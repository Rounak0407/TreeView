# TreeView Roadmap

## Phase 1
- Mobile and Web App SDK  
- AI pipeline integration (depth, segmentation, detection)  
- Testnet rewards live  

## Phase 2
- Custom TreeView hardware rollout  
- Mainnet TREE token launch  
- DAO governance start  

## Phase 3
- Satellite initiative funded by NFTs  
- Global mesh coverage  
- Full decentralization  
