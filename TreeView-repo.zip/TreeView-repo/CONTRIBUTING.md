# Contributing to TreeView

We welcome contributions!  
For now, contributions are limited until Full launch.  

## How to Contribute
- Report bugs via GitHub Issues  
- Suggest features via GitHub Discussions  
- Join our community on Telegram: [t.me/treeview]
