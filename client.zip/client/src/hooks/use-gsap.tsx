import { useEffect, useRef, useState } from "react";

// Type declarations for GSAP
declare global {
  interface Window {
    gsap: any;
    ScrollTrigger: any;
  }
}

// Global GSAP loading state
let gsapLoadPromise: Promise<void> | null = null;
let gsapLoaded = false;

export function useGSAP() {
  const contextRef = useRef<any>(null);
  const [isReady, setIsReady] = useState(false);

  useEffect(() => {
    // Load GSAP only once globally
    const loadGSAP = async () => {
      if (typeof window === 'undefined') return;
      
      // If already loaded, just create context
      if (gsapLoaded && (window as any).gsap) {
        contextRef.current = (window as any).gsap.context(() => {});
        setIsReady(true);
        return;
      }

      // If loading already in progress, wait for it
      if (gsapLoadPromise) {
        await gsapLoadPromise;
        if ((window as any).gsap) {
          contextRef.current = (window as any).gsap.context(() => {});
          setIsReady(true);
        }
        return;
      }

      // Create loading promise
      gsapLoadPromise = new Promise((resolve, reject) => {
        // Check if already loaded by another instance
        if ((window as any).gsap) {
          gsapLoaded = true;
          resolve();
          return;
        }

        // Load GSAP
        const gsapScript = document.createElement('script');
        gsapScript.src = 'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js';
        
        gsapScript.onload = () => {
          // Load ScrollTrigger after GSAP
          const stScript = document.createElement('script');
          stScript.src = 'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/ScrollTrigger.min.js';
          
          stScript.onload = () => {
            if ((window as any).gsap && (window as any).ScrollTrigger) {
              (window as any).gsap.registerPlugin((window as any).ScrollTrigger);
              gsapLoaded = true;
              resolve();
            } else {
              reject(new Error('GSAP failed to load'));
            }
          };

          stScript.onerror = () => reject(new Error('ScrollTrigger failed to load'));
          document.head.appendChild(stScript);
        };

        gsapScript.onerror = () => reject(new Error('GSAP failed to load'));
        document.head.appendChild(gsapScript);
      });

      try {
        await gsapLoadPromise;
        if ((window as any).gsap) {
          contextRef.current = (window as any).gsap.context(() => {});
          setIsReady(true);
        }
      } catch (error) {
        console.error('Failed to load GSAP:', error);
        gsapLoadPromise = null;
      }
    };

    loadGSAP();

    return () => {
      if (contextRef.current) {
        contextRef.current.revert();
        contextRef.current = null;
      }
    };
  }, []);

  const contextSafe = (func: () => void) => {
    return () => {
      if (isReady && contextRef.current && (window as any).gsap) {
        contextRef.current.add(func);
        func();
      }
    };
  };

  return { contextSafe, isReady };
}

// Add useInView hook for intersection observer
export function useInView(ref: React.RefObject<HTMLElement>) {
  const [isInView, setIsInView] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        setIsInView(entry.isIntersecting);
      },
      { threshold: 0.1 }
    );

    if (ref.current) {
      observer.observe(ref.current);
    }

    return () => {
      if (ref.current) {
        observer.unobserve(ref.current);
      }
    };
  }, [ref]);

  return isInView;
}
