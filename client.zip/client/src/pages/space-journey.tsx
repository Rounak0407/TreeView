import { useEffect, useRef } from "react";
import Navigation from "@/components/navigation";

export default function SpaceJourney() {
  const starsRef = useRef<HTMLDivElement>(null);
  const nebulaeRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Create twinkling stars
    const createStar = () => {
      if (!starsRef.current) return;
      
      const star = document.createElement('div');
      star.className = 'absolute bg-white rounded-full animate-pulse';
      
      // Different star sizes
      const size = Math.random();
      if (size > 0.8) {
        star.className += ' w-2 h-2';
      } else if (size > 0.5) {
        star.className += ' w-1 h-1';
      } else {
        star.className += ' w-0.5 h-0.5';
      }
      
      star.style.left = Math.random() * 100 + '%';
      star.style.top = Math.random() * 100 + '%';
      star.style.animationDuration = (Math.random() * 3 + 1) + 's';
      star.style.opacity = (Math.random() * 0.8 + 0.2).toString();
      
      starsRef.current.appendChild(star);
      
      setTimeout(() => {
        if (star.parentNode) star.parentNode.removeChild(star);
      }, 8000);
    };

    // Create floating nebula clouds
    const createNebula = () => {
      if (!nebulaeRef.current) return;
      
      const nebula = document.createElement('div');
      const colors = ['from-purple-600/20', 'from-blue-600/20', 'from-pink-600/20', 'from-teal-600/20'];
      const color = colors[Math.floor(Math.random() * colors.length)];
      
      nebula.className = `absolute rounded-full bg-gradient-radial ${color} to-transparent blur-2xl animate-pulse`;
      nebula.style.width = (Math.random() * 300 + 100) + 'px';
      nebula.style.height = nebula.style.width;
      nebula.style.left = Math.random() * 100 + '%';
      nebula.style.top = Math.random() * 100 + '%';
      nebula.style.animationDuration = (Math.random() * 10 + 5) + 's';
      
      nebulaeRef.current.appendChild(nebula);
      
      setTimeout(() => {
        if (nebula.parentNode) nebula.parentNode.removeChild(nebula);
      }, 15000);
    };

    const starInterval = setInterval(createStar, 300);
    const nebulaInterval = setInterval(createNebula, 2000);
    
    return () => {
      clearInterval(starInterval);
      clearInterval(nebulaInterval);
    };
  }, []);

  return (
    <div className="min-h-screen text-white font-inter overflow-hidden relative">
      {/* Deep black space background */}
      <div className="absolute inset-0 bg-black"></div>
      
      {/* Subtle space gradient */}
      <div className="absolute inset-0 bg-gradient-radial from-gray-900/30 via-black to-black"></div>
      
      {/* Static stars */}
      <div className="absolute inset-0">
        {[...Array(200)].map((_, i) => (
          <div
            key={i}
            className="absolute bg-white rounded-full"
            style={{
              width: Math.random() > 0.8 ? '2px' : '1px',
              height: Math.random() > 0.8 ? '2px' : '1px',
              left: Math.random() * 100 + '%',
              top: Math.random() * 100 + '%',
              opacity: Math.random() * 0.8 + 0.2,
            }}
          />
        ))}
      </div>
      
      {/* Distant galaxies */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute top-1/4 left-1/4 w-32 h-32 bg-purple-500/10 rounded-full blur-xl"></div>
        <div className="absolute top-3/4 right-1/4 w-24 h-24 bg-blue-500/10 rounded-full blur-xl"></div>
        <div className="absolute bottom-1/3 left-2/3 w-20 h-20 bg-teal-500/10 rounded-full blur-lg"></div>
      </div>
      
      {/* Animated nebulae */}
      <div ref={nebulaeRef} className="absolute inset-0 overflow-hidden"></div>
      
      {/* Twinkling stars */}
      <div ref={starsRef} className="absolute inset-0 overflow-hidden"></div>
      
      {/* Subtle shooting stars */}
      <div className="absolute inset-0">
        {[...Array(3)].map((_, i) => (
          <div
            key={i}
            className="absolute h-px bg-gradient-to-r from-transparent via-white/50 to-transparent animate-pulse opacity-20"
            style={{
              width: Math.random() * 100 + 50 + 'px',
              left: Math.random() * 100 + '%',
              top: Math.random() * 100 + '%',
              animationDelay: Math.random() * 10 + 's',
              animationDuration: (Math.random() * 5 + 3) + 's',
              transform: `rotate(${Math.random() * 45 - 22.5}deg)`
            }}
          />
        ))}
      </div>

      <div className="relative z-10">
        <Navigation />
        
        <div className="min-h-screen flex flex-col items-center justify-center px-6 py-20">
          {/* Hero section with highlighted community satellite */}
          <div className="text-center mb-20 max-w-7xl mx-auto">
            {/* Main hero title */}
            <div className="mb-8 relative">
              <h1 className="font-orbitron text-3xl lg:text-5xl font-bold mb-6 text-white leading-tight">
                WELCOME TO THE COSMOS
              </h1>
            </div>

            {/* Highlighted community satellite announcement */}
            <div className="relative mb-12">
              <div className="bg-gray-900/50 backdrop-blur-sm border border-gray-700/50 rounded-xl p-8 mx-auto max-w-4xl">
                <div className="relative z-10">
                  <div className="inline-block px-4 py-2 bg-white/10 rounded-full text-white font-semibold text-sm mb-4 border border-white/20">
                    WORLD'S FIRST
                  </div>
                  
                  <h2 className="font-orbitron text-2xl lg:text-4xl font-bold mb-4 text-white leading-tight">
                    COMMUNITY-OWNED SATELLITE
                  </h2>
                  
                  <p className="text-lg text-gray-300 mb-6 leading-relaxed max-w-3xl mx-auto">
                    TreeView pioneers the future of space exploration with the first satellite 
                    <span className="font-semibold text-white"> owned and governed by its community</span>
                  </p>
                  
                  <div className="flex justify-center items-center space-x-6 text-3xl">
                    <div className="w-12 h-12 bg-white/10 rounded-full flex items-center justify-center border border-white/20">
                      <span>🛰️</span>
                    </div>
                    <div className="text-lg font-orbitron font-bold text-gray-400">×</div>
                    <div className="w-12 h-12 bg-white/10 rounded-full flex items-center justify-center border border-white/20">
                      <span>🌍</span>
                    </div>
                    <div className="text-lg font-orbitron font-bold text-gray-400">=</div>
                    <div className="w-12 h-12 bg-white/10 rounded-full flex items-center justify-center border border-white/20">
                      <span>🌌</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="text-xl lg:text-2xl font-orbitron font-bold text-gray-400">
              LAUNCHING SOON...
            </div>
          </div>



          {/* TreeView Satellite Mission Details */}
          <div className="w-full max-w-6xl mx-auto">
            <div className="grid lg:grid-cols-2 gap-12 mb-16">
              {/* Community-Owned Satellite */}
              <div className="bg-gray-900/40 backdrop-blur-sm border border-gray-700/50 rounded-xl p-6">
                <h2 className="font-orbitron text-xl font-bold mb-4 text-white">
                  COMMUNITY-OWNED SATELLITE
                </h2>
                <div className="space-y-4 text-gray-300">
                  <p className="leading-relaxed">
                    TreeView will launch the <span className="text-white font-semibold">first community-owned satellite</span>, 
                    operated and funded through the TreeView DePIN ecosystem.
                  </p>
                  
                  <div className="space-y-3">
                    <div className="flex items-start gap-3">
                      <div className="w-1.5 h-1.5 bg-gray-400 rounded-full mt-2 flex-shrink-0"></div>
                      <p className="text-sm">Satellite nodes will capture <span className="text-gray-200">3D elevation data (DEM)</span>, optical imagery, and GNSS signal intelligence</p>
                    </div>
                    
                    <div className="flex items-start gap-3">
                      <div className="w-1.5 h-1.5 bg-gray-400 rounded-full mt-2 flex-shrink-0"></div>
                      <p className="text-sm">Satellite control, data transmission, and tokenized governance via <span className="text-gray-200">peaq-powered smart contracts</span> and on-orbit license NFTs</p>
                    </div>
                    
                    <div className="flex items-start gap-3">
                      <div className="w-1.5 h-1.5 bg-gray-400 rounded-full mt-2 flex-shrink-0"></div>
                      <p className="text-sm">Satellite data integrates with terrestrial nodes to anchor and refine <span className="text-gray-200">ground-level 3D reconstructions</span></p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Launch Strategy */}
              <div className="bg-gray-900/40 backdrop-blur-sm border border-gray-700/50 rounded-xl p-6">
                <h2 className="font-orbitron text-xl font-bold mb-4 text-white">
                  LAUNCH STRATEGY
                </h2>
                <div className="space-y-4 text-gray-300">
                  <p className="leading-relaxed">
                    After mainnet and revenue foundation are in place, we begin the world's first 
                    <span className="text-white font-semibold"> DePIN-powered satellite launch</span>.
                  </p>
                  
                  <div className="space-y-3">
                    <div className="bg-gray-800/40 rounded-lg p-3 border border-gray-700/30">
                      <h4 className="font-semibold text-white text-sm mb-1">NFT-based DAO Fundraising</h4>
                      <p className="text-xs text-gray-400">Community-driven funding model to support launch costs</p>
                    </div>
                    
                    <div className="bg-gray-800/40 rounded-lg p-3 border border-gray-700/30">
                      <h4 className="font-semibold text-white text-sm mb-1">Satellite Payload Finalization</h4>
                      <p className="text-xs text-gray-400">Optical + GNSS/terrain sensors integration</p>
                    </div>
                    
                    <div className="bg-gray-800/40 rounded-lg p-3 border border-gray-700/30">
                      <h4 className="font-semibold text-white text-sm mb-1">Data Pipeline Integration</h4>
                      <p className="text-xs text-gray-400">Satellite data into existing contributor-based mapping</p>
                    </div>
                    
                    <div className="bg-gray-800/40 rounded-lg p-3 border border-gray-700/30">
                      <h4 className="font-semibold text-white text-sm mb-1">On-Chain Governance</h4>
                      <p className="text-xs text-gray-400">Community control of data access, licensing, and rewards</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Earth-to-Orbit Transition */}
            <div className="bg-gray-900/40 backdrop-blur-sm border border-gray-700/50 rounded-xl p-8 text-center">
              <h2 className="font-orbitron text-2xl font-bold mb-6 text-white">
                EARTH-TO-ORBIT EVOLUTION
              </h2>
              <p className="text-lg text-gray-300 mb-8 leading-relaxed max-w-4xl mx-auto">
                TreeView's evolution from ground networks to a complete 
                <span className="font-semibold text-white"> Earth-to-orbit spatial data infrastructure</span>
              </p>
              
              <div className="grid md:grid-cols-3 gap-8 mt-8">
                <div className="text-center">
                  <div className="w-16 h-16 bg-white/10 rounded-full mx-auto mb-4 flex items-center justify-center border border-white/20">
                    <div className="text-2xl">🌍</div>
                  </div>
                  <h3 className="font-orbitron text-lg font-bold text-white mb-2">GROUND NETWORK</h3>
                  <p className="text-gray-400 text-sm">Terrestrial nodes and contributors</p>
                </div>
                
                <div className="text-center">
                  <div className="w-16 h-16 bg-white/10 rounded-full mx-auto mb-4 flex items-center justify-center border border-white/20">
                    <div className="text-2xl">🛰️</div>
                  </div>
                  <h3 className="font-orbitron text-lg font-bold text-white mb-2">SATELLITE LAYER</h3>
                  <p className="text-gray-400 text-sm">Orbital data collection and validation</p>
                </div>
                
                <div className="text-center">
                  <div className="w-16 h-16 bg-white/10 rounded-full mx-auto mb-4 flex items-center justify-center border border-white/20">
                    <div className="text-2xl">🌌</div>
                  </div>
                  <h3 className="font-orbitron text-lg font-bold text-white mb-2">UNIVERSAL ACCESS</h3>
                  <p className="text-gray-400 text-sm">Open spatial data infrastructure</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}