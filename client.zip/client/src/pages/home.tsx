import Navigation from "@/components/navigation";
import PointcloudEarth from "@/components/pointcloud-earth";
import FloatingSatellite from "@/components/floating-satellite";
import AnimatedEarthGlobe from "@/components/animated-earth-globe";
import Hero from "@/components/hero";
import ProblemSolution from "@/components/problem-solution";
import Tokenomics from "@/components/tokenomics";
import CoreTechnology from "@/components/core-technology";
import AnimatedNetwork from "@/components/animated-network";
import BusinessModel from "@/components/business-model";
import UseCases from "@/components/use-cases";
import Community from "@/components/community";
import Footer from "@/components/footer";
import ModalSystem from "@/components/modal-system";

export default function Home() {
  return (
    <div className="min-h-screen text-white font-inter overflow-x-hidden relative">
      <PointcloudEarth />
      <FloatingSatellite />
      <div className="relative z-10">
        <Navigation />
        <Hero />
        <ProblemSolution />
        <CoreTechnology />
        <AnimatedNetwork />
        <BusinessModel />
        <UseCases />
        <Community />
        <Tokenomics />
        <Footer />
        <ModalSystem />
      </div>
    </div>
  );
}
