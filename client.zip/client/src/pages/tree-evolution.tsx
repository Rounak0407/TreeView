import { useEffect, useRef } from "react";
import { Smartphone, Camera, Satellite, Cpu, Globe, TreePine, Network, Zap } from "lucide-react";
import { useGSAP } from "@/hooks/use-gsap";
import Navigation from "@/components/navigation";
import SpaceBackground from "@/components/space-background";
import Footer from "@/components/footer";

export default function TreeEvolution() {
  const treeRef = useRef<HTMLDivElement>(null);
  const networkRef = useRef<HTMLDivElement>(null);
  const { contextSafe } = useGSAP();

  useEffect(() => {
    const animateTreeGrowth = contextSafe(() => {
      if (typeof window !== 'undefined' && (window as any).gsap && treeRef.current) {
        const gsap = (window as any).gsap;
        const tl = gsap.timeline({ repeat: -1, yoyo: false });
        
        // Tree growth animation
        tl.fromTo(".tree-trunk", 
          { scaleY: 0, transformOrigin: "bottom" },
          { scaleY: 1, duration: 3, ease: "power2.out" }
        )
        .fromTo(".tree-branch", 
          { scale: 0, transformOrigin: "bottom left" },
          { scale: 1, duration: 2, stagger: 0.3, ease: "back.out(1.7)" }
        )
        .fromTo(".tree-leaf", 
          { opacity: 0, scale: 0 },
          { opacity: 1, scale: 1, duration: 1, stagger: 0.1, ease: "bounce.out" }
        )
        .to(".data-node", 
          { scale: 1.2, opacity: 1, duration: 0.5, stagger: 0.2, ease: "power2.out" }
        )
        .to(".connection-line", 
          { strokeDasharray: "100, 0", duration: 2, stagger: 0.1, ease: "power2.out" }
        );

        // Network pulse animation
        gsap.to(".network-pulse", {
          scale: 1.5,
          opacity: 0.3,
          duration: 2,
          repeat: -1,
          yoyo: true,
          stagger: 0.5,
          ease: "power2.inOut"
        });

        // Data flow animation
        gsap.to(".data-flow", {
          x: "100vw",
          duration: 8,
          repeat: -1,
          ease: "none",
          stagger: 2
        });
      }
    });

    const timer = setTimeout(animateTreeGrowth, 500);
    return () => clearTimeout(timer);
  }, [contextSafe]);

  return (
    <div className="min-h-screen text-white font-inter overflow-x-hidden relative">
      <SpaceBackground />
      <div className="relative z-10">
        <Navigation />
        <div className="pt-20 bg-gradient-to-br from-gray-900 via-gray-800 to-black min-h-screen">
      {/* Animated background particles */}
      <div className="absolute inset-0 pointer-events-none">
        {Array.from({ length: 100 }).map((_, i) => (
          <div
            key={i}
            className="absolute w-1 h-1 bg-green-500/20 rounded-full animate-pulse"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 3}s`,
              animationDuration: `${2 + Math.random() * 2}s`
            }}
          />
        ))}
      </div>

      {/* Header */}
      <div className="relative z-10 text-center pt-16 pb-8">
        <h1 className="font-mono text-4xl md:text-6xl font-light tracking-wider text-white mb-6 drop-shadow-2xl">
          TREE EVOLUTION
        </h1>
        <p className="text-lg md:text-xl text-gray-300 font-light tracking-wide max-w-4xl mx-auto px-6">
          Watch TreeView's data network grow through hybrid device capture - from phones to satellites - 
          creating advanced 4D semantic mapping technology
        </p>
      </div>

      {/* Main Animation Container */}
      <div className="flex flex-col lg:flex-row items-center justify-center min-h-[70vh] px-8 gap-16">
        
        {/* Animated Tree Growth */}
        <div className="relative flex-1 max-w-md" ref={treeRef}>
          <svg viewBox="0 0 300 400" className="w-full h-96">
            {/* Tree Trunk */}
            <rect 
              className="tree-trunk fill-gray-600" 
              x="140" 
              y="250" 
              width="20" 
              height="150" 
              rx="10"
            />
            
            {/* Tree Branches */}
            <g className="tree-branches">
              <rect className="tree-branch fill-gray-500" x="130" y="200" width="40" height="8" rx="4" transform="rotate(-20 150 204)" />
              <rect className="tree-branch fill-gray-500" x="120" y="180" width="35" height="6" rx="3" transform="rotate(-35 137 183)" />
              <rect className="tree-branch fill-gray-500" x="160" y="180" width="35" height="6" rx="3" transform="rotate(35 177 183)" />
              <rect className="tree-branch fill-gray-500" x="110" y="220" width="30" height="5" rx="2" transform="rotate(-45 125 222)" />
              <rect className="tree-branch fill-gray-500" x="170" y="220" width="30" height="5" rx="2" transform="rotate(45 185 222)" />
            </g>
            
            {/* Tree Leaves with Data Nodes */}
            <g className="tree-leaves">
              <circle className="tree-leaf" cx="110" cy="160" r="25" opacity="0.8" fill="#228B22" />
              <circle className="tree-leaf" cx="190" cy="160" r="25" opacity="0.8" fill="#228B22" />
              <circle className="tree-leaf" cx="150" cy="140" r="30" opacity="0.8" fill="#228B22" />
              <circle className="tree-leaf" cx="90" cy="190" r="20" opacity="0.8" fill="#32CD32" />
              <circle className="tree-leaf" cx="210" cy="190" r="20" opacity="0.8" fill="#32CD32" />
              <circle className="tree-leaf" cx="150" cy="180" r="25" opacity="0.8" fill="#228B22" />
              
              {/* Data Nodes */}
              <circle className="data-node" cx="110" cy="160" r="3" opacity="0" fill="#FFFFFF" />
              <circle className="data-node" cx="190" cy="160" r="3" opacity="0" fill="#FFFFFF" />
              <circle className="data-node" cx="150" cy="140" r="3" opacity="0" fill="#FFFFFF" />
              <circle className="data-node" cx="90" cy="190" r="3" opacity="0" fill="#FFFFFF" />
              <circle className="data-node" cx="210" cy="190" r="3" opacity="0" fill="#FFFFFF" />
              <circle className="data-node" cx="150" cy="180" r="3" opacity="0" fill="#FFFFFF" />
            </g>

            {/* Connection Lines */}
            <g className="connections stroke-white stroke-1 fill-none opacity-60">
              <line className="connection-line" x1="110" y1="160" x2="150" y2="140" strokeDasharray="0,100" />
              <line className="connection-line" x1="190" y1="160" x2="150" y2="140" strokeDasharray="0,100" />
              <line className="connection-line" x1="150" y1="140" x2="150" y2="180" strokeDasharray="0,100" />
              <line className="connection-line" x1="90" y1="190" x2="150" y2="180" strokeDasharray="0,100" />
              <line className="connection-line" x1="210" y1="190" x2="150" y2="180" strokeDasharray="0,100" />
            </g>

            {/* Network Pulses */}
            <circle className="network-pulse fill-cyan-400" cx="110" cy="160" r="5" opacity="0" />
            <circle className="network-pulse fill-blue-400" cx="190" cy="160" r="5" opacity="0" />
            <circle className="network-pulse fill-violet-400" cx="150" cy="140" r="5" opacity="0" />
          </svg>

          {/* Tree Base Data Collection */}
          <div className="absolute -bottom-8 left-1/2 transform -translate-x-1/2 text-center">
            <div className="text-sm text-slate-400 font-mono">DATA NETWORK ROOT</div>
            <div className="w-24 h-1 bg-gradient-to-r from-transparent via-blue-400 to-transparent mt-2"></div>
          </div>
        </div>

        {/* Data Capture Devices */}
        <div className="flex-1 space-y-12 max-w-2xl">
          
          {/* Mobile Devices */}
          <div className="bg-slate-800/40 backdrop-blur-sm p-8 rounded-2xl border border-slate-700 hover:border-blue-400 transition-all duration-300">
            <div className="flex items-center mb-6">
              <div className="p-3 bg-blue-500/20 rounded-lg mr-4">
                <Smartphone className="text-blue-400" size={28} />
              </div>
              <div>
                <h3 className="font-mono text-xl font-medium text-white uppercase tracking-wider">Mobile Mapping</h3>
                <p className="text-slate-400 text-sm">Smartphones & Camera Systems</p>
              </div>
            </div>
            <p className="text-slate-300 leading-relaxed font-light mb-4">
              Contributors use phones and camera systems to capture street-level 3D data, feeding the TreeView network with continuous spatial intelligence from urban environments.
            </p>
            <div className="flex space-x-2">
              <div className="data-flow w-2 h-2 bg-blue-400 rounded-full"></div>
              <div className="flex-1 h-px bg-gradient-to-r from-blue-400/50 to-transparent mt-1"></div>
            </div>
          </div>

          {/* Vehicle Systems */}
          <div className="bg-slate-800/40 backdrop-blur-sm p-8 rounded-2xl border border-slate-700 hover:border-emerald-400 transition-all duration-300">
            <div className="flex items-center mb-6">
              <div className="p-3 bg-emerald-500/20 rounded-lg mr-4">
                <Camera className="text-emerald-400" size={28} />
              </div>
              <div>
                <h3 className="font-mono text-xl font-medium text-white uppercase tracking-wider">Vehicle Kits</h3>
                <p className="text-slate-400 text-sm">LiDAR & RTK Hardware</p>
              </div>
            </div>
            <p className="text-slate-300 leading-relaxed font-light mb-4">
              Specialized hardware kits with LiDAR and RTK GPS capture high-precision geospatial data from vehicles, creating detailed 3D maps of roads and infrastructure.
            </p>
            <div className="flex space-x-2">
              <div className="data-flow w-2 h-2 bg-emerald-400 rounded-full"></div>
              <div className="flex-1 h-px bg-gradient-to-r from-emerald-400/50 to-transparent mt-1"></div>
            </div>
          </div>

          {/* Satellite Integration */}
          <div className="bg-slate-800/40 backdrop-blur-sm p-8 rounded-2xl border border-slate-700 hover:border-violet-400 transition-all duration-300">
            <div className="flex items-center mb-6">
              <div className="p-3 bg-violet-500/20 rounded-lg mr-4">
                <Satellite className="text-violet-400" size={28} />
              </div>
              <div>
                <h3 className="font-mono text-xl font-medium text-white uppercase tracking-wider">Satellite Data</h3>
                <p className="text-slate-400 text-sm">Community-Owned Satellite System</p>
              </div>
            </div>
            <p className="text-slate-300 leading-relaxed font-light mb-4">
              TreeView's community-owned satellite provides orbital perspective, capturing DEM elevation data and optical imagery for global 4D semantic mapping coverage.
            </p>
            <div className="flex space-x-2">
              <div className="data-flow w-2 h-2 bg-violet-400 rounded-full"></div>
              <div className="flex-1 h-px bg-gradient-to-r from-violet-400/50 to-transparent mt-1"></div>
            </div>
          </div>

        </div>
      </div>

      {/* Applications Section */}
      <div className="relative z-10 px-8 py-16">
        <div className="text-center mb-12">
          <h2 className="font-mono text-3xl font-light tracking-wider text-white mb-4">POWERED APPLICATIONS</h2>
          <p className="text-slate-400 max-w-2xl mx-auto">
            TreeView's 4D semantic mapping enables next-generation spatial applications
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
          <div className="bg-slate-800/30 backdrop-blur-sm p-6 rounded-xl border border-slate-700 text-center hover:border-cyan-400 transition-all duration-300">
            <div className="p-4 bg-cyan-500/20 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
              <Globe className="text-cyan-400" size={24} />
            </div>
            <h3 className="font-mono text-lg text-white mb-2 uppercase tracking-wide">AR/VR</h3>
            <p className="text-slate-400 text-sm">Immersive spatial experiences with real-world precision</p>
          </div>

          <div className="bg-slate-800/30 backdrop-blur-sm p-6 rounded-xl border border-slate-700 text-center hover:border-orange-400 transition-all duration-300">
            <div className="p-4 bg-orange-500/20 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
              <Cpu className="text-orange-400" size={24} />
            </div>
            <h3 className="font-mono text-lg text-white mb-2 uppercase tracking-wide">Robotics</h3>
            <p className="text-slate-400 text-sm">Autonomous navigation with trustless geospatial data</p>
          </div>

          <div className="bg-slate-800/30 backdrop-blur-sm p-6 rounded-xl border border-slate-700 text-center hover:border-emerald-400 transition-all duration-300">
            <div className="p-4 bg-emerald-500/20 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
              <Network className="text-emerald-400" size={24} />
            </div>
            <h3 className="font-mono text-lg text-white mb-2 uppercase tracking-wide">Digital Twins</h3>
            <p className="text-slate-400 text-sm">Real-time digital replicas of physical environments</p>
          </div>

          <div className="bg-slate-800/30 backdrop-blur-sm p-6 rounded-xl border border-slate-700 text-center hover:border-violet-400 transition-all duration-300">
            <div className="p-4 bg-violet-500/20 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
              <Zap className="text-violet-400" size={24} />
            </div>
            <h3 className="font-mono text-lg text-white mb-2 uppercase tracking-wide">Autonomous Systems</h3>
            <p className="text-slate-400 text-sm">Self-driving vehicles and autonomous operations</p>
          </div>
        </div>
      </div>

      {/* Timeline Section */}
      <div className="relative z-10 px-8 py-16 bg-slate-900/50">
        <div className="text-center mb-12">
          
          <p className="text-slate-400 max-w-2xl mx-auto">
            TreeView's evolution to become the world's most accurate and permissionless 3D mapping infrastructure
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          <div className="bg-slate-800/40 backdrop-blur-sm p-8 rounded-2xl border border-slate-700">
            <div className="text-center mb-6">
              <div className="w-12 h-12 bg-blue-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-blue-400 font-mono font-bold">1</span>
              </div>
              <h3 className="font-mono text-xl text-white uppercase tracking-wider">Year 1</h3>
              <p className="text-slate-400 text-sm">Testnet Launch & Hardware Rollout</p>
            </div>
            <ul className="space-y-2 text-slate-300 text-sm">
              <li>• Mobile contributor app launch</li>
              <li>• Low-cost LiDAR/RTK hardware kits</li>
              <li>• Global contributor onboarding</li>
              <li>• Testnet rewards program</li>
              <li>• AI pipeline development</li>
            </ul>
          </div>

          <div className="bg-slate-800/40 backdrop-blur-sm p-8 rounded-2xl border border-slate-700">
            <div className="text-center mb-6">
              <div className="w-12 h-12 bg-emerald-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-emerald-400 font-mono font-bold">2</span>
              </div>
              <h3 className="font-mono text-xl text-white uppercase tracking-wider">Year 2</h3>
              <p className="text-slate-400 text-sm">Mainnet & Commercial Partnerships</p>
            </div>
            <ul className="space-y-2 text-slate-300 text-sm">
              <li>• Mainnet deployment</li>
              <li>• API monetization for AR/VR</li>
              <li>• Commercial partnerships</li>
              <li>• Team scaling to 10+ engineers</li>
              <li>• Enhanced mapping precision</li>
            </ul>
          </div>

          <div className="bg-slate-800/40 backdrop-blur-sm p-8 rounded-2xl border border-slate-700">
            <div className="text-center mb-6">
              <div className="w-12 h-12 bg-violet-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-violet-400 font-mono font-bold">3</span>
              </div>
              <h3 className="font-mono text-xl text-white uppercase tracking-wider">Year 3</h3>
              <p className="text-slate-400 text-sm">Community-Owned Satellite Launch</p>
            </div>
            <ul className="space-y-2 text-slate-300 text-sm">
              <li>• NFT-based DAO fundraising</li>
              <li>• Satellite payload finalization</li>
              <li>• Earth-to-orbit data integration</li>
              <li>• On-chain governance launch</li>
              <li>• Complete spatial data layer</li>
            </ul>
          </div>
        </div>
      </div>
        </div>
        <Footer />
      </div>
    </div>
  );
}