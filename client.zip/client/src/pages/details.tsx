import Navigation from "@/components/navigation";
import PointcloudEarth from "@/components/pointcloud-earth";
import FloatingSatellite from "@/components/floating-satellite";
import MappingModalities from "@/components/mapping-modalities";
import PhaseRoadmap from "@/components/phase-roadmap";
import TechStack from "@/components/tech-stack";
import Footer from "@/components/footer";

export default function Details() {
  return (
    <div className="min-h-screen text-white font-inter overflow-x-hidden relative">
      <PointcloudEarth />
      <FloatingSatellite />
      <div className="relative z-10">
        <Navigation />
        <div className="pt-20">
          <div className="max-w-7xl mx-auto px-6 py-12">
            <div className="text-center mb-16">
              <h1 className="font-orbitron text-4xl lg:text-6xl font-bold mb-6 text-gradient" data-testid="details-title">
                TreeView Satellite System
              </h1>
              <p className="text-xl text-gray-300 max-w-3xl mx-auto" data-testid="details-description">
                Advanced 4D semantic mapping through hybrid satellite constellation, IoT sensors, and mobile devices. 
                Building the world's first decentralized geospatial intelligence network.
              </p>
            </div>

            {/* Satellite Mission Overview */}
            <div className="glass-effect p-8 rounded-xl mb-12 pointcloud-bg">
              <div className="grid md:grid-cols-2 gap-8 items-center">
                <div>
                  <h2 className="font-orbitron text-3xl font-bold mb-6 text-gradient">
                    Mission Overview
                  </h2>
                  <div className="space-y-4 text-gray-300">
                    <div className="flex items-start gap-3">
                      <div className="w-2 h-2 bg-steel-blue rounded-full mt-2 flex-shrink-0"></div>
                      <div>
                        <h3 className="font-semibold text-white mb-1">Global Coverage</h3>
                        <p>0 active satellites providing 67.3% Earth coverage with sub-meter precision</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <div className="w-2 h-2 bg-accent-teal rounded-full mt-2 flex-shrink-0"></div>
                      <div>
                        <h3 className="font-semibold text-white mb-1">Real-time Processing</h3>
                        <p>0.0 TB/s data throughput with AI-powered semantic reconstruction</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <div className="w-2 h-2 bg-soft-mint rounded-full mt-2 flex-shrink-0"></div>
                      <div>
                        <h3 className="font-semibold text-white mb-1">Decentralized Network</h3>
                        <p>00 active nodes contributing to mapping and validation processes</p>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="relative">
                  <div className="aspect-square bg-gradient-radial rounded-full relative overflow-hidden">
                    <div className="absolute inset-4 border-2 border-steel-blue/30 rounded-full"></div>
                    <div className="absolute inset-8 border-2 border-accent-teal/30 rounded-full"></div>
                    <div className="absolute inset-12 border-2 border-soft-mint/30 rounded-full"></div>
                    
                    {/* Satellite orbits visualization */}
                    <div className="absolute top-4 left-1/2 -translate-x-1/2 w-3 h-3 bg-steel-blue rounded-full animate-pulse"></div>
                    <div className="absolute bottom-8 right-8 w-3 h-3 bg-accent-teal rounded-full animate-pulse" style={{animationDelay: '0.5s'}}></div>
                    <div className="absolute left-6 top-1/2 -translate-y-1/2 w-3 h-3 bg-soft-mint rounded-full animate-pulse" style={{animationDelay: '1s'}}></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <MappingModalities />
          <PhaseRoadmap />
          <TechStack />
        </div>
        <Footer />
      </div>
    </div>
  );
}