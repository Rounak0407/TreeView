import { useEffect, useState, useMemo } from "react";
import { useLocation } from "wouter";
import { 
  Wallet, 
  Settings, 
  LogOut, 
  User, 
  MapPin, 
  Clock, 
  Coins, 
  BarChart3,
  Eye,
  EyeOff,
  Lock,
  Plus,
  Activity,
  TrendingUp,
  QrCode
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import TreeViewLogo from "@/components/logo";
import { useAppKit } from '@reown/appkit/react';
import { useAccount, useDisconnect, WagmiProvider } from 'wagmi';
import { initializeWallet } from "@/lib/walletConfig";

interface User {
  id: string;
  email: string;
  username: string;
  isVerified: boolean;
  createdAt: string;
}

interface UserStats {
  userId: string;
  totalDistanceKm: number;
  totalDataGB: number;
  totalTokens: number;
  totalSessions: number;
}

interface MappingSession {
  id: string;
  userId: string;
  mode: string;
  startTime: string;
  endTime?: string;
  distanceKm: number;
  dataSizeMB: number;
  tokensEarned: number;
  status: string;
  startLocation?: {
    lat: number;
    lng: number;
  };
  endLocation?: {
    lat: number;
    lng: number;
  };
}

interface WalletConnection {
  id: string;
  userId: string;
  walletAddress: string;
  walletType: string;
  isActive: boolean;
  connectedAt: string;
}

interface DashboardData {
  stats: UserStats;
  recentSessions: MappingSession[];
  walletConnections: WalletConnection[];
  activeMappingSession?: MappingSession;
}

function ConsoleInner() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  // WalletConnect hooks
  const { open } = useAppKit();
  const { address, isConnected } = useAccount();
  const { disconnect } = useDisconnect();
  const [user, setUser] = useState<User | null>(null);
  const [dashboardData, setDashboardData] = useState<DashboardData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [showPasswordForm, setShowPasswordForm] = useState(false);
  const [showWalletForm, setShowWalletForm] = useState(false);
  
  // Password change form
  const [passwordForm, setPasswordForm] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: ""
  });

  // Wallet connection form
  const [walletForm, setWalletForm] = useState({
    walletAddress: "",
    walletType: "walletconnect"
  });

  useEffect(() => {
    const sessionToken = localStorage.getItem("sessionToken");
    if (!sessionToken) {
      setLocation("/auth");
      return;
    }

    fetchUserData();
    fetchDashboardData();
  }, []);

  const fetchUserData = async () => {
    try {
      const sessionToken = localStorage.getItem("sessionToken");
      const response = await fetch("/api/auth/user", {
        headers: {
          "Authorization": `Bearer ${sessionToken}`
        }
      });

      if (response.ok) {
        const userData = await response.json();
        setUser(userData);
      } else {
        localStorage.removeItem("sessionToken");
        setLocation("/auth");
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to fetch user data",
        variant: "destructive",
      });
    }
  };

  const fetchDashboardData = async () => {
    try {
      const sessionToken = localStorage.getItem("sessionToken");
      const response = await fetch("/api/dashboard", {
        headers: {
          "Authorization": `Bearer ${sessionToken}`
        }
      });

      if (response.ok) {
        const data = await response.json();
        setDashboardData(data);
      }
    } catch (error) {
      toast({
        title: "Error", 
        description: "Failed to fetch dashboard data",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogout = async () => {
    try {
      const sessionToken = localStorage.getItem("sessionToken");
      await fetch("/api/auth/logout", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${sessionToken}`
        }
      });
    } catch (error) {
      console.error("Logout error:", error);
    } finally {
      localStorage.removeItem("sessionToken");
      toast({
        title: "Logged out",
        description: "You have been logged out successfully.",
      });
      setLocation("/");
    }
  };

  const handlePasswordChange = async (e: React.FormEvent) => {
    e.preventDefault();

    if (passwordForm.newPassword !== passwordForm.confirmPassword) {
      toast({
        title: "Password mismatch",
        description: "New passwords do not match",
        variant: "destructive",
      });
      return;
    }

    try {
      const sessionToken = localStorage.getItem("sessionToken");
      const response = await fetch("/api/auth/change-password", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${sessionToken}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          currentPassword: passwordForm.currentPassword,
          newPassword: passwordForm.newPassword
        })
      });

      const data = await response.json();

      if (response.ok) {
        toast({
          title: "Password changed",
          description: "Your password has been updated successfully.",
        });
        setPasswordForm({ currentPassword: "", newPassword: "", confirmPassword: "" });
        setShowPasswordForm(false);
      } else {
        toast({
          title: "Password change failed",
          description: data.error || "Failed to change password",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Network error",
        description: "Failed to connect to server. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleWalletConnect = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      const sessionToken = localStorage.getItem("sessionToken");
      const response = await fetch("/api/wallet/connect", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${sessionToken}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify(walletForm)
      });

      const data = await response.json();

      if (response.ok) {
        toast({
          title: "Wallet connected",
          description: "Your wallet has been connected successfully.",
        });
        fetchDashboardData(); // Refresh to show updated wallet
        setWalletForm({ walletAddress: "", walletType: "metamask" });
        setShowWalletForm(false);
      } else {
        toast({
          title: "Wallet connection failed",
          description: data.error || "Failed to connect wallet",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Network error",
        description: "Failed to connect to server. Please try again.",
        variant: "destructive",
      });
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const getModeIcon = (mode: string) => {
    switch (mode) {
      case 'walking': return '🚶';
      case 'driving': return '🚗';
      case 'cycling': return '🚴';
      default: return '📍';
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-900 flex items-center justify-center">
        <div className="text-slate-900 dark:text-white text-xl font-medium">Loading console...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white">
      {/* Header */}
      <header className="bg-white dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700 shadow-sm">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <TreeViewLogo size={32} />
              <div>
                <h1 className="text-xl font-semibold text-slate-900 dark:text-white">Console</h1>
                <p className="text-sm text-slate-600 dark:text-slate-400">Welcome back, {user?.username}</p>
              </div>
            </div>
            <Button 
              onClick={handleLogout}
              variant="outline"
              className="border-slate-200 dark:border-slate-600 hover:bg-slate-50 dark:hover:bg-slate-700"
              data-testid="button-logout"
            >
              <LogOut className="w-4 h-4 mr-2" />
              Sign Out
            </Button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-6 py-8">
        <Tabs defaultValue="dashboard" className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-8 bg-slate-100 dark:bg-slate-700 border-0">
            <TabsTrigger value="dashboard" className="data-[state=active]:bg-white data-[state=active]:text-slate-900 dark:data-[state=active]:bg-slate-600 dark:data-[state=active]:text-white text-slate-600 dark:text-slate-300">
              <BarChart3 className="w-4 h-4 mr-2" />
              Dashboard
            </TabsTrigger>
            <TabsTrigger value="settings" className="data-[state=active]:bg-white data-[state=active]:text-slate-900 dark:data-[state=active]:bg-slate-600 dark:data-[state=active]:text-white text-slate-600 dark:text-slate-300">
              <Settings className="w-4 h-4 mr-2" />
              Settings
            </TabsTrigger>
            <TabsTrigger value="wallet" className="data-[state=active]:bg-white data-[state=active]:text-slate-900 dark:data-[state=active]:bg-slate-600 dark:data-[state=active]:text-white text-slate-600 dark:text-slate-300">
              <Wallet className="w-4 h-4 mr-2" />
              Wallet
            </TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard" className="space-y-6">
            {/* Stats Overview */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium text-slate-600 dark:text-slate-400">Total Distance</CardTitle>
                  <MapPin className="h-4 w-4 text-slate-500 dark:text-slate-400" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-slate-900 dark:text-white">{dashboardData?.stats?.totalDistanceKm?.toFixed(1) || '0.0'} km</div>
                  <p className="text-xs text-slate-500 dark:text-slate-400">Captured mapping data</p>
                </CardContent>
              </Card>

              <Card className="bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium text-slate-600 dark:text-slate-400">Data Uploaded</CardTitle>
                  <Activity className="h-4 w-4 text-slate-500 dark:text-slate-400" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-slate-900 dark:text-white">{dashboardData?.stats?.totalDataGB?.toFixed(2) || '0.00'} GB</div>
                  <p className="text-xs text-slate-500 dark:text-slate-400">Total data contribution</p>
                </CardContent>
              </Card>

              <Card className="bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium text-slate-600 dark:text-slate-400">Tokens Earned</CardTitle>
                  <Coins className="h-4 w-4 text-slate-500 dark:text-slate-400" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-slate-900 dark:text-white">{dashboardData?.stats?.totalTokens?.toFixed(0) || '0'}</div>
                  <p className="text-xs text-slate-500 dark:text-slate-400">TREEV tokens</p>
                </CardContent>
              </Card>

              <Card className="bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium text-slate-600 dark:text-slate-400">Sessions</CardTitle>
                  <Clock className="h-4 w-4 text-slate-500 dark:text-slate-400" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-slate-900 dark:text-white">{dashboardData?.stats?.totalSessions || 0}</div>
                  <p className="text-xs text-slate-500 dark:text-slate-400">Mapping sessions</p>
                </CardContent>
              </Card>
            </div>

            {/* Recent Sessions */}
            <Card className="bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700">
              <CardHeader>
                <CardTitle className="text-slate-900 dark:text-white">Recent Mapping Sessions</CardTitle>
                <CardDescription className="text-slate-600 dark:text-slate-400">
                  Your latest contributions to the TreeView network
                </CardDescription>
              </CardHeader>
              <CardContent>
                {dashboardData?.recentSessions && dashboardData.recentSessions.length > 0 ? (
                  <div className="space-y-4">
                    {dashboardData.recentSessions.map((session) => (
                      <div 
                        key={session.id} 
                        className="flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-700/50 rounded-lg border border-slate-200 dark:border-slate-600"
                        data-testid={`session-${session.id}`}
                      >
                        <div className="flex items-center gap-4">
                          <div className="text-2xl">{getModeIcon(session.mode)}</div>
                          <div>
                            <div className="font-medium text-slate-900 dark:text-white capitalize">{session.mode} Session</div>
                            <div className="text-sm text-slate-600 dark:text-slate-400">{formatDate(session.startTime)}</div>
                          </div>
                        </div>
                        <div className="flex items-center gap-6 text-right">
                          <div>
                            <div className="text-sm font-medium text-slate-900 dark:text-white">{session.distanceKm.toFixed(1)} km</div>
                            <div className="text-xs text-slate-500 dark:text-slate-400">Distance</div>
                          </div>
                          <div>
                            <div className="text-sm font-medium text-slate-900 dark:text-white">{session.dataSizeMB.toFixed(1)} MB</div>
                            <div className="text-xs text-slate-500 dark:text-slate-400">Data</div>
                          </div>
                          <div>
                            <div className="text-sm font-medium text-slate-900 dark:text-white">{session.tokensEarned.toFixed(1)} TREEV</div>
                            <div className="text-xs text-slate-500 dark:text-slate-400">Earned</div>
                          </div>
                          <Badge 
                            variant={session.status === "completed" ? "default" : "secondary"}
                            className={session.status === "completed" ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100" : ""}
                          >
                            {session.status}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <MapPin className="h-12 w-12 text-slate-300 dark:text-slate-600 mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-slate-900 dark:text-white mb-2">No mapping sessions yet</h3>
                    <p className="text-slate-600 dark:text-slate-400">Start your first mapping session to see your progress here.</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settings" className="space-y-6">
            <Card className="bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700">
              <CardHeader>
                <CardTitle className="text-slate-900 dark:text-white">Account Settings</CardTitle>
                <CardDescription className="text-slate-600 dark:text-slate-400">
                  Manage your account preferences and security settings
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* User Info */}
                <div className="space-y-4">
                  <h3 className="text-lg font-medium text-slate-900 dark:text-white">Account Information</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label className="text-sm font-medium text-slate-700 dark:text-slate-300">Email</Label>
                      <div className="mt-1 p-3 bg-slate-50 dark:bg-slate-700 rounded-md border border-slate-200 dark:border-slate-600">
                        <span className="text-slate-900 dark:text-white">{user?.email}</span>
                      </div>
                    </div>
                    <div>
                      <Label className="text-sm font-medium text-slate-700 dark:text-slate-300">Username</Label>
                      <div className="mt-1 p-3 bg-slate-50 dark:bg-slate-700 rounded-md border border-slate-200 dark:border-slate-600">
                        <span className="text-slate-900 dark:text-white">{user?.username}</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Password Change */}
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-medium text-slate-900 dark:text-white">Password</h3>
                    {!showPasswordForm && (
                      <Button 
                        variant="outline"
                        onClick={() => setShowPasswordForm(true)}
                        className="border-slate-200 dark:border-slate-600"
                        data-testid="button-change-password"
                      >
                        Change Password
                      </Button>
                    )}
                  </div>
                  
                  {showPasswordForm && (
                    <form onSubmit={handlePasswordChange} className="space-y-4 p-4 bg-slate-50 dark:bg-slate-700 rounded-lg border border-slate-200 dark:border-slate-600">
                      <div className="space-y-2">
                        <Label htmlFor="current-password" className="text-sm font-medium text-slate-700 dark:text-slate-300">Current Password</Label>
                        <Input
                          id="current-password"
                          type="password"
                          value={passwordForm.currentPassword}
                          onChange={(e) => setPasswordForm({ ...passwordForm, currentPassword: e.target.value })}
                          className="bg-white dark:bg-slate-600 border-slate-200 dark:border-slate-500"
                          required
                          data-testid="input-current-password"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="new-password" className="text-sm font-medium text-slate-700 dark:text-slate-300">New Password</Label>
                        <Input
                          id="new-password"
                          type="password"
                          value={passwordForm.newPassword}
                          onChange={(e) => setPasswordForm({ ...passwordForm, newPassword: e.target.value })}
                          className="bg-white dark:bg-slate-600 border-slate-200 dark:border-slate-500"
                          required
                          minLength={6}
                          data-testid="input-new-password"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="confirm-new-password" className="text-sm font-medium text-slate-700 dark:text-slate-300">Confirm New Password</Label>
                        <Input
                          id="confirm-new-password"
                          type="password"
                          value={passwordForm.confirmPassword}
                          onChange={(e) => setPasswordForm({ ...passwordForm, confirmPassword: e.target.value })}
                          className="bg-white dark:bg-slate-600 border-slate-200 dark:border-slate-500"
                          required
                          data-testid="input-confirm-new-password"
                        />
                      </div>
                      <div className="flex gap-2">
                        <Button 
                          type="submit"
                          className="bg-slate-900 hover:bg-slate-800 dark:bg-slate-100 dark:hover:bg-slate-200 dark:text-slate-900"
                          data-testid="button-save-password"
                        >
                          Save Changes
                        </Button>
                        <Button 
                          type="button" 
                          variant="outline"
                          onClick={() => {
                            setShowPasswordForm(false);
                            setPasswordForm({ currentPassword: "", newPassword: "", confirmPassword: "" });
                          }}
                          className="border-slate-200 dark:border-slate-600"
                          data-testid="button-cancel-password"
                        >
                          Cancel
                        </Button>
                      </div>
                    </form>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="wallet" className="space-y-6">
            <Card className="bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700">
              <CardHeader>
                <CardTitle className="text-slate-900 dark:text-white">Wallet Management</CardTitle>
                <CardDescription className="text-slate-600 dark:text-slate-400">
                  Connect your crypto wallet to receive TVW token rewards
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Connected Wallets */}
                {dashboardData?.walletConnections && dashboardData.walletConnections.length > 0 ? (
                  <div className="space-y-4">
                    <h3 className="text-lg font-medium text-slate-900 dark:text-white">Connected Wallets</h3>
                    {dashboardData.walletConnections.map((wallet) => (
                      <div 
                        key={wallet.id} 
                        className="flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-700 rounded-lg border border-slate-200 dark:border-slate-600"
                        data-testid={`wallet-${wallet.id}`}
                      >
                        <div className="flex items-center gap-4">
                          <div className="p-2 bg-slate-100 dark:bg-slate-600 rounded-lg">
                            <Wallet className="h-5 w-5 text-slate-600 dark:text-slate-300" />
                          </div>
                          <div>
                            <div className="font-medium text-slate-900 dark:text-white capitalize">{wallet.walletType}</div>
                            <div className="text-sm text-slate-600 dark:text-slate-400 font-mono">
                              {wallet.walletAddress.slice(0, 8)}...{wallet.walletAddress.slice(-6)}
                            </div>
                          </div>
                        </div>
                        <Badge 
                          variant={wallet.isActive ? "default" : "secondary"}
                          className={wallet.isActive ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100" : ""}
                        >
                          {wallet.isActive ? "Active" : "Inactive"}
                        </Badge>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <Wallet className="h-12 w-12 text-slate-300 dark:text-slate-600 mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-slate-900 dark:text-white mb-2">No wallet connected</h3>
                    <p className="text-slate-600 dark:text-slate-400 mb-4">Connect a wallet to receive your TVW token rewards on Arbitrum network</p>
                  </div>
                )}

                {/* WalletConnect Integration */}
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-lg font-medium text-slate-900 dark:text-white">Connect Wallet</h3>
                      <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">Use WalletConnect for secure connection • Arbitrum network supported</p>
                    </div>
                    {!isConnected ? (
                      <div className="flex gap-2">
                        <Button 
                          onClick={async () => {
                            try {
                              await open();
                            } catch (error) {
                              console.error('WalletConnect error:', error);
                              toast({
                                title: "Connection Issue",
                                description: "Due to domain restrictions, please try the Manual Connect option instead.",
                                variant: "destructive",
                              });
                            }
                          }}
                          className="bg-blue-600 hover:bg-blue-700 dark:bg-blue-500 dark:hover:bg-blue-600"
                          data-testid="button-walletconnect"
                        >
                          <Wallet className="w-4 h-4 mr-2" />
                          Connect Wallet
                        </Button>
                        <Button 
                          variant="outline"
                          onClick={() => {
                            toast({
                              title: "Manual Connection Instructions",
                              description: "1) Open your wallet app (MetaMask, Trust Wallet, etc.) 2) Look for 'WalletConnect' or 'Scan QR Code' 3) If the connection modal appears, scan the code 4) Ensure you're on Arbitrum network for TVW rewards",
                              duration: 8000,
                            });
                            // Try to force open the modal
                            setTimeout(() => {
                              try {
                                open();
                              } catch (e) {
                                console.log('Manual attempt');
                              }
                            }, 1000);
                          }}
                          className="border-slate-200 dark:border-slate-600"
                          data-testid="button-manual-connect"
                        >
                          <QrCode className="w-4 h-4 mr-2" />
                          Manual Instructions
                        </Button>
                      </div>
                    ) : (
                      <div className="flex gap-2">
                        <Button 
                          variant="outline"
                          onClick={() => open({ view: 'Account' })}
                          className="border-slate-200 dark:border-slate-600"
                          data-testid="button-manage-wallet"
                        >
                          <Settings className="w-4 h-4 mr-2" />
                          Manage
                        </Button>
                        <Button 
                          variant="destructive"
                          onClick={() => disconnect()}
                          data-testid="button-disconnect-wallet"
                        >
                          Disconnect
                        </Button>
                      </div>
                    )}
                  </div>
                  
                  {isConnected && address && (
                    <div className="p-4 bg-green-50 dark:bg-green-900/20 rounded-lg border border-green-200 dark:border-green-700">
                      <div className="flex items-center gap-3">
                        <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                        <div>
                          <div className="font-medium text-green-800 dark:text-green-100">Wallet Connected</div>
                          <div className="text-sm text-green-700 dark:text-green-200 font-mono">
                            {address.slice(0, 8)}...{address.slice(-6)}
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

// Wrap the console with WagmiProvider to isolate wallet initialization
export default function Console() {
  // Initialize wallet only when Console component mounts
  const adapter = useMemo(() => {
    const walletAdapter = initializeWallet();
    if (!walletAdapter) {
      throw new Error('Failed to initialize wallet');
    }
    return walletAdapter;
  }, []);

  return (
    <WagmiProvider config={adapter.wagmiConfig}>
      <ConsoleInner />
    </WagmiProvider>
  );
}