import { useEffect, useRef } from "react";
import { MapPin, Smartphone, Satellite, Radar, CheckCircle, Clock, Lock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { useGSAP } from "@/hooks/use-gsap";
import Navigation from "@/components/navigation";

export default function Contributors() {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const [, setLocation] = useLocation();
  const { contextSafe } = useGSAP();

  useEffect(() => {
    const animateMapping = contextSafe(() => {
      if (typeof window !== 'undefined' && (window as any).gsap) {
        const gsap = (window as any).gsap;
        // Animate mapping points appearing
        gsap.fromTo(".mapping-point", 
          { scale: 0, opacity: 0 },
          { 
            scale: 1, 
            opacity: 1, 
            duration: 0.8, 
            stagger: 0.3,
            repeat: -1,
            repeatDelay: 2,
            ease: "back.out(1.7)"
          }
        );

        // Animate data flow lines
        gsap.fromTo(".data-line",
          { strokeDashoffset: 100 },
          {
            strokeDashoffset: 0,
            duration: 2,
            repeat: -1,
            ease: "none"
          }
        );

        // Floating animation for devices
        gsap.to(".device-float", {
          y: "random(-20, 20)",
          x: "random(-15, 15)",
          duration: "random(3, 5)",
          ease: "power2.inOut",
          repeat: -1,
          yoyo: true,
          stagger: 0.5
        });
      }
    });

    animateMapping();
  }, [contextSafe]);

  const roadmapPhases = [
    {
      phase: "Phase 1",
      title: "Mobile & IoT Launch",
      status: "live",
      description: "Crowdsourced mapping through mobile phones and IoT sensors",
      features: [
        "Mobile app for contributors",
        "Real-time data collection",
        "Basic reward system",
        "Community validation"
      ]
    },
    {
      phase: "Phase 2", 
      title: "First DePIN Satellite",
      status: "coming-soon",
      description: "Launch of our hybrid satellite constellation for enhanced coverage",
      features: [
        "Satellite data integration",
        "Enhanced accuracy",
        "Global coverage expansion",
        "Advanced reward mechanisms"
      ]
    },
    {
      phase: "Phase 3",
      title: "Full Network",
      status: "development",
      description: "Complete multimodal mapping infrastructure deployment",
      features: [
        "Multi-satellite constellation",
        "AI-powered data fusion",
        "Enterprise API access",
        "Decentralized governance"
      ]
    }
  ];

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'live': return <CheckCircle className="w-6 h-6 text-soft-mint" />;
      case 'coming-soon': return <Clock className="w-6 h-6 text-accent-teal" />;
      case 'development': return <Lock className="w-6 h-6 text-steel-blue" />;
      default: return null;
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'live': return 'LIVE';
      case 'coming-soon': return 'COMING SOON';
      case 'development': return 'UNDER DEVELOPMENT';
      default: return '';
    }
  };

  return (
    <div className="min-h-screen text-white font-inter overflow-x-hidden relative">
      <div className="min-h-screen bg-gradient-radial relative overflow-hidden pointcloud-bg">
        <Navigation />
      {/* Pointcloud Background Pattern */}
      <div className="absolute inset-0 opacity-25">
        <svg width="100%" height="100%" className="absolute inset-0">
          <defs>
            <pattern id="pointcloudGrid" width="60" height="60" patternUnits="userSpaceOnUse">
              <circle cx="10" cy="10" r="1" fill="var(--steel-blue)" opacity="0.6"/>
              <circle cx="30" cy="20" r="1.5" fill="var(--accent-teal)" opacity="0.4"/>
              <circle cx="50" cy="35" r="1" fill="var(--soft-mint)" opacity="0.5"/>
              <circle cx="20" cy="50" r="1" fill="var(--slate-blue)" opacity="0.3"/>
              <path d="M 60 0 L 0 0 0 60" fill="none" stroke="var(--steel-blue)" strokeWidth="0.3" opacity="0.2"/>
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#pointcloudGrid)" />
        </svg>
      </div>

      {/* World Map Animation Container */}
      <div ref={mapContainerRef} className="absolute inset-0 overflow-hidden">
        {/* Mapping Points */}
        <div className="mapping-point absolute top-1/4 left-1/4 w-3 h-3 bg-steel-blue rounded-full shadow-lg shadow-steel-blue/50"></div>
        <div className="mapping-point absolute top-1/3 right-1/4 w-3 h-3 bg-accent-teal rounded-full shadow-lg shadow-accent-teal/50"></div>
        <div className="mapping-point absolute bottom-1/3 left-1/3 w-3 h-3 bg-soft-mint rounded-full shadow-lg shadow-soft-mint/50"></div>
        <div className="mapping-point absolute top-1/2 right-1/3 w-3 h-3 bg-slate-blue rounded-full shadow-lg shadow-slate-blue/50"></div>
        <div className="mapping-point absolute bottom-1/4 right-1/4 w-3 h-3 bg-steel-blue rounded-full shadow-lg shadow-steel-blue/50"></div>

        {/* Data Flow Lines */}
        <svg className="absolute inset-0 w-full h-full">
          <line 
            x1="25%" y1="25%" x2="50%" y2="50%" 
            className="data-line" 
            stroke="var(--steel-blue)" 
            strokeWidth="2" 
            strokeDasharray="5,5"
            opacity="0.7"
          />
          <line 
            x1="75%" y1="33%" x2="50%" y2="50%" 
            className="data-line" 
            stroke="var(--accent-teal)" 
            strokeWidth="2" 
            strokeDasharray="5,5" 
            opacity="0.7"
          />
          <line 
            x1="33%" y1="67%" x2="50%" y2="50%" 
            className="data-line" 
            stroke="var(--soft-mint)" 
            strokeWidth="2" 
            strokeDasharray="5,5" 
            opacity="0.7"
          />
        </svg>

        {/* Floating Devices */}
        <div className="device-float absolute top-20 left-20">
          <Smartphone className="w-8 h-8 text-steel-blue drop-shadow-lg" />
        </div>
        <div className="device-float absolute top-40 right-32">
          <Radar className="w-10 h-10 text-accent-teal drop-shadow-lg" />
        </div>
        <div className="device-float absolute bottom-32 left-40">
          <Satellite className="w-12 h-12 text-soft-mint drop-shadow-lg" />
        </div>
        <div className="device-float absolute top-60 right-20">
          <MapPin className="w-6 h-6 text-slate-blue drop-shadow-lg" />
        </div>
      </div>

      {/* Main Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-6 py-20">
        {/* Hero Section */}
        <div className="text-center mb-20">
          <h1 className="font-orbitron text-6xl lg:text-8xl font-bold mb-8" data-testid="contributors-title">
            <span className="text-gradient">Start Mapping</span>
          </h1>
          <p className="text-2xl text-gray-300 mb-12 max-w-4xl mx-auto leading-relaxed" data-testid="contributors-description">
            Join the revolution in 4D semantic mapping. Contribute through mobile phones, IoT sensors, 
            and our groundbreaking DePIN satellite constellation. Shape the future of geospatial intelligence.
          </p>
          <Button 
            onClick={() => setLocation("/auth")}
            size="lg" 
            className="bg-gradient-to-r from-steel-blue to-accent-teal hover:from-accent-teal hover:to-soft-mint transition-all duration-300 text-white font-bold px-8 py-4 text-xl shadow-lg shadow-steel-blue/30"
            data-testid="button-start-mapping"
          >
            Start Mapping
          </Button>
        </div>

        {/* Mapping Methods */}
        <div className="grid md:grid-cols-3 gap-8 mb-20">
          <div className="glass-effect p-8 rounded-xl text-center pointcloud-bg" data-testid="card-mobile-mapping">
            <Smartphone className="w-16 h-16 text-steel-blue mx-auto mb-4 drop-shadow-lg" />
            <h3 className="text-2xl font-bold mb-4 text-gradient">Mobile Mapping</h3>
            <p className="text-gray-300">
              Use your smartphone to capture high-quality geospatial data while you move through the world.
            </p>
          </div>
          <div className="glass-effect p-8 rounded-xl text-center pointcloud-bg" data-testid="card-iot-sensors">
            <Radar className="w-16 h-16 text-accent-teal mx-auto mb-4 drop-shadow-lg" />
            <h3 className="text-2xl font-bold mb-4 text-gradient">IoT Sensors</h3>
            <p className="text-gray-300">
              Deploy specialized hardware sensors for precision data collection in urban and rural environments.
            </p>
          </div>
          <div className="glass-effect p-8 rounded-xl text-center pointcloud-bg" data-testid="card-satellite-network">
            <Satellite className="w-16 h-16 text-soft-mint mx-auto mb-4 drop-shadow-lg" />
            <h3 className="text-2xl font-bold mb-4 text-gradient">DePIN Satellites</h3>
            <p className="text-gray-300">
              Contribute to our hybrid satellite constellation for global coverage and enhanced mapping accuracy.
            </p>
          </div>
        </div>

        {/* Roadmap */}
        <div className="mb-20">
          <h2 className="font-orbitron text-4xl font-bold text-center mb-12 text-gradient" data-testid="roadmap-title">
            Development Roadmap
          </h2>
          <div className="space-y-8">
            {roadmapPhases.map((phase, index) => (
              <div 
                key={index}
                className={`glass-effect p-8 rounded-xl pointcloud-bg ${
                  phase.status === 'live' ? 'border-soft-mint border-2 shadow-lg shadow-soft-mint/20' :
                  phase.status === 'coming-soon' ? 'border-accent-teal border-2 shadow-lg shadow-accent-teal/20' :
                  'border-steel-blue border-2 shadow-lg shadow-steel-blue/20 opacity-75'
                }`}
                data-testid={`roadmap-phase-${index + 1}`}
              >
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center gap-4">
                    {getStatusIcon(phase.status)}
                    <div>
                      <h3 className="text-2xl font-bold text-gradient">{phase.phase}</h3>
                      <h4 className="text-xl text-white">{phase.title}</h4>
                    </div>
                  </div>
                  <span 
                    className={`px-4 py-2 rounded-full font-bold text-sm ${
                      phase.status === 'live' ? 'bg-soft-mint text-black shadow-lg shadow-soft-mint/30' :
                      phase.status === 'coming-soon' ? 'bg-accent-teal text-white shadow-lg shadow-accent-teal/30' :
                      'bg-steel-blue text-white shadow-lg shadow-steel-blue/30'
                    }`}
                    data-testid={`status-${phase.status}`}
                  >
                    {getStatusLabel(phase.status)}
                  </span>
                </div>
                <p className="text-gray-300 mb-6 text-lg">{phase.description}</p>
                <div className="grid md:grid-cols-2 gap-4">
                  {phase.features.map((feature, featureIndex) => (
                    <div key={featureIndex} className="flex items-center gap-3">
                      <CheckCircle className="w-5 h-5 text-soft-mint" />
                      <span className="text-gray-300">{feature}</span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* CTA Section */}
        <div className="text-center glass-effect p-12 rounded-xl pointcloud-bg">
          <h2 className="font-orbitron text-3xl font-bold mb-6 text-gradient">
            Ready to Shape the Future?
          </h2>
          <p className="text-xl text-gray-300 mb-8 max-w-3xl mx-auto">
            Join thousands of contributors already mapping the world with TreeView. 
            Earn rewards while building the next generation of geospatial intelligence.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              className="bg-gradient-to-r from-steel-blue to-accent-teal hover:from-accent-teal hover:to-soft-mint transition-all duration-300 text-white font-bold px-8 py-4 shadow-lg shadow-steel-blue/30"
              data-testid="button-download-app"
            >
              Download Mobile App
            </Button>
            <Button 
              size="lg" 
              variant="outline"
              className="border-accent-teal text-accent-teal hover:bg-accent-teal hover:text-white transition-all duration-300 px-8 py-4 shadow-lg shadow-accent-teal/20"
              data-testid="button-learn-more"
            >
              Learn More
            </Button>
          </div>
        </div>
        </div>
      </div>
    </div>
  );
}