import { createAppKit } from '@reown/appkit/react'
import { arbitrum, mainnet } from '@reown/appkit/networks'
import { WagmiAdapter } from '@reown/appkit-adapter-wagmi'

// Lazy initialization - only create wallet when needed
let wagmiAdapter: WagmiAdapter | null = null;
let initialized = false;

export function initializeWallet() {
  if (initialized) return wagmiAdapter;

  // Get WalletConnect Project ID from environment
  const projectId = import.meta.env.VITE_WALLETCONNECT_PROJECT_ID || 'd5ba8379b09961502e3496f03bac0850'

  console.log('WalletConnect Project ID:', projectId ? 'Available' : 'Missing')

  if (!projectId) {
    throw new Error('VITE_WALLETCONNECT_PROJECT_ID is required')
  }

  const metadata = {
    name: 'TreeView',
    description: 'Decentralized 3D mapping infrastructure platform',
    url: typeof window !== 'undefined' ? window.location.origin : 'https://treeview.network',
    icons: ['https://reown.com/favicon.ico']
  }

  // Create Wagmi adapter with Arbitrum network focus
  wagmiAdapter = new WagmiAdapter({
    networks: [arbitrum, mainnet],
    projectId,
    ssr: false
  })

  // Create AppKit instance
  createAppKit({
    adapters: [wagmiAdapter],
    networks: [arbitrum, mainnet],
    projectId,
    metadata,
    features: {
      analytics: false,  // Disabled analytics to prevent tracking issues
    }
  })

  initialized = true;
  return wagmiAdapter;
}

// Export getter function instead of direct adapter
export function getWagmiAdapter() {
  if (!wagmiAdapter) {
    throw new Error('Wallet not initialized. Call initializeWallet() first.');
  }
  return wagmiAdapter;
}