// Performance optimization utilities for animations and rendering

export const optimizeForDevice = () => {
  if (typeof window === 'undefined') return 'high';
  
  // Check if user prefers reduced motion
  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (prefersReducedMotion) return 'reduced';
  
  // Check device capabilities
  const userAgent = navigator.userAgent.toLowerCase();
  const isMobile = /android|webos|iphone|ipad|ipod|blackberry|iemobile|opera mini/i.test(userAgent);
  const isLowEndDevice = navigator.hardwareConcurrency && navigator.hardwareConcurrency <= 4;
  
  // Check performance hints
  const connection = (navigator as any).connection;
  const isSlowConnection = connection && (connection.effectiveType === 'slow-2g' || connection.effectiveType === '2g');
  
  if (isMobile || isLowEndDevice || isSlowConnection) {
    return 'low';
  }
  
  return 'high';
};

export const getOptimizedAnimationSettings = () => {
  const performanceLevel = optimizeForDevice();
  
  switch (performanceLevel) {
    case 'reduced':
      return {
        enableAnimations: false,
        duration: 0,
        stagger: 0,
        ease: 'none'
      };
    case 'low':
      return {
        enableAnimations: true,
        duration: 0.5,
        stagger: 0.05,
        ease: 'power2.out',
        force3D: false
      };
    case 'high':
    default:
      return {
        enableAnimations: true,
        duration: 1,
        stagger: 0.1,
        ease: 'power2.out',
        force3D: true
      };
  }
};

export const debounce = (func: Function, wait: number) => {
  let timeout: NodeJS.Timeout;
  return function executedFunction(...args: any[]) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
};

export const requestIdleCallback = (callback: Function) => {
  if (typeof window !== 'undefined' && 'requestIdleCallback' in window) {
    return (window as any).requestIdleCallback(callback);
  } else {
    return setTimeout(callback, 16);
  }
};