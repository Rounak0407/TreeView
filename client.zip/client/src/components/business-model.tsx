import { useRef } from "react";
import { Map, CheckCircle, Server } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { type Contributor } from "@shared/schema";

export default function BusinessModel() {
  const sectionRef = useRef<HTMLDivElement>(null);

  const { data: contributors } = useQuery<Contributor[]>({
    queryKey: ['/api/contributors'],
  });

  const totalContributors = contributors?.length || 0;
  const totalEarnings = contributors?.reduce((sum, c) => sum + (c.totalEarnings || 0), 0) || 0;

  return (
    <section 
      className="py-20 bg-space-black" 
      id="business"
      ref={sectionRef}
      data-testid="business-section"
    >
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="font-orbitron text-4xl lg:text-5xl font-bold mb-6 text-gradient" data-testid="business-title">
            Incentivized Ecosystem
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto" data-testid="business-description">
            Contributors earn rewards for mapping, validating, and maintaining the global spatial intelligence network.
          </p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8 mb-16">
          <div className="glass-effect p-8 rounded-xl text-center hover:border-neon-cyan transition-all" data-testid="card-mappers">
            <div className="w-16 h-16 bg-neon-cyan rounded-full flex items-center justify-center mx-auto mb-6">
              <Map className="text-space-black text-2xl" />
            </div>
            <h3 className="text-xl font-bold font-orbitron mb-4">Mappers</h3>
            <p className="text-gray-300 mb-4">
              Use smartphones, dashcams, and vehicle sensor kits to collect visual SLAM data.
            </p>
            <div className="text-neon-cyan font-bold">Earn 0.5-2.0 TVW per dataset</div>
          </div>
          
          <div className="glass-effect p-8 rounded-xl text-center hover:border-neon-green transition-all" data-testid="card-validators">
            <div className="w-16 h-16 bg-neon-green rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircle className="text-space-black text-2xl" />
            </div>
            <h3 className="text-xl font-bold font-orbitron mb-4">Validators</h3>
            <p className="text-gray-300 mb-4">
              Verify data quality and accuracy through consensus mechanisms.
            </p>
            <div className="text-neon-green font-bold">Earn 0.1-0.5 TVW per validation</div>
          </div>
          
          <div className="glass-effect p-8 rounded-xl text-center hover:border-electric-purple transition-all" data-testid="card-node-operators">
            <div className="w-16 h-16 bg-electric-purple rounded-full flex items-center justify-center mx-auto mb-6">
              <Server className="text-white text-2xl" />
            </div>
            <h3 className="text-xl font-bold font-orbitron mb-4">Node Operators</h3>
            <p className="text-gray-300 mb-4">
              Run satellite mesh stations and edge processing units for the network.
            </p>
            <div className="text-electric-purple font-bold">Earn 1.0-5.0 TVW per compute hour</div>
          </div>
        </div>
        
        {/* Real Contributor Stats */}
        {contributors && contributors.length > 0 && (
          <div className="glass-effect p-6 rounded-xl mb-8" data-testid="contributor-stats">
            <h3 className="text-xl font-bold font-orbitron mb-4 text-center">Live Network Stats</h3>
            <div className="grid md:grid-cols-3 gap-4 text-center">
              <div>
                <div className="text-2xl font-bold text-neon-cyan">{totalContributors}</div>
                <div className="text-gray-300">Active Contributors</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-neon-green">{totalEarnings.toFixed(1)} TVW</div>
                <div className="text-gray-300">Total Earnings</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-electric-purple">
                  {contributors.reduce((sum, c) => sum + (c.contributionsCount || 0), 0)}
                </div>
                <div className="text-gray-300">Total Contributions</div>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}