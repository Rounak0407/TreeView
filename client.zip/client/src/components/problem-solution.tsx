import { useEffect, useRef, useState } from "react";
import { MapPin, Zap, Users, Cpu, Satellite, Upload, Database, Globe } from "lucide-react";

export default function ProblemSolution() {
  const containerRef = useRef<HTMLDivElement>(null);
  const [showCards, setShowCards] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setShowCards(true);
        }
      },
      { threshold: 0.3 }
    );

    if (containerRef.current) {
      observer.observe(containerRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section className="py-20 bg-gradient-to-b from-deep-space to-space-black relative overflow-hidden" ref={containerRef}>

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="font-orbitron text-3xl md:text-4xl lg:text-6xl font-bold text-white mb-6">
            The <span className="text-red-400">Problem</span> & Our <span className="text-gradient">Solution</span>
          </h2>
          <p className="text-lg md:text-xl text-gray-300 max-w-3xl mx-auto">
            Current mapping systems are broken. TreeView builds the future of spatial computing.
          </p>
        </div>

        {/* Problem vs Solution Cards */}
        <div className={`grid lg:grid-cols-2 gap-8 md:gap-12 lg:gap-16 mb-20 transition-opacity duration-300 ${showCards ? 'opacity-100' : 'opacity-0'}`}>
          {/* Problem Card */}
          <div className="relative p-6 md:p-8 rounded-2xl backdrop-blur-sm border-2 border-red-400/30 bg-gradient-to-br from-red-900/20 to-red-800/10">
            <div className="text-center mb-6">
              <div className="w-16 h-16 bg-red-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <MapPin className="w-8 h-8 text-red-400" />
              </div>
              <h3 className="text-xl md:text-2xl font-bold text-red-400 mb-4 font-orbitron">Current Problems</h3>
            </div>
            
            <div className="space-y-4">
              <div className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-red-400 rounded-full mt-2 flex-shrink-0"></div>
                <p className="text-sm md:text-base text-gray-300">Existing mapping systems are <strong className="text-red-400">centralized, outdated, and inaccessible</strong></p>
              </div>
              <div className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-red-400 rounded-full mt-2 flex-shrink-0"></div>
                <p className="text-sm md:text-base text-gray-300">Spatial computing (AR, robotics, autonomous) needs <strong className="text-red-400">real-time 3D environments</strong></p>
              </div>
              <div className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-red-400 rounded-full mt-2 flex-shrink-0"></div>
                <p className="text-sm md:text-base text-gray-300">Google, Mapbox, and others <strong className="text-red-400">can't scale globally, affordably, or openly</strong></p>
              </div>
            </div>
          </div>

          {/* Solution Card */}
          <div className="relative p-6 md:p-8 rounded-2xl backdrop-blur-sm border-2 border-neon-cyan/30 bg-gradient-to-br from-cyan-900/20 to-blue-800/10">
            <div className="text-center mb-6">
              <div className="w-16 h-16 bg-cyan-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Globe className="w-8 h-8 text-neon-cyan" />
              </div>
              <h3 className="text-xl md:text-2xl font-bold text-neon-cyan mb-4 font-orbitron">Our Solution</h3>
            </div>
            
            <div className="space-y-4">
              <div className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-neon-cyan rounded-full mt-2 flex-shrink-0"></div>
                <p className="text-sm md:text-base text-gray-300">Crowd + sensor data uploaded through <strong className="text-neon-cyan">TreeView's mobile/web platform</strong></p>
              </div>
              <div className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-neon-green rounded-full mt-2 flex-shrink-0"></div>
                <p className="text-sm md:text-base text-gray-300">Data verified, processed via <strong className="text-neon-green">decentralized compute</strong> (Acurast/Render), visualized as 3D mesh</p>
              </div>
              <div className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-electric-purple rounded-full mt-2 flex-shrink-0"></div>
                <p className="text-sm md:text-base text-gray-300">Developers access data via <strong className="text-electric-purple">API and stake tokens</strong> for premium access</p>
              </div>
            </div>
          </div>
        </div>

        {/* MVP Phases */}
        <div>
          <h3 className="text-3xl font-bold text-white text-center mb-12 font-orbitron">
            MVP <span className="text-gradient">Development Phases</span>
          </h3>
          
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                phase: "Phase 1",
                title: "Mobile & Web Upload",
                description: "Video→Mesh converter + rewards dashboard",
                icon: Upload,
                color: "#06b6d4"
              },
              {
                phase: "Phase 2", 
                title: "Custom Hardware",
                description: "Affordable 3D sensors for vehicles & infrastructure",
                icon: Cpu,
                color: "#10b981"
              },
              {
                phase: "Phase 3",
                title: "Satellite Initiative", 
                description: "NFT staking funds high-altitude mesh capture stations",
                icon: Satellite,
                color: "#8b5cf6"
              }
            ].map((phase, index) => {
              const IconComponent = phase.icon;
              return (
                <div
                  key={phase.phase}
                  className="mvp-phase relative p-6 rounded-xl backdrop-blur-sm border"
                  style={{
                    background: 'linear-gradient(145deg, rgba(15, 23, 42, 0.8) 0%, rgba(30, 41, 59, 0.6) 100%)',
                    borderColor: phase.color,
                    boxShadow: `0 0 30px ${phase.color}30`
                  }}
                >
                  {/* Phase Number */}
                  <div className="absolute -top-4 left-4">
                    <div 
                      className="w-8 h-8 rounded-full flex items-center justify-center text-white font-bold text-sm"
                      style={{ backgroundColor: phase.color }}
                    >
                      {index + 1}
                    </div>
                  </div>
                  
                  <div 
                    className="w-16 h-16 rounded-xl flex items-center justify-center mb-4 mx-auto"
                    style={{ backgroundColor: phase.color }}
                  >
                    <IconComponent className="w-8 h-8 text-white" />
                  </div>
                  
                  <div className="text-center">
                    <div className="text-gray-400 text-sm font-semibold mb-1">{phase.phase}</div>
                    <h4 className="text-white font-bold text-lg mb-3">{phase.title}</h4>
                    <p className="text-gray-300 text-sm leading-relaxed">{phase.description}</p>
                  </div>
                  
                  {/* Progress Indicator */}
                  <div className="mt-4 h-1 bg-gray-700 rounded-full overflow-hidden">
                    <div 
                      className="h-full rounded-full"
                      style={{ 
                        backgroundColor: phase.color,
                        width: `${(index + 1) * 33.33}%`
                      }}
                    ></div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}