import { useState, useEffect } from "react";
import { X } from "lucide-react";
import { Button } from "@/components/ui/button";

const modalData = {
  lidar: {
    title: 'LiDAR Integration',
    content: 'High-precision point cloud data processing for detailed 3D environmental mapping with centimeter-level accuracy.'
  },
  video: {
    title: 'Video Analytics', 
    content: 'Real-time video processing for dynamic object detection, movement tracking, and behavioral analysis using computer vision.'
  },
  gps: {
    title: 'GPS & Positioning',
    content: 'Centimeter-level positioning accuracy through multi-constellation GNSS fusion and advanced signal processing.'
  },
  text: {
    title: 'Text & Metadata',
    content: 'Natural language processing for semantic understanding of location descriptions, reviews, and contextual information.'
  },
  imagery: {
    title: 'Imagery Processing',
    content: 'Computer vision algorithms for feature detection, visual SLAM capabilities, and photogrammetric reconstruction.'
  },
  'ai-fusion': {
    title: 'AI Fusion Technology',
    content: 'Advanced neural networks seamlessly integrate diverse data types including LiDAR, video, GPS, imagery, and text into unified spatial understanding with temporal awareness.'
  },
  '4d-mapping': {
    title: '4D Semantic Mapping',
    content: 'Our 4D mapping technology combines spatial coordinates with temporal data, creating living maps that understand not just where things are, but how they change over time.'
  },
  'depin': {
    title: 'Decentralized Physical Infrastructure',
    content: 'DePIN architecture distributes computational load across a network of edge devices, ensuring resilient, scalable, and community-owned mapping infrastructure.'
  }
};

export default function ModalSystem() {
  const [isOpen, setIsOpen] = useState(false);
  const [modalKey, setModalKey] = useState<string>('');

  useEffect(() => {
    const handleOpenModal = (event: CustomEvent) => {
      setModalKey(event.detail);
      setIsOpen(true);
    };

    window.addEventListener('openModal', handleOpenModal as EventListener);

    return () => {
      window.removeEventListener('openModal', handleOpenModal as EventListener);
    };
  }, []);

  const closeModal = () => {
    setIsOpen(false);
    setModalKey('');
  };

  if (!isOpen || !modalKey || !modalData[modalKey as keyof typeof modalData]) {
    return null;
  }

  const data = modalData[modalKey as keyof typeof modalData];

  return (
    <div 
      className="fixed inset-0 bg-space-black bg-opacity-90 z-50 flex items-center justify-center"
      onClick={closeModal}
      data-testid="modal-overlay"
    >
      <div 
        className="glass-effect p-8 rounded-xl max-w-2xl mx-4 relative"
        onClick={(e) => e.stopPropagation()}
        data-testid="modal-content"
      >
        <Button
          variant="ghost"
          size="icon"
          onClick={closeModal}
          className="absolute top-4 right-4 text-gray-400 hover:text-white"
          data-testid="button-close-modal"
        >
          <X size={24} />
        </Button>
        
        <h3 className="text-2xl font-bold font-orbitron mb-4 text-gradient" data-testid="modal-title">
          {data.title}
        </h3>
        <p className="text-gray-300 text-lg leading-relaxed" data-testid="modal-description">
          {data.content}
        </p>
      </div>
    </div>
  );
}
