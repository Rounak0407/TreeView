import React from 'react';

interface LogoProps {
  className?: string;
  size?: number;
}

export default function TreeViewLogo({ className = "", size = 32 }: LogoProps) {
  return (
    <div className={`flex items-center gap-2 ${className}`}>
      {/* TreeView Icon - Exact same satellite design from home page */}
      <div className="relative flex items-center justify-end" style={{ width: size * 1.8, height: size }}>
        {/* Realistic Satellite Design - Same as floating satellite */}
        <div className="relative group" style={{ marginLeft: size * 0.4 }}>
          {/* Main satellite body - cylindrical like real satellites */}
          <div 
            className="bg-gradient-to-b from-white via-green-50 to-green-200 rounded-t-lg rounded-b-sm shadow-2xl border border-green-300 relative"
            style={{ 
              width: size * 0.5, 
              height: size * 0.8
            }}
          >
            {/* Metallic panels */}
            <div 
              className="absolute bg-gradient-to-r from-green-400 to-green-300 rounded"
              style={{ 
                left: size * 0.04,
                right: size * 0.04,
                top: size * 0.08,
                height: size * 0.12
              }}
            ></div>
            <div 
              className="absolute bg-gradient-to-r from-white to-green-200 rounded"
              style={{ 
                left: size * 0.04,
                right: size * 0.04,
                top: size * 0.28,
                height: size * 0.12
              }}
            ></div>
            <div 
              className="absolute bg-gradient-to-r from-green-400 to-green-300 rounded"
              style={{ 
                left: size * 0.04,
                right: size * 0.04,
                top: size * 0.48,
                height: size * 0.12
              }}
            ></div>
            
            {/* Antenna array */}
            <div 
              className="absolute left-1/2 transform -translate-x-1/2"
              style={{ 
                top: 0,
                transform: 'translateX(-50%) translateY(-' + (size * 0.125) + 'px)'
              }}
            >
              <div 
                className="bg-green-600"
                style={{ 
                  width: size * 0.03125,
                  height: size * 0.125
                }}
              ></div>
              <div 
                className="absolute left-1/2 bg-green-700 rounded-full transform -translate-x-1/2"
                style={{ 
                  top: -size * 0.03125,
                  width: size * 0.09375,
                  height: size * 0.0625
                }}
              ></div>
            </div>

            {/* Side antennas */}
            <div 
              className="absolute bg-green-600"
              style={{ 
                top: size * 0.125,
                left: -size * 0.0625,
                width: size * 0.125,
                height: size * 0.015625
              }}
            ></div>
            <div 
              className="absolute bg-green-600"
              style={{ 
                top: size * 0.125,
                right: -size * 0.0625,
                width: size * 0.125,
                height: size * 0.015625
              }}
            ></div>
            
            {/* Solar panels - green and white theme */}
            <div 
              className="absolute bg-gradient-to-b from-green-900 via-green-800 to-green-900 rounded-sm shadow-lg border border-green-700"
              style={{ 
                left: -size * 0.32,
                top: size * 0.12,
                width: size * 0.24,
                height: size * 0.56,
                transform: 'rotate(2deg)'
              }}
            >
              <div className="grid grid-cols-3 gap-0.5 p-1 h-full">
                {[...Array(15)].map((_, i) => (
                  <div key={i} className="bg-green-700 rounded-sm opacity-80"></div>
                ))}
              </div>
            </div>
            
            <div 
              className="absolute bg-gradient-to-b from-green-900 via-green-800 to-green-900 rounded-sm shadow-lg border border-green-700"
              style={{ 
                right: -size * 0.32,
                top: size * 0.12,
                width: size * 0.24,
                height: size * 0.56,
                transform: 'rotate(-2deg)'
              }}
            >
              <div className="grid grid-cols-3 gap-0.5 p-1 h-full">
                {[...Array(15)].map((_, i) => (
                  <div key={i} className="bg-green-700 rounded-sm opacity-80"></div>
                ))}
              </div>
            </div>
            
            {/* Status lights */}
            <div 
              className="absolute bg-green-400 rounded-full animate-pulse"
              style={{ 
                top: size * 0.09375,
                right: size * 0.03125,
                width: size * 0.046875,
                height: size * 0.046875
              }}
            ></div>
            <div 
              className="absolute bg-red-400 rounded-full animate-pulse"
              style={{ 
                top: size * 0.1875,
                right: size * 0.03125,
                width: size * 0.046875,
                height: size * 0.046875,
                animationDelay: '0.5s'
              }}
            ></div>
            <div 
              className="absolute bg-blue-400 rounded-full animate-pulse"
              style={{ 
                top: size * 0.28125,
                right: size * 0.03125,
                width: size * 0.046875,
                height: size * 0.046875,
                animationDelay: '1s'
              }}
            ></div>
            
            {/* Thrusters */}
            <div 
              className="absolute left-1/2 transform -translate-x-1/2"
              style={{ 
                bottom: 0,
                transform: 'translateX(-50%) translateY(' + (size * 0.0625) + 'px)'
              }}
            >
              <div className="flex space-x-1">
                <div 
                  className="bg-gradient-to-b from-orange-400 via-red-500 to-transparent animate-pulse"
                  style={{ 
                    width: size * 0.03125,
                    height: size * 0.09375
                  }}
                ></div>
                <div 
                  className="bg-gradient-to-b from-orange-400 via-red-500 to-transparent animate-pulse"
                  style={{ 
                    width: size * 0.03125,
                    height: size * 0.09375,
                    animationDelay: '0.2s'
                  }}
                ></div>
              </div>
            </div>
            
            {/* Reflective surfaces */}
            <div 
              className="absolute bg-white/80 rounded-sm transform rotate-45"
              style={{ 
                top: size * 0.03125,
                left: size * 0.03125,
                width: size * 0.0625,
                height: size * 0.0625
              }}
            ></div>
            <div 
              className="absolute bg-white/60 rounded-sm"
              style={{ 
                bottom: size * 0.125,
                right: size * 0.03125,
                width: size * 0.03125,
                height: size * 0.03125
              }}
            ></div>
          </div>

          {/* Signal waves - space communication */}
          <div 
            className="absolute opacity-30 group-hover:opacity-50 transition-opacity duration-300"
            style={{ 
              top: -size * 0.1875,
              left: -size * 0.1875,
              right: -size * 0.1875,
              bottom: -size * 0.1875
            }}
          >
            <div className="absolute inset-0 border border-green-400 rounded-full animate-ping" style={{animationDuration: '2s'}}></div>
            <div 
              className="absolute border border-blue-400 rounded-full animate-ping"
              style={{
                inset: size * 0.0625,
                animationDuration: '2s', 
                animationDelay: '0.7s'
              }}
            ></div>
          </div>
        </div>


      </div>
      
      {/* TreeView Text - More refined typography */}
      <span 
        className="font-orbitron font-medium"
        style={{ 
          fontSize: size * 0.68,
          color: '#85E3C4',
          letterSpacing: '0.3px',
          textShadow: '0 1px 2px rgba(0,0,0,0.1)'
        }}
      >
        Tree View
      </span>
    </div>
  );
}

export function TreeViewLogoText({ className = "", size = 120 }: LogoProps) {
  return (
    <div className={`flex items-center gap-3 ${className}`}>
      <TreeViewLogo size={size * 0.4} />
      <span 
        className="font-orbitron font-bold text-star-white" 
        style={{ fontSize: size * 0.25 }}
      >
        TreeView
      </span>
    </div>
  );
}