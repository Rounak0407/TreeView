import { Github, Twitter, MessageCircle, Send } from "lucide-react";

export default function Footer() {
  const footerSections = [
    {
      title: "Platform",
      links: [
        { name: "API Documentation", href: "#" },
        { name: "SDK Downloads", href: "#" },
        { name: "Integration Guide", href: "#" },
        { name: "Status Page", href: "#" }
      ]
    },
    {
      title: "Community", 
      links: [
        { name: "Discord Server", href: "#" },
        { name: "Forums", href: "#" },
        { name: "Contributors", href: "#" },
        { name: "Governance", href: "#" }
      ]
    },
    {
      title: "Resources",
      links: [
        { name: "Whitepaper", href: "#" },
        { name: "Research", href: "#" },
        { name: "Blog", href: "#" },
        { name: "Support", href: "#" }
      ]
    }
  ];

  const socialLinks = [
    { icon: Twitter, href: "#", label: "Twitter" },
    { icon: Github, href: "#", label: "GitHub" }, 
    { icon: MessageCircle, href: "#", label: "Discord" },
    { icon: Send, href: "#", label: "Telegram" }
  ];

  return (
    <footer className="bg-darker-gray py-12 border-t border-gray-800" data-testid="footer">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid md:grid-cols-4 gap-8">
          <div>
            <div className="font-orbitron text-2xl font-bold text-gradient mb-4" data-testid="footer-logo">
              TreeView
            </div>
            <p className="text-gray-400 mb-4" data-testid="footer-description">
              Decentralized 4D semantic mapping for the future of spatial intelligence.
            </p>
            <div className="flex space-x-4">
              {socialLinks.map((social, index) => {
                const IconComponent = social.icon;
                return (
                  <a
                    key={social.label}
                    href={social.href}
                    className="text-gray-400 hover:text-neon-cyan transition-colors"
                    aria-label={social.label}
                    data-testid={`social-${social.label.toLowerCase()}`}
                  >
                    <IconComponent size={20} />
                  </a>
                );
              })}
            </div>
          </div>
          
          {footerSections.map((section, index) => (
            <div key={section.title}>
              <h4 className="font-semibold mb-4" data-testid={`footer-section-${index}`}>
                {section.title}
              </h4>
              <ul className="space-y-2 text-gray-400">
                {section.links.map((link, linkIndex) => (
                  <li key={link.name}>
                    <a 
                      href={link.href} 
                      className="hover:text-white transition-colors"
                      data-testid={`footer-link-${index}-${linkIndex}`}
                    >
                      {link.name}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        
        <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400" data-testid="footer-copyright">
          <p>© 2025 TreeView. All rights reserved. Building the future of spatial intelligence.</p>
        </div>
      </div>
    </footer>
  );
}
