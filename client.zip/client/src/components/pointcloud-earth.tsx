import { useEffect, useRef } from "react";

export default function PointcloudEarth() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number>();

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set canvas size
    const resizeCanvas = () => {
      const dpr = window.devicePixelRatio || 1;
      const rect = canvas.getBoundingClientRect();
      canvas.width = rect.width * dpr;
      canvas.height = rect.height * dpr;
      ctx.scale(dpr, dpr);
      canvas.style.width = `${rect.width}px`;
      canvas.style.height = `${rect.height}px`;
    };

    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    // Earth parameters
    const centerX = canvas.width / (2 * (window.devicePixelRatio || 1));
    const centerY = canvas.height / (2 * (window.devicePixelRatio || 1));
    const radius = Math.min(centerX, centerY) * 0.4;

    // Pointcloud parameters
    const totalPoints = 800;
    const points: Array<{
      x: number;
      y: number;
      z: number;
      originalX: number;
      originalY: number;
      originalZ: number;
      color: string;
      size: number;
      type: 'mobile' | 'iot' | 'satellite' | 'ground';
    }> = [];

    // Professional colors
    const colors = {
      steelBlue: '#4682B4',
      accentTeal: '#5F9EA0',
      softMint: '#98D982',
      slateBlue: '#5865B8'
    };

    // Generate Earth-like pointcloud
    for (let i = 0; i < totalPoints; i++) {
      // Generate points on sphere surface
      const phi = Math.acos(1 - 2 * Math.random()); // latitude
      const theta = 2 * Math.PI * Math.random(); // longitude
      
      const x = radius * Math.sin(phi) * Math.cos(theta);
      const y = radius * Math.sin(phi) * Math.sin(theta);
      const z = radius * Math.cos(phi);

      // Assign data types based on position (simulate land masses, oceans, etc.)
      let type: 'mobile' | 'iot' | 'satellite' | 'ground';
      let color: string;
      let size: number;

      if (z > radius * 0.3) {
        type = 'satellite';
        color = colors.softMint;
        size = 3;
      } else if (y > 0 && Math.abs(x) < radius * 0.5) {
        type = 'mobile';
        color = colors.steelBlue;
        size = 2;
      } else if (y < 0) {
        type = 'iot';
        color = colors.accentTeal;
        size = 2.5;
      } else {
        type = 'ground';
        color = colors.slateBlue;
        size = 1.5;
      }

      points.push({
        x, y, z,
        originalX: x,
        originalY: y,
        originalZ: z,
        color,
        size,
        type
      });
    }

    let rotationY = 0;
    let rotationX = 0;

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      // Slow rotation
      rotationY += 0.003;
      rotationX += 0.001;

      // Sort points by z-coordinate for proper depth rendering
      const rotatedPoints = points.map(point => {
        // Rotate around Y axis
        let x = point.originalX * Math.cos(rotationY) - point.originalZ * Math.sin(rotationY);
        let z = point.originalX * Math.sin(rotationY) + point.originalZ * Math.cos(rotationY);
        let y = point.originalY;

        // Rotate around X axis
        const newY = y * Math.cos(rotationX) - z * Math.sin(rotationX);
        z = y * Math.sin(rotationX) + z * Math.cos(rotationX);
        y = newY;

        return { ...point, x, y, z };
      }).sort((a, b) => a.z - b.z);

      // Draw points
      rotatedPoints.forEach(point => {
        if (point.z > -radius) { // Only draw visible points
          const projectedX = centerX + point.x;
          const projectedY = centerY + point.y;

          // Calculate opacity based on depth
          const depth = (point.z + radius) / (2 * radius);
          const opacity = 0.3 + depth * 0.7;

          // Draw point with glow effect
          ctx.save();
          ctx.globalAlpha = opacity;
          
          // Glow effect
          ctx.shadowColor = point.color;
          ctx.shadowBlur = point.size * 2;
          
          ctx.fillStyle = point.color;
          ctx.beginPath();
          ctx.arc(projectedX, projectedY, point.size * (0.5 + depth * 0.5), 0, Math.PI * 2);
          ctx.fill();
          
          ctx.restore();

          // Add data connection lines occasionally
          if (Math.random() < 0.005 && depth > 0.7) {
            const nearbyPoint = rotatedPoints.find(p => 
              p !== point && 
              Math.abs(p.x - point.x) < 30 && 
              Math.abs(p.y - point.y) < 30 &&
              p.z > -radius
            );

            if (nearbyPoint) {
              ctx.save();
              ctx.globalAlpha = opacity * 0.3;
              ctx.strokeStyle = point.color;
              ctx.lineWidth = 0.5;
              ctx.beginPath();
              ctx.moveTo(projectedX, projectedY);
              ctx.lineTo(centerX + nearbyPoint.x, centerY + nearbyPoint.y);
              ctx.stroke();
              ctx.restore();
            }
          }
        }
      });

      // Add scanning effect
      const scanTime = Date.now() * 0.002;
      const scanY = centerY + Math.sin(scanTime) * radius * 0.8;
      
      ctx.save();
      ctx.globalAlpha = 0.3;
      ctx.strokeStyle = colors.accentTeal;
      ctx.lineWidth = 2;
      ctx.setLineDash([10, 10]);
      ctx.beginPath();
      ctx.moveTo(centerX - radius, scanY);
      ctx.lineTo(centerX + radius, scanY);
      ctx.stroke();
      ctx.restore();

      animationRef.current = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      window.removeEventListener('resize', resizeCanvas);
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, []);

  return (
    <div className="absolute inset-0 overflow-hidden">
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full opacity-40"
        style={{ background: 'transparent' }}
      />
      
      {/* Subtle overlay effects */}
      <div className="absolute inset-0 bg-gradient-radial opacity-20"></div>
      
      {/* Corner data indicators */}
      <div className="absolute top-6 left-6 text-xs text-steel-blue font-mono opacity-60">
        <div>MAPPING: ACTIVE</div>
        <div>SENSORS: 847 ONLINE</div>
      </div>
      
      <div className="absolute top-6 right-6 text-xs text-accent-teal font-mono opacity-60">
        <div>COVERAGE: 67.3%</div>
        <div>RESOLUTION: 0.5M</div>
      </div>
      
      <div className="absolute bottom-6 left-6 text-xs text-soft-mint font-mono opacity-60">
        <div>SATELLITES: 12 ACTIVE</div>
        <div>UPLINK: STABLE</div>
      </div>
      
      <div className="absolute bottom-6 right-6 text-xs text-slate-blue font-mono opacity-60">
        <div>DATA RATE: 2.4 TB/S</div>
        <div>NODES: 10,847</div>
      </div>
    </div>
  );
}