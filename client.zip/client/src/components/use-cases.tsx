import { Building, Bot, CircuitBoard, Leaf } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { useGSAP } from "@/hooks/use-gsap";

export default function UseCases() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const carRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);
  const { contextSafe } = useGSAP();
  const useCases = [
    {
      icon: Building,
      title: "Urban Planning",
      description: "Real-time city insights for traffic optimization, infrastructure planning, and smart city development.",
      color: "neon-cyan",
      borderColor: "border-neon-cyan",
      textColor: "text-neon-cyan"
    },
    {
      icon: Bot,
      title: "Autonomous Robotics", 
      description: "Semantic understanding enables robots to navigate and interact with complex environments.",
      color: "neon-green",
      borderColor: "border-neon-green",
      textColor: "text-neon-green"
    },
    {
      icon: CircuitBoard,
      title: "AR Navigation",
      description: "Immersive AR experiences with precise localization and rich contextual information.",
      color: "electric-purple",
      borderColor: "border-electric-purple",
      textColor: "text-electric-purple"
    },
    {
      icon: Leaf,
      title: "Environmental Monitoring",
      description: "Track ecosystem changes, pollution levels, and climate impacts with comprehensive data fusion.",
      color: "yellow-500",
      borderColor: "border-yellow-500",
      textColor: "text-yellow-500"
    }
  ];

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.3 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    const animateCar = contextSafe(() => {
      if (isVisible && typeof window !== 'undefined' && window.gsap) {
        // Simple cards entrance animation
        window.gsap.fromTo(".application-card",
          {
            y: 50,
            opacity: 0,
            scale: 0.9
          },
          {
            y: 0,
            opacity: 1,
            scale: 1,
            duration: 0.8,
            stagger: 0.2,
            ease: "power2.out"
          }
        );

        // Continuous floating animation for cards
        window.gsap.to(".application-card",
          {
            y: "random(-8, 8)",
            duration: "random(3, 5)",
            ease: "sine.inOut",
            repeat: -1,
            yoyo: true,
            stagger: 0.3
          }
        );
      }
    });

    animateCar();
  }, [isVisible, contextSafe]);

  return (
    <section ref={sectionRef} className="py-20 bg-darker-gray relative overflow-hidden" id="features" data-testid="features-section">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="font-orbitron text-4xl lg:text-5xl font-bold mb-6 text-gradient" data-testid="features-title">
            Real-World Applications
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto" data-testid="features-description">
            Watch our 4D mapping car project real applications into the world
          </p>
        </div>

        <div className="relative">
          {/* Application Cards with Simple Animation */}
          <div className="grid lg:grid-cols-2 gap-8 relative z-20">
            {useCases.map((useCase, index) => {
              const IconComponent = useCase.icon;
              return (
                <div 
                  key={useCase.title}
                  className={`application-card p-6 rounded-lg hover:${useCase.borderColor} transition-all cursor-pointer relative`}
                  data-testid={`use-case-${index}`}
                  style={{
                    background: 'linear-gradient(145deg, rgba(15, 23, 42, 0.9) 0%, rgba(30, 41, 59, 0.8) 100%)',
                    backdropFilter: 'blur(20px)',
                    border: `2px solid ${useCase.color === 'neon-cyan' ? '#06b6d4' : useCase.color === 'neon-green' ? '#10b981' : useCase.color === 'electric-purple' ? '#8b5cf6' : '#eab308'}`,
                    borderRadius: '16px',
                    boxShadow: `0 0 40px rgba(${useCase.color === 'neon-cyan' ? '6, 182, 212' : useCase.color === 'neon-green' ? '16, 185, 129' : useCase.color === 'electric-purple' ? '139, 92, 246' : '234, 179, 8'}, 0.4), inset 0 0 20px rgba(0, 0, 0, 0.5)`
                  }}
                >
                  {/* Clean Modern Content */}
                  <div className="relative z-10">
                    <div className="flex items-center mb-4">
                      <div className={`w-14 h-14 bg-${useCase.color} rounded-xl flex items-center justify-center mr-4 shadow-xl`} style={{
                        background: `linear-gradient(135deg, ${useCase.color === 'neon-cyan' ? '#06b6d4' : useCase.color === 'neon-green' ? '#10b981' : useCase.color === 'electric-purple' ? '#8b5cf6' : '#eab308'}, ${useCase.color === 'neon-cyan' ? '#0891b2' : useCase.color === 'neon-green' ? '#059669' : useCase.color === 'electric-purple' ? '#7c3aed' : '#ca8a04'})`
                      }}>
                        <IconComponent className="text-white" size={28} />
                      </div>
                      <h3 className="text-2xl font-bold font-orbitron text-white">{useCase.title}</h3>
                    </div>
                    <p className="text-gray-300 mb-6 leading-relaxed">
                      {useCase.description}
                    </p>
                    <div className="flex items-center justify-between">
                      <div className={`${useCase.textColor} font-semibold text-lg glow-text`}>Explore →</div>
                      <div className="w-10 h-10 rounded-full border-2 border-current flex items-center justify-center hover:bg-current/20 transition-all" style={{
                        borderColor: useCase.color === 'neon-cyan' ? '#06b6d4' : useCase.color === 'neon-green' ? '#10b981' : useCase.color === 'electric-purple' ? '#8b5cf6' : '#eab308'
                      }}>
                        <span className="text-current text-lg font-bold">→</span>
                      </div>
                    </div>
                  </div>
                  
                  {/* Neon Border Glow Effect */}
                  <div className="absolute inset-0 rounded-2xl opacity-20 pointer-events-none" style={{
                    background: `linear-gradient(45deg, transparent, ${useCase.color === 'neon-cyan' ? '#06b6d4' : useCase.color === 'neon-green' ? '#10b981' : useCase.color === 'electric-purple' ? '#8b5cf6' : '#eab308'}40, transparent)`
                  }}></div>
                  
                  {/* Floating Tech Particles */}
                  <div className="absolute inset-0 pointer-events-none overflow-hidden rounded-2xl">
                    {[...Array(8)].map((_, i) => (
                      <div 
                        key={i}
                        className="absolute w-1 h-1 rounded-full animate-ping"
                        style={{
                          backgroundColor: useCase.color === 'neon-cyan' ? '#06b6d4' : useCase.color === 'neon-green' ? '#10b981' : useCase.color === 'electric-purple' ? '#8b5cf6' : '#eab308',
                          left: `${10 + Math.random() * 80}%`,
                          top: `${10 + Math.random() * 80}%`,
                          animationDelay: `${Math.random() * 3}s`,
                          animationDuration: `${2 + Math.random() * 2}s`
                        }}
                      ></div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
