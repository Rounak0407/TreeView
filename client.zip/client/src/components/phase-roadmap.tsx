import { useEffect, useRef } from "react";
import { Smartphone, Car, Satellite, Camera, MapPin } from "lucide-react";
import { useGSAP } from "@/hooks/use-gsap";

export default function PhaseRoadmap() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const networkRef = useRef<HTMLDivElement>(null);
  const { contextSafe } = useGSAP();

  useEffect(() => {
    const animatePhases = contextSafe(() => {
      if (typeof window !== 'undefined' && window.gsap && window.ScrollTrigger) {
        window.gsap.timeline({
          scrollTrigger: {
            trigger: sectionRef.current,
            start: "top 80%",
            end: "bottom 20%",
            toggleActions: "play none none reverse"
          }
        })
        .from(".phase-card", {
          x: -100,
          opacity: 0,
          duration: 0.8,
          stagger: 0.3
        });
      }
    });

    const animateNetwork = contextSafe(() => {
      if (typeof window !== 'undefined' && window.gsap && networkRef.current) {
        // Create interconnected network animation
        const tl = window.gsap.timeline({ repeat: -1, duration: 8 });
        
        // Animate satellite connections
        tl.to(".satellite-beam", {
          opacity: 1,
          duration: 0.5,
          stagger: 0.2
        })
        .to(".mobile-pulse", {
          scale: 1.5,
          opacity: 0.7,
          duration: 1,
          ease: "power2.out",
          stagger: 0.1
        }, "-=0.5")
        .to(".data-packet", {
          x: "random(-50, 50)",
          y: "random(-50, 50)",
          duration: 2,
          stagger: 0.3,
          ease: "power2.inOut"
        }, "-=1")
        .to(".mobile-pulse", {
          scale: 1,
          opacity: 1,
          duration: 0.5
        })
        .to(".satellite-beam", {
          opacity: 0.3,
          duration: 0.5
        });
      }
    });

    animatePhases();
    animateNetwork();
  }, [contextSafe]);

  const phases = [
    {
      number: "01",
      title: "Mobile Mapping",
      description: "Phone cameras and dashcam integration for crowdsourced data collection",
      icon: Smartphone,
      color: "neon-cyan",
      features: ["Android app (Kotlin)", "GPS + camera intrinsics", "Real-time upload", "Basic 3D reconstruction"]
    },
    {
      number: "02", 
      title: "Vehicle Integration",
      description: "LiDAR + stereo camera fusion with RTK GNSS for professional mapping",
      icon: Car,
      color: "neon-green", 
      features: ["Vehicle sensor kits", "LiDAR + stereo fusion", "RTK & IMU georeferencing", "Enhanced AI pipeline"]
    },
    {
      number: "03",
      title: "Satellite Mesh",
      description: "Low-Earth orbit satellite-connected mesh stations for global coverage",
      icon: Satellite,
      color: "electric-purple",
      features: ["Starlink-ready stations", "Edge processing units", "Mesh network topology", "Full decentralization"]
    }
  ];

  return (
    <section 
      className="py-20 bg-space-black" 
      id="roadmap" 
      ref={sectionRef}
      data-testid="roadmap-section"
    >
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="font-orbitron text-4xl lg:text-5xl font-bold mb-6 text-gradient" data-testid="roadmap-title">
            3-Phase Launch
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto" data-testid="roadmap-description">
            Building Earth's decentralized mapping infrastructure through progressive rollout of interconnected sensor networks.
          </p>
        </div>
        
        <div className="space-y-8 mb-16">
          {phases.map((phase, index) => {
            const IconComponent = phase.icon;
            return (
              <div 
                key={phase.number}
                className="phase-card grid md:grid-cols-3 gap-8 items-center"
                data-testid={`phase-${phase.number}`}
              >
                <div className={`glass-effect p-6 rounded-xl border-l-4 border-${phase.color}`}>
                  <div className="flex items-center mb-4">
                    <div className={`w-16 h-16 bg-${phase.color} rounded-full flex items-center justify-center mr-4`}>
                      <IconComponent className={phase.color.includes('purple') ? 'text-white' : 'text-space-black'} size={32} />
                    </div>
                    <div>
                      <div className={`text-sm font-mono text-${phase.color} mb-1`}>Phase {phase.number}</div>
                      <h3 className="text-2xl font-bold font-orbitron">{phase.title}</h3>
                    </div>
                  </div>
                  <p className="text-gray-300 mb-4">{phase.description}</p>
                </div>
                
                <div className="md:col-span-2">
                  <div className="grid sm:grid-cols-2 gap-4">
                    {phase.features.map((feature, featureIndex) => (
                      <div 
                        key={featureIndex}
                        className="glass-effect p-4 rounded-lg flex items-center"
                        data-testid={`feature-${index}-${featureIndex}`}
                      >
                        <MapPin className={`text-${phase.color} mr-3`} size={16} />
                        <span className="text-gray-300">{feature}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
        
        {/* Interconnected Network Animation */}
        <div className="glass-effect p-8 rounded-xl" data-testid="network-animation">
          <h3 className="text-2xl font-bold font-orbitron mb-8 text-center">Interconnected Sensor Network</h3>
          <div className="relative h-96 overflow-hidden" ref={networkRef}>
            {/* Satellites */}
            <div className="absolute top-4 left-1/2 transform -translate-x-1/2">
              <div className="w-12 h-12 bg-electric-purple rounded-full flex items-center justify-center animate-pulse-neon" data-testid="satellite-1">
                <Satellite className="text-white" size={20} />
              </div>
              <div className="satellite-beam absolute top-full left-1/2 w-1 h-32 bg-gradient-to-b from-electric-purple to-transparent opacity-30"></div>
            </div>
            
            <div className="absolute top-8 right-12">
              <div className="w-10 h-10 bg-electric-purple rounded-full flex items-center justify-center animate-pulse" data-testid="satellite-2">
                <Satellite className="text-white" size={16} />
              </div>
              <div className="satellite-beam absolute top-full left-1/2 w-1 h-24 bg-gradient-to-b from-electric-purple to-transparent opacity-30"></div>
            </div>
            
            {/* Mobile Devices */}
            <div className="absolute bottom-12 left-8">
              <div className="mobile-pulse w-8 h-8 bg-neon-cyan rounded-full flex items-center justify-center" data-testid="mobile-1">
                <Smartphone className="text-space-black" size={16} />
              </div>
            </div>
            
            <div className="absolute bottom-16 right-8">
              <div className="mobile-pulse w-8 h-8 bg-neon-green rounded-full flex items-center justify-center" data-testid="mobile-2">
                <Car className="text-space-black" size={16} />
              </div>
            </div>
            
            <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2">
              <div className="mobile-pulse w-8 h-8 bg-neon-cyan rounded-full flex items-center justify-center" data-testid="mobile-3">
                <Camera className="text-space-black" size={16} />
              </div>
            </div>
            
            {/* Connection paths */}
            <svg className="absolute inset-0 w-full h-full pointer-events-none">
              <defs>
                <linearGradient id="connectionGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="var(--neon-cyan)" stopOpacity="0.8"/>
                  <stop offset="100%" stopColor="var(--electric-purple)" stopOpacity="0.8"/>
                </linearGradient>
              </defs>
              
              {/* Connection lines */}
              <path 
                className="connection-path" 
                d="M 200,50 Q 300,150 400,300" 
                stroke="url(#connectionGrad)" 
                strokeWidth="2" 
                fill="none"
                opacity="0.5"
              />
              <path 
                className="connection-path" 
                d="M 600,80 Q 500,180 300,320" 
                stroke="url(#connectionGrad)" 
                strokeWidth="2" 
                fill="none"
                opacity="0.5"
              />
              <path 
                className="connection-path" 
                d="M 400,50 Q 450,200 500,340" 
                stroke="url(#connectionGrad)" 
                strokeWidth="2" 
                fill="none"
                opacity="0.5"
              />
              
              {/* Data packets */}
              <circle className="data-packet" cx="200" cy="50" r="3" fill="var(--neon-cyan)" opacity="0">
                <animate attributeName="opacity" values="0;1;0" dur="2s" repeatCount="indefinite"/>
              </circle>
              <circle className="data-packet" cx="600" cy="80" r="3" fill="var(--neon-green)" opacity="0">
                <animate attributeName="opacity" values="0;1;0" dur="2s" begin="0.5s" repeatCount="indefinite"/>
              </circle>
              <circle className="data-packet" cx="400" cy="50" r="3" fill="var(--electric-purple)" opacity="0">
                <animate attributeName="opacity" values="0;1;0" dur="2s" begin="1s" repeatCount="indefinite"/>
              </circle>
            </svg>
            
            {/* Central processing hub */}
            <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
              <div className="w-16 h-16 bg-gradient-radial border-2 border-neon-cyan rounded-full flex items-center justify-center animate-pulse-neon" data-testid="processing-hub">
                <div className="text-xs font-mono text-neon-cyan">AI</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}