import { useEffect, useRef } from "react";
import { Brain, Box, Network } from "lucide-react";
import ThreeGlobe from "./three-globe";
import { useGSAP } from "@/hooks/use-gsap";

export default function CoreTechnology() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const { contextSafe } = useGSAP();

  // Simple fade-in animation on mount
  useEffect(() => {
    const animateCards = contextSafe(() => {
      const checkGSAP = () => {
        if (typeof window !== 'undefined' && (window as any).gsap && sectionRef.current) {
          const gsap = (window as any).gsap;
          const cards = sectionRef.current!.querySelectorAll('.tech-card');
          
          if (cards.length > 0) {
            // Simple fade-in animation
            gsap.fromTo(cards, 
              {
                opacity: 0,
                y: 20
              },
              {
                opacity: 1,
                y: 0,
                duration: 0.8,
                stagger: 0.2,
                delay: 0.5
              }
            );
          }
        } else {
          setTimeout(checkGSAP, 100);
        }
      };
      
      checkGSAP();
    });

    animateCards();
  }, [contextSafe]);

  const handleTechCardClick = (modalType: string) => {
    const event = new CustomEvent('openModal', { detail: modalType });
    window.dispatchEvent(event);
  };

  return (
    <section 
      className="py-20 bg-cosmic-blue relative pointcloud-bg" 
      id="technology"
      ref={sectionRef}
      data-testid="technology-section"
    >
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="font-orbitron text-4xl lg:text-5xl font-bold mb-6 text-gradient" data-testid="technology-title">
            Core Technology
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto" data-testid="technology-description">
            Custom visual SLAM pipeline, hybrid sensor fusion, and satellite mesh stations 
            creating Earth's first decentralized 3D mapping infrastructure.
          </p>
        </div>
        
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* 3D Globe Container */}
          <div className="relative">
            <div className="w-full h-96 bg-gradient-radial rounded-xl neon-border" data-testid="globe-container">
              <ThreeGlobe />
            </div>
            <div className="absolute top-4 left-4 glass-effect p-3 rounded-lg" data-testid="data-stats">
              <div className="text-sm text-gray-300">Real-time Data Streams</div>
              <div className="text-2xl font-bold text-neon-cyan">2.4M+</div>
            </div>
          </div>
          
          {/* TreeView AI Engine & 4D Spatial World Demonstration */}
          <div className="max-w-6xl mx-auto">
            <div className="relative glass-effect rounded-2xl p-4 md:p-8 overflow-hidden">
              {/* Cinematic Background */}
              <div className="absolute inset-0 bg-gradient-to-br from-space-black via-blue-900/30 to-purple-900/30"></div>
              
              {/* Main Video Content */}
              <div className="relative z-10">
                <div className="text-center mb-6 md:mb-8">
                  <h3 className="text-xl md:text-2xl font-bold font-orbitron text-neon-cyan mb-2">TreeView AI Engine: 4D Spatial World Vision</h3>
                  <p className="text-gray-300 text-sm md:text-base">Real-time environmental scanning with complete spatial metadata reconstruction</p>
                </div>
                
                {/* Integrated Multi-Platform Scanning Video */}
                <div className="relative bg-black/70 rounded-xl p-4 md:p-6 border border-neon-cyan/40 mb-6">
                  {/* Main Scanning Environment */}
                  <div className="relative h-64 md:h-96 bg-gradient-to-br from-gray-900 via-blue-900/20 to-purple-900/20 rounded-lg overflow-hidden border-2 border-neon-cyan/30">
                    
                    {/* Urban Environment Scene */}
                    <div className="absolute inset-0">
                      {/* Sky and Background */}
                      <div className="absolute top-0 left-0 right-0 h-20 bg-gradient-to-b from-blue-900/30 to-transparent"></div>
                      
                      {/* Buildings */}
                      <div className="absolute bottom-0 left-12 w-20 h-32 bg-gradient-to-t from-gray-700 to-gray-500">
                        <div className="absolute top-4 left-3 w-3 h-4 bg-yellow-400/60 animate-pulse"></div>
                        <div className="absolute top-8 right-2 w-3 h-4 bg-yellow-400/40 animate-pulse" style={{animationDelay: '0.5s'}}></div>
                        <div className="absolute top-16 left-1 w-3 h-4 bg-blue-400/60 animate-pulse" style={{animationDelay: '1s'}}></div>
                      </div>
                      <div className="absolute bottom-0 right-16 w-24 h-40 bg-gradient-to-t from-gray-600 to-gray-400">
                        <div className="absolute top-6 left-4 w-3 h-4 bg-blue-400/60 animate-pulse" style={{animationDelay: '0.8s'}}></div>
                        <div className="absolute top-12 right-3 w-3 h-4 bg-blue-400/40 animate-pulse" style={{animationDelay: '1.2s'}}></div>
                        <div className="absolute top-20 left-2 w-3 h-4 bg-yellow-400/50 animate-pulse" style={{animationDelay: '1.8s'}}></div>
                      </div>
                      
                      {/* Street Infrastructure */}
                      <div className="absolute bottom-0 left-32 w-3 h-20 bg-gray-500">
                        {/* Street Lamp with Scanner Hardware */}
                        <div className="absolute -top-6 -left-3 w-9 h-6 bg-gray-300 rounded border border-gray-400">
                          {/* Scanner Box */}
                          <div className="absolute top-1 left-1 w-2 h-2 bg-blue-600 rounded animate-pulse"></div>
                          <div className="absolute top-1 right-1 w-2 h-2 bg-green-600 rounded animate-pulse" style={{animationDelay: '0.3s'}}></div>
                          <div className="absolute bottom-1 left-1/2 w-3 h-1 bg-red-500/80 rounded transform -translate-x-1/2 animate-ping"></div>
                        </div>
                        {/* Light fixture */}
                        <div className="absolute -top-4 -left-2 w-7 h-4 bg-yellow-500/80 rounded animate-pulse">
                          <div className="absolute top-1 left-1 w-1 h-1 bg-yellow-200 rounded-full"></div>
                          <div className="absolute top-1 right-1 w-1 h-1 bg-yellow-200 rounded-full"></div>
                        </div>
                        {/* Multiple Scanning Beams from Street Lamp */}
                        <div className="absolute -top-4 left-1/2 w-24 h-0.5 bg-neon-cyan/60 transform -translate-x-1/2 animate-pulse origin-left"></div>
                        <div className="absolute -top-3 left-1/2 w-28 h-0.5 bg-neon-green/40 transform -translate-x-1/2 animate-pulse origin-left" style={{animationDelay: '0.5s'}}></div>
                        <div className="absolute -top-2 left-1/2 w-20 h-0.5 bg-blue-400/50 transform -translate-x-1/2 animate-pulse origin-left" style={{animationDelay: '1s'}}></div>
                      </div>
                      
                      {/* Road */}
                      <div className="absolute bottom-0 left-0 right-0 h-10 bg-gradient-to-r from-gray-600 via-gray-500 to-gray-600">
                        <div className="absolute top-1/2 left-1/4 w-20 h-0.5 bg-yellow-300/60"></div>
                        <div className="absolute top-1/2 right-1/4 w-20 h-0.5 bg-yellow-300/60"></div>
                      </div>
                      
                      {/* Trees */}
                      <div className="absolute bottom-0 left-48 w-5 h-18 bg-green-700 rounded-t-full">
                        <div className="absolute -top-3 -left-3 w-11 h-11 bg-green-600/80 rounded-full animate-sway"></div>
                      </div>
                      <div className="absolute bottom-0 right-32 w-4 h-16 bg-green-800 rounded-t-full">
                        <div className="absolute -top-2 -left-2 w-8 h-8 bg-green-700/80 rounded-full animate-sway" style={{animationDelay: '0.3s'}}></div>
                      </div>
                    </div>
                    
                    {/* Moving Satellite */}
                    <div className="absolute top-8 left-0 w-full h-full pointer-events-none">
                      <div className="relative w-full h-full animate-satellite-path">
                        <div className="absolute top-4 left-8 w-8 h-6 bg-gradient-to-r from-gray-300 to-gray-100 rounded transform rotate-12">
                          {/* Satellite Body */}
                          <div className="absolute -left-2 top-1 w-2 h-4 bg-blue-400 rounded"></div>
                          <div className="absolute -right-2 top-1 w-2 h-4 bg-blue-400 rounded"></div>
                          <div className="absolute top-2 left-2 w-1 h-1 bg-red-500 rounded-full animate-ping"></div>
                          <div className="absolute top-2 right-2 w-1 h-1 bg-green-500 rounded-full animate-ping" style={{animationDelay: '0.5s'}}></div>
                          {/* Scanning Beam from Satellite */}
                          <div className="absolute top-6 left-1/2 w-32 h-32 border border-neon-cyan/30 rounded-full animate-ping"></div>
                          <div className="absolute top-8 left-1/2 w-40 h-40 border border-neon-cyan/20 rounded-full animate-ping" style={{animationDelay: '0.7s'}}></div>
                        </div>
                      </div>
                    </div>
                    
                    {/* Moving Car with Scanner */}
                    <div className="absolute bottom-10 left-0 w-full h-full pointer-events-none">
                      <div className="relative w-full h-full animate-car-drive">
                        <div className="absolute bottom-0 left-8 w-12 h-6 bg-gradient-to-r from-blue-600 to-blue-500 rounded shadow-lg">
                          {/* Car Body Details */}
                          <div className="absolute -bottom-2 left-1 w-2 h-2 bg-gray-800 rounded-full border border-gray-600"></div>
                          <div className="absolute -bottom-2 right-1 w-2 h-2 bg-gray-800 rounded-full border border-gray-600"></div>
                          <div className="absolute top-1 left-2 w-2 h-1 bg-cyan-400/80 rounded"></div>
                          <div className="absolute top-1 right-2 w-2 h-1 bg-cyan-400/80 rounded"></div>
                          <div className="absolute top-2 left-1/2 w-1 h-1 bg-white/60 rounded-full transform -translate-x-1/2"></div>
                          
                          {/* Advanced Scanner Kit on Car Roof */}
                          <div className="absolute -top-5 left-1/2 w-6 h-4 bg-gray-200 rounded border border-gray-400 transform -translate-x-1/2">
                            {/* LiDAR Spinning Unit */}
                            <div className="absolute top-0 left-1/2 w-2 h-2 bg-green-600 rounded-full animate-spin transform -translate-x-1/2"></div>
                            {/* Camera Array */}
                            <div className="absolute top-1 left-0 w-1 h-1 bg-blue-600 rounded-full animate-pulse"></div>
                            <div className="absolute top-1 right-0 w-1 h-1 bg-blue-600 rounded-full animate-pulse" style={{animationDelay: '0.2s'}}></div>
                            {/* GPS Antenna */}
                            <div className="absolute bottom-0 left-1/2 w-0.5 h-1 bg-yellow-500 transform -translate-x-1/2"></div>
                            {/* Sensor Status Lights */}
                            <div className="absolute bottom-0 left-1 w-0.5 h-0.5 bg-red-500 rounded-full animate-ping"></div>
                            <div className="absolute bottom-0 right-1 w-0.5 h-0.5 bg-green-500 rounded-full animate-ping" style={{animationDelay: '0.3s'}}></div>
                          </div>
                          
                          {/* Multiple Scanner Beams */}
                          <div className="absolute -top-3 left-1/2 w-24 h-0.5 bg-neon-green/70 transform -translate-x-1/2 animate-pulse"></div>
                          <div className="absolute -top-2 left-1/2 w-20 h-0.5 bg-blue-400/60 transform -translate-x-1/2 animate-pulse" style={{animationDelay: '0.4s'}}></div>
                          <div className="absolute -top-1 left-1/2 w-16 h-0.5 bg-purple-400/50 transform -translate-x-1/2 animate-pulse" style={{animationDelay: '0.8s'}}></div>
                        </div>
                      </div>
                    </div>
                    
                    {/* Enhanced LiDAR Point Cloud Effect */}
                    <div className="absolute inset-0">
                      {[...Array(150)].map((_, i) => (
                        <div 
                          key={i}
                          className={`absolute w-1 h-1 rounded-full animate-ping ${
                            i % 3 === 0 ? 'bg-neon-green' : 
                            i % 3 === 1 ? 'bg-blue-400' : 'bg-purple-400'
                          }`}
                          style={{
                            left: `${5 + Math.random() * 90}%`,
                            top: `${15 + Math.random() * 70}%`,
                            animationDelay: `${Math.random() * 3}s`,
                            animationDuration: `${0.6 + Math.random() * 0.6}s`
                          }}
                        ></div>
                      ))}
                    </div>
                    
                    {/* Depth Lines for 3D Effect */}
                    <div className="absolute inset-0">
                      {[...Array(20)].map((_, i) => (
                        <div 
                          key={`line${i}`}
                          className="absolute h-0.5 bg-gradient-to-r from-transparent via-neon-cyan/30 to-transparent animate-pulse"
                          style={{
                            left: `${10 + Math.random() * 80}%`,
                            top: `${20 + Math.random() * 60}%`,
                            width: `${10 + Math.random() * 30}%`,
                            animationDelay: `${Math.random() * 2}s`,
                            transform: `rotate(${Math.random() * 180}deg)`
                          }}
                        ></div>
                      ))}
                    </div>
                    
                    {/* Object Detection Overlays */}
                    <div className="absolute top-16 left-12 w-20 h-32 border-2 border-yellow-400/80 rounded">
                      <div className="absolute -top-6 left-0 bg-yellow-400/90 text-black text-xs px-2 py-1 rounded font-mono">
                        BUILDING: 98.7%
                      </div>
                    </div>
                    <div className="absolute top-20 right-16 w-24 h-40 border-2 border-blue-400/80 rounded">
                      <div className="absolute -top-6 right-0 bg-blue-400/90 text-black text-xs px-2 py-1 rounded font-mono">
                        STRUCTURE: 96.3%
                      </div>
                    </div>
                    <div className="absolute bottom-18 left-48 w-8 h-18 border-2 border-green-400/80 rounded">
                      <div className="absolute -top-6 left-0 bg-green-400/90 text-black text-xs px-1 py-1 rounded font-mono">
                        TREE: 99.5%
                      </div>
                    </div>
                    <div className="absolute bottom-10 left-8 w-12 h-6 border-2 border-cyan-400/80 rounded">
                      <div className="absolute -top-6 left-0 bg-cyan-400/90 text-black text-xs px-1 py-1 rounded font-mono">
                        VEHICLE: 97.1%
                      </div>
                    </div>
                    
                    {/* Real-time Data Overlay */}
                  </div>
                </div>
                

                {/* Vision Statement */}
                <div className="text-center bg-gradient-to-r from-neon-cyan/10 via-neon-green/10 to-electric-purple/10 rounded-lg p-4 border border-neon-cyan/20">
                  <h4 className="font-bold text-neon-cyan mb-2 text-sm md:text-base">Our Vision: Complete 4D Spatial World</h4>
                  <p className="text-gray-300 text-xs md:text-sm">
                    Every surface, every object, every movement captured with millimeter precision in real-time. 
                    A living, breathing digital twin of Earth where physical and digital worlds converge seamlessly.
                  </p>
                </div>
              </div>
              
              {/* Environmental Particles */}
              <div className="absolute inset-0 overflow-hidden pointer-events-none">
                {[...Array(25)].map((_, i) => (
                  <div 
                    key={i}
                    className="absolute w-0.5 h-0.5 bg-neon-cyan/40 rounded-full animate-drift"
                    style={{
                      left: `${Math.random() * 100}%`,
                      top: `${Math.random() * 100}%`,
                      animationDelay: `${Math.random() * 5}s`,
                      animationDuration: `${3 + Math.random() * 4}s`
                    }}
                  ></div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
