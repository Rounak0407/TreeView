import { useEffect, useRef, useState } from "react";
import { Satellite, Smartphone, Car, Camera, Navigation, Wifi } from "lucide-react";

export default function AnimatedNetwork() {
  const networkRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.2 }
    );

    if (networkRef.current) {
      observer.observe(networkRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section className="py-20 bg-darker-gray relative overflow-hidden z-30" data-testid="animated-network">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="font-orbitron text-4xl lg:text-5xl font-bold mb-6 text-gradient" data-testid="network-title">
            Live Sensor Network
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto" data-testid="network-description">
            Watch our decentralized mapping infrastructure in action with satellites, mobile sensors, and mesh stations.
          </p>
        </div>
        
        <div className={`relative h-96 lg:h-[500px] transition-all duration-1000 ${isVisible ? 'opacity-100' : 'opacity-0'}`} ref={networkRef}>
          {/* Satellites orbiting - positioned using percentages */}
          <div className="absolute animate-orbit" style={{ top: '16%', left: '50%' }} data-testid="satellite-1">
            <div className="w-10 md:w-12 h-10 md:h-12 bg-electric-purple rounded-full flex items-center justify-center animate-pulse-neon">
              <Satellite className="text-white" size={16} />
            </div>
          </div>
          
          <div className="absolute animate-orbit" style={{ top: '24%', right: '20%', animationDelay: '15s' }} data-testid="satellite-2">
            <div className="w-8 md:w-10 h-8 md:h-10 bg-electric-purple rounded-full flex items-center justify-center animate-pulse">
              <Satellite className="text-white" size={14} />
            </div>
          </div>

          {/* Mobile sensors floating with staggered animations */}
          <div className="absolute animate-float" style={{ bottom: '40%', left: '15%', animationDelay: '0s' }} data-testid="mobile-phone">
            <div className="w-8 md:w-10 h-8 md:h-10 bg-neon-cyan rounded-full flex items-center justify-center relative">
              <Smartphone className="text-space-black" size={14} />
              <div className="absolute inset-0 rounded-full border-2 border-neon-cyan animate-ping opacity-30"></div>
            </div>
          </div>
          
          <div className="absolute animate-float" style={{ bottom: '24%', right: '25%', animationDelay: '2s' }} data-testid="mobile-vehicle">
            <div className="w-10 md:w-12 h-10 md:h-12 bg-neon-green rounded-full flex items-center justify-center relative">
              <Car className="text-space-black" size={16} />
              <div className="absolute inset-0 rounded-full border-2 border-neon-green animate-ping opacity-30"></div>
            </div>
          </div>
          
          <div className="absolute animate-float" style={{ bottom: '32%', left: '33%', animationDelay: '4s' }} data-testid="mobile-camera">
            <div className="w-8 md:w-9 h-8 md:h-9 bg-yellow-500 rounded-full flex items-center justify-center relative">
              <Camera className="text-space-black" size={12} />
              <div className="absolute inset-0 rounded-full border-2 border-yellow-500 animate-ping opacity-30"></div>
            </div>
          </div>

          <div className="absolute animate-float" style={{ bottom: '48%', right: '33%', animationDelay: '6s' }} data-testid="mobile-nav">
            <div className="w-7 md:w-8 h-7 md:h-8 bg-pink-500 rounded-full flex items-center justify-center relative">
              <Navigation className="text-white" size={11} />
              <div className="absolute inset-0 rounded-full border-2 border-pink-500 animate-ping opacity-30"></div>
            </div>
          </div>

          {/* Central AI processing hub */}
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2" data-testid="ai-hub">
            <div className="w-16 md:w-20 h-16 md:h-20 bg-gradient-radial border-2 md:border-3 border-neon-cyan rounded-full flex items-center justify-center animate-glow relative">
              <div className="text-xs md:text-sm font-mono text-neon-cyan font-bold">AI</div>
              {/* Simplified rotating indicator */}
              <div className="absolute inset-0 border-2 border-dotted border-cyan-400 rounded-full animate-spin opacity-40"></div>
            </div>
          </div>

          {/* Mesh stations */}
          <div className="absolute animate-pulse" style={{ top: '33%', left: '10%', animationDelay: '1s' }} data-testid="mesh-station-1">
            <div className="w-5 md:w-6 h-5 md:h-6 bg-orange-500 rounded-full flex items-center justify-center">
              <Wifi className="text-white" size={10} />
            </div>
          </div>
          
          <div className="absolute animate-pulse" style={{ top: '66%', right: '15%', animationDelay: '3s' }} data-testid="mesh-station-2">
            <div className="w-5 md:w-6 h-5 md:h-6 bg-orange-500 rounded-full flex items-center justify-center">
              <Wifi className="text-white" size={10} />
            </div>
          </div>

          {/* Simplified connection lines for better performance */}
          <svg 
            className="absolute inset-0 w-full h-full pointer-events-none opacity-40" 
            viewBox="0 0 100 100" 
            preserveAspectRatio="xMidYMid meet"
          >
            <defs>
              <linearGradient id="simpleGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#06b6d4" stopOpacity="0.6"/>
                <stop offset="100%" stopColor="#8b5cf6" stopOpacity="0.4"/>
              </linearGradient>
            </defs>
            
            {/* Central hub connections - static lines for performance */}
            <line x1="50" y1="50" x2="50" y2="20" stroke="url(#simpleGradient)" strokeWidth="0.5" opacity="0.6"/>
            <line x1="50" y1="50" x2="20" y2="75" stroke="url(#simpleGradient)" strokeWidth="0.5" opacity="0.5"/>
            <line x1="50" y1="50" x2="80" y2="65" stroke="url(#simpleGradient)" strokeWidth="0.5" opacity="0.5"/>
            <line x1="50" y1="50" x2="35" y2="80" stroke="url(#simpleGradient)" strokeWidth="0.5" opacity="0.4"/>
            <line x1="50" y1="50" x2="65" y2="80" stroke="url(#simpleGradient)" strokeWidth="0.5" opacity="0.4"/>
          </svg>
        </div>
        
        {/* Live stats - responsive and animated entrance */}
        <div className={`grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6 mt-12 transition-all duration-1000 delay-500 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}>
          <div className="text-center glass-effect p-3 md:p-4 rounded-lg transition-transform duration-300 hover:scale-105">
            <div className="text-lg md:text-2xl font-bold text-electric-purple mb-1">3</div>
            <div className="text-xs md:text-sm text-gray-400">Satellites Active</div>
          </div>
          <div className="text-center glass-effect p-3 md:p-4 rounded-lg transition-transform duration-300 hover:scale-105">
            <div className="text-lg md:text-2xl font-bold text-neon-cyan mb-1">1.2K</div>
            <div className="text-xs md:text-sm text-gray-400">Mobile Sensors</div>
          </div>
          <div className="text-center glass-effect p-3 md:p-4 rounded-lg transition-transform duration-300 hover:scale-105">
            <div className="text-lg md:text-2xl font-bold text-neon-green mb-1">247</div>
            <div className="text-xs md:text-sm text-gray-400">Mesh Stations</div>
          </div>
          <div className="text-center glass-effect p-3 md:p-4 rounded-lg transition-transform duration-300 hover:scale-105">
            <div className="text-lg md:text-2xl font-bold text-yellow-500 mb-1">Live</div>
            <div className="text-xs md:text-sm text-gray-400">Data Streaming</div>
          </div>
        </div>
      </div>
    </section>
  );
}