import React, { useEffect, useRef, useState } from "react";
import { useInView } from "@/hooks/use-gsap";
import { Coins, TrendingUp, Users, Building, Shield, Globe } from "lucide-react";
import { getOptimizedAnimationSettings } from "@/utils/performance";

interface TokenAllocation {
  label: string;
  percentage: number;
  amount: string;
  color: string;
  icon: any;
  description: string;
}

const allocations: TokenAllocation[] = [
  {
    label: "Contributors",
    percentage: 40,
    amount: "396M",
    color: "#06b6d4", // neon-cyan
    icon: Users,
    description: "Rewards for data contributors and validators"
  },
  {
    label: "Ecosystem/Grants",
    percentage: 15,
    amount: "148.5M",
    color: "#10b981", // neon-green
    icon: Globe,
    description: "Developer grants and ecosystem growth"
  },
  {
    label: "Team + Advisors",
    percentage: 15,
    amount: "148.5M",
    color: "#8b5cf6", // electric-purple
    icon: Building,
    description: "Core team and strategic advisors"
  },
  {
    label: "Investors",
    percentage: 15,
    amount: "148.5M",
    color: "#eab308", // neon-yellow
    icon: TrendingUp,
    description: "Private and strategic investors"
  },
  {
    label: "DAO Treasury",
    percentage: 10,
    amount: "99M",
    color: "#f97316", // orange
    icon: Shield,
    description: "Community governance and operations"
  },
  {
    label: "Reserves",
    percentage: 5,
    amount: "49.5M",
    color: "#ef4444", // red
    icon: Coins,
    description: "Emergency reserves and liquidity"
  }
];

export default function Tokenomics() {
  const containerRef = useRef<HTMLDivElement>(null);
  const isVisible = useInView(containerRef);
  const [animationStarted, setAnimationStarted] = useState(false);

  useEffect(() => {
    if (isVisible && !animationStarted && typeof window !== 'undefined' && (window as any).gsap && containerRef.current) {
      setAnimationStarted(true);
      
      const gsap = (window as any).gsap;
      const container = containerRef.current;
      
      // Use scoped animations for better performance
      const titleEl = container.querySelector(".tokenomics-title");
      const globeEl = container.querySelector(".tokenomics-globe");
      const legendEls = container.querySelectorAll(".allocation-legend");
      const cardEls = container.querySelectorAll(".utility-card");
      
      // Animate title with force3D
      if (titleEl) {
        gsap.fromTo(titleEl, 
          { y: 30, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.8, ease: "power2.out", force3D: true }
        );
      }

      // Animate globe container with optimized settings
      if (globeEl) {
        gsap.fromTo(globeEl, 
          { scale: 0.8, opacity: 0 },
          { scale: 1, opacity: 1, duration: 1, delay: 0.2, ease: "back.out(1.2)", force3D: true }
        );
      }

      // Animate allocation legend with reduced motion
      if (legendEls.length > 0) {
        gsap.fromTo(legendEls, 
          { y: 20, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.6, delay: 0.4, stagger: 0.08, ease: "power2.out" }
        );
      }

      // Animate utility cards if they exist
      if (cardEls.length > 0) {
        gsap.fromTo(cardEls, 
          { y: 15, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.6, delay: 0.8, stagger: 0.05, ease: "power2.out" }
        );
      }
    }
  }, [isVisible, animationStarted]);

  // Calculate cumulative percentages for pie chart
  const cumulativePercentages = allocations.reduce((acc, allocation, index) => {
    const prev = index > 0 ? acc[index - 1] : 0;
    acc.push(prev + allocation.percentage);
    return acc;
  }, [] as number[]);

  // Create modern 3D donut pie slice
  const createPieSlice = (allocation: TokenAllocation, index: number) => {
    const start = index > 0 ? cumulativePercentages[index - 1] : 0;
    const end = cumulativePercentages[index];
    const startAngle = (start / 100) * 360 - 90;
    const endAngle = (end / 100) * 360 - 90;
    
    const outerRadius = 42;
    const innerRadius = 16;
    
    const startOuterX = 50 + outerRadius * Math.cos((startAngle * Math.PI) / 180);
    const startOuterY = 50 + outerRadius * Math.sin((startAngle * Math.PI) / 180);
    const endOuterX = 50 + outerRadius * Math.cos((endAngle * Math.PI) / 180);
    const endOuterY = 50 + outerRadius * Math.sin((endAngle * Math.PI) / 180);
    
    const startInnerX = 50 + innerRadius * Math.cos((startAngle * Math.PI) / 180);
    const startInnerY = 50 + innerRadius * Math.sin((startAngle * Math.PI) / 180);
    const endInnerX = 50 + innerRadius * Math.cos((endAngle * Math.PI) / 180);
    const endInnerY = 50 + innerRadius * Math.sin((endAngle * Math.PI) / 180);
    
    const largeArcFlag = allocation.percentage > 50 ? 1 : 0;
    
    return `M ${startOuterX},${startOuterY} A ${outerRadius},${outerRadius} 0 ${largeArcFlag},1 ${endOuterX},${endOuterY} L ${endInnerX},${endInnerY} A ${innerRadius},${innerRadius} 0 ${largeArcFlag},0 ${startInnerX},${startInnerY} Z`;
  };

  // Create 3D depth effect for bottom edge
  const create3DDepth = (allocation: TokenAllocation, index: number) => {
    const start = index > 0 ? cumulativePercentages[index - 1] : 0;
    const end = cumulativePercentages[index];
    const startAngle = (start / 100) * 360 - 90;
    const endAngle = (end / 100) * 360 - 90;
    
    const outerRadius = 42;
    const depth = 4;
    
    // Only show depth for bottom-facing slices
    if (startAngle < 90 && endAngle > 90) {
      const startOuterX = 50 + outerRadius * Math.cos((startAngle * Math.PI) / 180);
      const startOuterY = 50 + outerRadius * Math.sin((startAngle * Math.PI) / 180);
      const endOuterX = 50 + outerRadius * Math.cos((endAngle * Math.PI) / 180);
      const endOuterY = 50 + outerRadius * Math.sin((endAngle * Math.PI) / 180);
      
      const largeArcFlag = allocation.percentage > 50 ? 1 : 0;
      
      return `M ${startOuterX},${startOuterY} A ${outerRadius},${outerRadius} 0 ${largeArcFlag},1 ${endOuterX},${endOuterY} L ${endOuterX},${endOuterY + depth} A ${outerRadius},${outerRadius} 0 ${largeArcFlag},0 ${startOuterX},${startOuterY + depth} Z`;
    }
    return '';
  };

  return (
    <section className="py-20 bg-gradient-to-b from-space-black to-deep-space relative overflow-hidden" ref={containerRef}>
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        {[...Array(50)].map((_, i) => (
          <div
            key={i}
            className="absolute w-1 h-1 bg-neon-cyan rounded-full animate-ping"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 5}s`,
              animationDuration: `${2 + Math.random() * 3}s`
            }}
          />
        ))}
      </div>

      <div className="max-w-7xl mx-auto px-6">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="tokenomics-title font-orbitron text-4xl lg:text-6xl font-bold text-white mb-6">
            <span className="text-gradient">Tokenomics</span>
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            TreeView's token economy designed for sustainable growth and community ownership of Earth's 3D mapping infrastructure
          </p>
        </div>

        {/* Interactive Earth Globe Pie Chart - Full Width */}
        <div className="tokenomics-globe relative max-w-4xl mx-auto z-20">
          <div className="relative w-full max-w-2xl mx-auto aspect-square z-20">
            {/* Globe Base */}
            <div className="absolute inset-0 rounded-full bg-gradient-to-br from-blue-600/40 via-blue-500/30 to-blue-800/40 shadow-2xl z-10">
              {/* Continents overlay */}
              <div className="absolute top-[15%] left-[20%] w-[15%] h-[20%] bg-green-600/30 rounded-lg transform rotate-12"></div>
              <div className="absolute top-[10%] left-[10%] w-[12%] h-[18%] bg-green-700/25 rounded-xl transform -rotate-12"></div>
              <div className="absolute top-[8%] right-[15%] w-[18%] h-[12%] bg-green-600/35 rounded-2xl transform rotate-45"></div>
              <div className="absolute bottom-[15%] left-[25%] w-[8%] h-[20%] bg-green-700/30 rounded-full transform rotate-15"></div>
              <div className="absolute bottom-[20%] right-[20%] w-[6%] h-[5%] bg-green-600/25 rounded-lg"></div>
            </div>

            {/* Interactive Pie Chart SVG Overlay */}
            <svg className="absolute inset-0 w-full h-full z-20" viewBox="0 0 100 100" style={{ touchAction: 'manipulation' }}>
              <defs>
                {allocations.map((allocation, index) => (
                  <g key={`gradient-group-${index}`}>
                    {/* Main gradient for pie slice */}
                    <radialGradient id={`gradient-${index}`} cx="30%" cy="30%">
                      <stop offset="0%" stopColor={allocation.color} stopOpacity="1" />
                      <stop offset="60%" stopColor={allocation.color} stopOpacity="0.8" />
                      <stop offset="100%" stopColor={allocation.color} stopOpacity="0.5" />
                    </radialGradient>
                    
                    {/* Highlight gradient for hover effect */}
                    <radialGradient id={`highlight-${index}`} cx="25%" cy="25%">
                      <stop offset="0%" stopColor="#ffffff" stopOpacity="0.3" />
                      <stop offset="40%" stopColor={allocation.color} stopOpacity="0.9" />
                      <stop offset="100%" stopColor={allocation.color} stopOpacity="0.6" />
                    </radialGradient>
                  </g>
                ))}
                
                {/* Filter for 3D emboss effect */}
                <filter id="emboss" x="-50%" y="-50%" width="200%" height="200%">
                  <feOffset dx="1" dy="1" in="SourceAlpha" result="offset" />
                  <feGaussianBlur stdDeviation="1" in="offset" result="blur" />
                  <feMerge>
                    <feMergeNode in="blur" />
                    <feMergeNode in="SourceGraphic" />
                  </feMerge>
                </filter>
              </defs>
              
              {allocations.map((allocation, index) => {
                const depthPath = create3DDepth(allocation, index);
                return (
                  <g key={allocation.label}>
                    {/* 3D Depth Effect - render first for layering */}
                    {depthPath && (
                      <path
                        d={depthPath}
                        fill={allocation.color}
                        opacity="0.6"
                        className="pointer-events-none"
                        style={{
                          filter: "brightness(0.7)"
                        }}
                      />
                    )}
                    
                    {/* Main Pie Slice */}
                    <path
                      d={createPieSlice(allocation, index)}
                      fill={`url(#gradient-${index})`}
                      stroke="rgba(255,255,255,0.2)"
                      strokeWidth="0.8"
                      className="cursor-pointer select-none pie-slice"
                      style={{
                        filter: `drop-shadow(0 4px 12px ${allocation.color}30)`,
                        transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
                        transformOrigin: "50px 50px"
                      }}
                      onMouseEnter={(e) => {
                        e.preventDefault();
                        const element = e.currentTarget as SVGPathElement;
                        element.style.filter = `drop-shadow(0 8px 25px ${allocation.color}60) brightness(1.15)`;
                        element.style.transform = "scale(1.05) translateZ(10px)";
                        element.style.strokeWidth = "1.2";
                        element.style.stroke = allocation.color;
                      }}
                      onMouseLeave={(e) => {
                        e.preventDefault();
                        const element = e.currentTarget as SVGPathElement;
                        element.style.filter = `drop-shadow(0 4px 12px ${allocation.color}30)`;
                        element.style.transform = "scale(1) translateZ(0px)";
                        element.style.strokeWidth = "0.8";
                        element.style.stroke = "rgba(255,255,255,0.2)";
                      }}
                      onTouchStart={(e) => {
                        e.preventDefault();
                        const element = e.currentTarget as SVGPathElement;
                        element.style.filter = `drop-shadow(0 12px 30px ${allocation.color}80) brightness(1.25)`;
                        element.style.transform = "scale(1.08) translateZ(15px)";
                        element.style.strokeWidth = "1.5";
                        element.style.stroke = allocation.color;
                      }}
                      onTouchEnd={(e) => {
                        e.preventDefault();
                        const element = e.currentTarget as SVGPathElement;
                        setTimeout(() => {
                          element.style.filter = `drop-shadow(0 4px 12px ${allocation.color}30)`;
                          element.style.transform = "scale(1) translateZ(0px)";
                          element.style.strokeWidth = "0.8";
                          element.style.stroke = "rgba(255,255,255,0.2)";
                        }, 200);
                      }}
                    />
                  </g>
                );
              })}
            </svg>

            {/* Center Text */}
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-30">
              <div className="text-center bg-black/70 backdrop-blur-md rounded-full p-6 md:p-8 border-2 border-cyan-400/40 shadow-2xl">
                <div className="text-3xl md:text-4xl font-bold text-white font-orbitron mb-1">990M</div>
                <div className="text-neon-cyan text-sm md:text-base font-semibold">Total Supply</div>
                <div className="text-gray-300 text-xs mt-1">Fixed • Non-Inflationary</div>
                <div className="w-12 h-0.5 bg-gradient-to-r from-transparent via-neon-cyan to-transparent mx-auto mt-2"></div>
              </div>
            </div>

            {/* Orbital Ring */}
            <div className="absolute inset-0 rounded-full border-2 border-neon-cyan/30 animate-spin" style={{ animationDuration: '30s' }}></div>
            <div className="absolute inset-2 md:inset-4 rounded-full border border-electric-purple/20 animate-spin" style={{ animationDuration: '20s', animationDirection: 'reverse' }}></div>
          </div>
          
          {/* Legend Below Chart */}
          <div className="mt-8 grid grid-cols-2 md:grid-cols-3 gap-4 max-w-3xl mx-auto z-40">
            {allocations.map((allocation, index) => {
              const IconComponent = allocation.icon;
              return (
                <div
                  key={allocation.label}
                  className="allocation-legend flex items-center p-3 rounded-lg backdrop-blur-sm border border-white/10 hover:border-white/20 transition-all duration-300 hover:scale-105"
                  style={{
                    background: 'linear-gradient(145deg, rgba(15, 23, 42, 0.6) 0%, rgba(30, 41, 59, 0.4) 100%)',
                    boxShadow: `0 0 15px ${allocation.color}20`
                  }}
                >
                  <div 
                    className="w-10 h-10 rounded-lg flex items-center justify-center mr-3 flex-shrink-0"
                    style={{ backgroundColor: allocation.color }}
                  >
                    <IconComponent className="w-5 h-5 text-white" />
                  </div>
                  
                  <div className="min-w-0">
                    <h4 className="text-white font-semibold text-sm truncate">{allocation.label}</h4>
                    <div className="flex items-center space-x-2">
                      <span className="text-lg font-bold" style={{ color: allocation.color }}>
                        {allocation.percentage}%
                      </span>
                      <span className="text-gray-400 text-xs">{allocation.amount}</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Utility Section */}
        <div className="mt-20">
          <h3 className="text-3xl font-bold text-white text-center mb-12 font-orbitron">
            Token <span className="text-gradient">Utility</span>
          </h3>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { title: "Contributor Rewards", desc: "Earn tokens for mapping data", icon: Users, color: "#06b6d4" },
              { title: "Staking Benefits", desc: "Stake for premium API access", icon: Shield, color: "#10b981" },
              { title: "API Usage", desc: "Pay for 3D mapping services", icon: Globe, color: "#8b5cf6" },
              { title: "NFT Privileges", desc: "Access exclusive satellite stations", icon: Coins, color: "#eab308" }
            ].map((utility, index) => {
              const IconComponent = utility.icon;
              return (
                <div
                  key={utility.title}
                  className="utility-card p-6 rounded-xl backdrop-blur-sm border border-white/10 hover:border-white/20 transition-all duration-300 hover:scale-105"
                  style={{
                    background: 'linear-gradient(145deg, rgba(15, 23, 42, 0.8) 0%, rgba(30, 41, 59, 0.6) 100%)',
                    boxShadow: `0 0 30px ${utility.color}20`
                  }}
                >
                  <div 
                    className="w-12 h-12 rounded-lg flex items-center justify-center mb-4 mx-auto"
                    style={{ backgroundColor: utility.color }}
                  >
                    <IconComponent className="w-6 h-6 text-white" />
                  </div>
                  <h4 className="text-white font-semibold text-center mb-2">{utility.title}</h4>
                  <p className="text-gray-400 text-sm text-center">{utility.desc}</p>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}