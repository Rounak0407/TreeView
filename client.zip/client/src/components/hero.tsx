import { useEffect, useRef } from "react";
import { Video, Radar, Satellite, Type, Camera } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { useTypewriter } from "@/hooks/use-typewriter";
import { useGSAP } from "@/hooks/use-gsap";
import TreeViewLogo from "./logo";
import AnimatedEarthGlobe from "./animated-earth-globe";

const modalData = {
  lidar: { icon: Radar, color: "bg-purple-600", title: "LiDAR Integration" },
  video: { icon: Video, color: "bg-blue-600", title: "Video Analytics" },
  gps: { icon: Satellite, color: "bg-green-600", title: "GPS & Positioning" },
  text: { icon: Type, color: "bg-yellow-600", title: "Text & Metadata" },
  imagery: { icon: Camera, color: "bg-red-600", title: "Imagery Processing" },
};

export default function Hero() {
  const treeContainerRef = useRef<HTMLDivElement>(null);
  const typewriterText = useTypewriter("Hybrid Multimodal 4D Semantic Mapping", 100, 1000);
  const [, setLocation] = useLocation();

  const { contextSafe } = useGSAP();

  useEffect(() => {
    const animateParticles = contextSafe(() => {
      if (typeof window !== 'undefined' && window.gsap) {
        window.gsap.to(".particle", {
          y: "random(-50, 50)",
          x: "random(-30, 30)",
          duration: "random(3, 6)",
          ease: "power2.inOut",
          repeat: -1,
          yoyo: true,
          stagger: 0.5
        });
      }
    });

    animateParticles();
  }, [contextSafe]);

  const handleNodeClick = (modalType: string) => {
    const event = new CustomEvent('openModal', { detail: modalType });
    window.dispatchEvent(event);
  };

  const navigateToContributors = () => {
    setLocation("/contributors");
  };

  const scrollToCommunity = () => {
    const element = document.getElementById("community");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section 
      className="min-h-screen bg-gradient-radial relative overflow-hidden pt-20 pointcloud-bg" 
      id="hero"
      data-testid="hero-section"
    >
      <div className="max-w-7xl mx-auto px-6 py-20">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <h1 className="font-orbitron text-5xl lg:text-7xl font-bold leading-tight">
              <span className="text-gradient" data-testid="hero-title">TreeView</span>
              <br />
              <span className="text-white" data-testid="typewriter-text">
                {typewriterText}
              </span>
              <span className="animate-pulse text-neon-cyan">|</span>
            </h1>
            <p className="text-xl text-gray-300 leading-relaxed" data-testid="hero-description">
              The first decentralized 4D mapping infrastructure combining phone cameras, vehicle sensors, 
              satellite mesh stations, and AI reconstruction for a continuously updating, permissionless map of Earth.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button 
                onClick={navigateToContributors}
                variant="outline"
                className="px-8 py-4 border border-neon-green text-neon-green hover:bg-neon-green hover:text-space-black transition-all rounded-lg"
                data-testid="button-map-in-4d"
              >
                Map in 4D
              </Button>
              <Button 
                onClick={scrollToCommunity}
                variant="outline"
                className="px-8 py-4 border border-neon-green text-neon-green hover:bg-neon-green hover:text-space-black transition-all rounded-lg"
                data-testid="button-join-community"
              >
                Join Community
              </Button>
            </div>
          </div>
          
          {/* Animated Globe with Orbiting Icons */}
          <div className="relative h-96 lg:h-[500px]" ref={treeContainerRef} data-testid="tree-visualization">
            <AnimatedEarthGlobe />
          </div>
        </div>
      </div>
      
      {/* Floating particles */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div 
          className="particle w-2 h-2 bg-neon-cyan rounded-full absolute animate-float" 
          style={{ top: '20%', left: '10%', animationDelay: '0s' }}
          data-testid="particle-1"
        />
        <div 
          className="particle w-1 h-1 bg-neon-green rounded-full absolute animate-float" 
          style={{ top: '60%', right: '15%', animationDelay: '1s' }}
          data-testid="particle-2"
        />
        <div 
          className="particle w-3 h-3 bg-electric-purple rounded-full absolute animate-float" 
          style={{ bottom: '30%', left: '20%', animationDelay: '2s' }}
          data-testid="particle-3"
        />
      </div>
    </section>
  );
}
