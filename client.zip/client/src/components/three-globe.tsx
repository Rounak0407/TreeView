import { useEffect, useRef } from "react";

declare global {
  interface Window {
    THREE: any;
  }
}

export default function ThreeGlobe() {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!containerRef.current) return;

    // Load Three.js dynamically
    const script = document.createElement('script');
    script.src = 'https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js';
    script.onload = () => {
      initGlobe();
    };
    document.head.appendChild(script);

    function initGlobe() {
      if (!containerRef.current || !window.THREE) return;

      const container = containerRef.current;
      const scene = new window.THREE.Scene();
      const camera = new window.THREE.PerspectiveCamera(
        75, 
        container.offsetWidth / container.offsetHeight, 
        0.1, 
        1000
      );
      const renderer = new window.THREE.WebGLRenderer({ alpha: true, antialias: true });
      
      renderer.setSize(container.offsetWidth, container.offsetHeight);
      renderer.setClearColor(0x000000, 0);
      container.appendChild(renderer.domElement);

      // Create globe
      const geometry = new window.THREE.SphereGeometry(2, 32, 32);
      const material = new window.THREE.MeshBasicMaterial({
        color: 0x00d4ff,
        wireframe: true,
        transparent: true,
        opacity: 0.7
      });
      const globe = new window.THREE.Mesh(geometry, material);
      scene.add(globe);

      // Add data points
      const dataPoints = [];
      for (let i = 0; i < 30; i++) {
        const pointGeometry = new window.THREE.SphereGeometry(0.02, 8, 8);
        const pointMaterial = new window.THREE.MeshBasicMaterial({
          color: Math.random() > 0.5 ? 0x00ff88 : 0x8b5cf6
        });
        const point = new window.THREE.Mesh(pointGeometry, pointMaterial);
        
        const phi = Math.acos(-1 + (2 * i) / 30);
        const theta = Math.sqrt(30 * Math.PI) * phi;
        
        point.position.x = 2.1 * Math.cos(theta) * Math.sin(phi);
        point.position.y = 2.1 * Math.sin(theta) * Math.sin(phi);
        point.position.z = 2.1 * Math.cos(phi);
        
        dataPoints.push(point);
        scene.add(point);
      }

      // Add orbiting satellites
      const satellites = [];
      for (let i = 0; i < 3; i++) {
        const satGeometry = new window.THREE.BoxGeometry(0.05, 0.05, 0.1);
        const satMaterial = new window.THREE.MeshBasicMaterial({ color: 0x8b5cf6 });
        const satellite = new window.THREE.Mesh(satGeometry, satMaterial);
        
        satellite.userData = { 
          orbitRadius: 3 + i * 0.5, 
          speed: 0.01 + i * 0.005,
          angle: i * Math.PI * 2 / 3
        };
        
        satellites.push(satellite);
        scene.add(satellite);
      }

      camera.position.z = 5;

      function animate() {
        requestAnimationFrame(animate);
        globe.rotation.y += 0.005;
        
        // Animate data points
        dataPoints.forEach((point, index) => {
          point.material.opacity = 0.5 + 0.5 * Math.sin(Date.now() * 0.001 + index);
        });
        
        // Animate satellites
        satellites.forEach((satellite) => {
          satellite.userData.angle += satellite.userData.speed;
          satellite.position.x = satellite.userData.orbitRadius * Math.cos(satellite.userData.angle);
          satellite.position.z = satellite.userData.orbitRadius * Math.sin(satellite.userData.angle);
          satellite.position.y = 0.5 * Math.sin(satellite.userData.angle * 2);
          satellite.rotation.y += 0.02;
        });
        
        renderer.render(scene, camera);
      }
      animate();

      // Handle resize
      const handleResize = () => {
        if (!containerRef.current) return;
        camera.aspect = containerRef.current.offsetWidth / containerRef.current.offsetHeight;
        camera.updateProjectionMatrix();
        renderer.setSize(containerRef.current.offsetWidth, containerRef.current.offsetHeight);
      };

      window.addEventListener('resize', handleResize);

      // Cleanup
      return () => {
        window.removeEventListener('resize', handleResize);
        if (container && renderer.domElement) {
          container.removeChild(renderer.domElement);
        }
      };
    }

    return () => {
      // Cleanup on unmount
      if (script.parentNode) {
        script.parentNode.removeChild(script);
      }
    };
  }, []);

  return (
    <div 
      ref={containerRef} 
      className="w-full h-full"
      data-testid="three-globe"
    />
  );
}
