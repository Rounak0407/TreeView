import { useEffect, useRef } from "react";
import { Cpu, Database, Globe, Smartphone, Cloud, Shield } from "lucide-react";
import { useGSAP } from "@/hooks/use-gsap";

export default function TechStack() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const { contextSafe } = useGSAP();

  useEffect(() => {
    const animateStack = contextSafe(() => {
      if (typeof window !== 'undefined' && window.gsap && window.ScrollTrigger) {
        window.gsap.timeline({
          scrollTrigger: {
            trigger: sectionRef.current,
            start: "top 80%",
            end: "bottom 20%",
            toggleActions: "play none none reverse"
          }
        })
        .from(".stack-layer", {
          y: 50,
          opacity: 0,
          duration: 0.6,
          stagger: 0.15
        });
      }
    });

    animateStack();
  }, [contextSafe]);

  const techLayers = [
    {
      name: "AI Engine",
      icon: Cpu,
      color: "electric-purple",
      technologies: ["PyTorch", "OpenCV", "SuperPoint", "Custom DepthNet"],
      description: "Visual SLAM pipeline with frame extraction and 3D reconstruction"
    },
    {
      name: "Sensor Hardware", 
      icon: Smartphone,
      color: "neon-green",
      technologies: ["Stereo depth cam", "RTK GNSS", "IMU", "LiDAR"],
      description: "Multi-modal sensor fusion for precise georeferencing"
    },
    {
      name: "Mobile App",
      icon: Globe,
      color: "neon-cyan", 
      technologies: ["Android (Kotlin)", "GPS integration", "Camera intrinsics", "Real-time upload"],
      description: "Crowdsourced data collection and processing"
    },
    {
      name: "Backend Infrastructure",
      icon: Cloud,
      color: "yellow-500",
      technologies: ["Python FastAPI", "PostgreSQL", "AWS S3", "IPFS"],
      description: "Scalable processing and decentralized storage"
    },
    {
      name: "3D Visualization",
      icon: Database,
      color: "pink-500", 
      technologies: ["Potree", "WebGL", "Three.js", "3D Tiles"],
      description: "Interactive 3D point cloud rendering and visualization"
    },
    {
      name: "Blockchain Layer",
      icon: Shield,
      color: "orange-500",
      technologies: ["peaq ID", "Smart contracts", "Token rewards", "Verification"],
      description: "Decentralized coordination and contributor incentives"
    }
  ];

  return (
    <section 
      className="py-20 bg-darker-gray" 
      id="tech-stack" 
      ref={sectionRef}
      data-testid="tech-stack-section"
    >
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="font-orbitron text-4xl lg:text-5xl font-bold mb-6 text-gradient" data-testid="tech-stack-title">
            Technology Stack
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto" data-testid="tech-stack-description">
            Enterprise-grade technologies powering the world's first decentralized 3D mapping infrastructure.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {techLayers.map((layer, index) => {
            const IconComponent = layer.icon;
            return (
              <div 
                key={layer.name}
                className="stack-layer glass-effect p-6 rounded-xl hover:border-opacity-80 transition-all cursor-pointer"
                style={{ borderColor: `var(--${layer.color})` }}
                data-testid={`stack-layer-${index}`}
              >
                <div className="flex items-center mb-4">
                  <div 
                    className={`w-12 h-12 bg-${layer.color} rounded-lg flex items-center justify-center mr-4`}
                    style={{ backgroundColor: `var(--${layer.color})` }}
                  >
                    <IconComponent className="text-white" size={24} />
                  </div>
                  <h3 className="text-xl font-bold font-orbitron">{layer.name}</h3>
                </div>
                
                <p className="text-gray-300 mb-4 text-sm leading-relaxed">
                  {layer.description}
                </p>
                
                <div className="flex flex-wrap gap-2">
                  {layer.technologies.map((tech, techIndex) => (
                    <span 
                      key={techIndex}
                      className="px-2 py-1 bg-gray-800 rounded text-xs font-mono text-gray-300"
                      data-testid={`tech-${index}-${techIndex}`}
                    >
                      {tech}
                    </span>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
        
        {/* Data Flow Diagram */}
        <div className="mt-16 glass-effect p-8 rounded-xl" data-testid="data-flow">
          <h3 className="text-2xl font-bold font-orbitron mb-8 text-center">Data Processing Pipeline</h3>
          <div className="grid md:grid-cols-5 gap-4 items-center">
            <div className="text-center">
              <div className="w-16 h-16 bg-neon-cyan rounded-full flex items-center justify-center mx-auto mb-2">
                <Smartphone className="text-space-black" size={24} />
              </div>
              <div className="text-sm text-gray-300">Data Collection</div>
            </div>
            <div className="text-center">
              <div className="text-neon-cyan text-2xl">→</div>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-electric-purple rounded-full flex items-center justify-center mx-auto mb-2">
                <Cpu className="text-white" size={24} />
              </div>
              <div className="text-sm text-gray-300">AI Processing</div>
            </div>
            <div className="text-center">
              <div className="text-neon-green text-2xl">→</div>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-neon-green rounded-full flex items-center justify-center mx-auto mb-2">
                <Database className="text-space-black" size={24} />
              </div>
              <div className="text-sm text-gray-300">3D Reconstruction</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}