import { useEffect, useRef, useState } from "react";
import { Video, Radar, Satellite, Type, Camera } from "lucide-react";

interface Icon {
  id: string;
  type: 'lidar' | 'video' | 'gps' | 'text' | 'imagery';
  angle: number;
  radius: number;
  speed: number;
  isClicked: boolean;
  scale: number;
}

const iconComponents = {
  lidar: Radar,
  video: Video,
  gps: Satellite,
  text: Type,
  imagery: Camera,
};

// Global satellite proximity checker
declare global {
  interface Window {
    checkSatelliteProximity?: () => boolean;
    deliverIconsFromSatellite?: () => void;
  }
}

export default function AnimatedEarthGlobe() {
  const containerRef = useRef<HTMLDivElement>(null);
  const [icons, setIcons] = useState<Icon[]>([]);
  const [score, setScore] = useState(0);
  const [gameActive, setGameActive] = useState(false);
  const [clickStreak, setClickStreak] = useState(0);
  const [showScore, setShowScore] = useState(false);
  const [worldProgress, setWorldProgress] = useState(0);
  const [missionsCompleted, setMissionsCompleted] = useState(0);
  const [timeLeft, setTimeLeft] = useState(25);
  const [gameOver, setGameOver] = useState(false);
  const [gameWon, setGameWon] = useState(false);
  const [collectedTypes, setCollectedTypes] = useState<Set<string>>(new Set());
  const animationRef = useRef<number>();

  // Initialize icons around the globe
  useEffect(() => {
    const initialIcons: Icon[] = [
      { id: '1', type: 'lidar', angle: 0, radius: 220, speed: 0.006, isClicked: false, scale: 1 },
      { id: '2', type: 'video', angle: 72, radius: 230, speed: 0.005, isClicked: false, scale: 1 },
      { id: '3', type: 'gps', angle: 144, radius: 240, speed: 0.007, isClicked: false, scale: 1 },
      { id: '4', type: 'text', angle: 216, radius: 235, speed: 0.004, isClicked: false, scale: 1 },
      { id: '5', type: 'imagery', angle: 288, radius: 225, speed: 0.006, isClicked: false, scale: 1 },
    ];
    setIcons(initialIcons);
  }, []);



  // Game mechanics
  const getIconScore = (type: string) => {
    switch (type) {
      case 'lidar': return 50;
      case 'video': return 30;
      case 'gps': return 40;
      case 'text': return 20;
      case 'imagery': return 35;
      default: return 10;
    }
  };

  const handleIconClick = (iconId: string) => {
    if (!gameActive) {
      setGameActive(true);
      setShowScore(true);
      startTimer();
    }

    if (gameOver || gameWon) return;

    setIcons(prev => prev.map(icon => {
      if (icon.id === iconId && !icon.isClicked) {
        const points = getIconScore(icon.type);
        const streakBonus = clickStreak >= 3 ? points * 0.5 : 0;
        setScore(s => s + points + streakBonus);
        setClickStreak(s => s + 1);
        
        // Track collected data types for multimodal progress
        setCollectedTypes(prev => new Set([...Array.from(prev), icon.type]));
        
        // Check if all 5 data types collected (complete multimodal mapping)
        const newCollectedTypes = new Set([...Array.from(collectedTypes), icon.type]);
        if (newCollectedTypes.size === 5) {
          setMissionsCompleted(prev => prev + 1);
          setWorldProgress(prev => Math.min(100, prev + 25));
          setCollectedTypes(new Set()); // Reset for next mission
          
          // Win condition: Complete 4 multimodal missions
          if (missionsCompleted + 1 >= 4) {
            setGameWon(true);
            setGameActive(false);
          }
        }
        
        // Respawn icon after animation
        setTimeout(() => {
          setIcons(prev => prev.map(i => 
            i.id === iconId 
              ? { ...i, isClicked: false, scale: 1, angle: Math.random() * 360 }
              : i
          ));
        }, 2000);
        
        return { ...icon, isClicked: true, scale: 0 };
      }
      return icon;
    }));
  };

  const startTimer = () => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          clearInterval(timer);
          setGameOver(true);
          setGameActive(false);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const resetGame = () => {
    setScore(0);
    setClickStreak(0);
    setGameActive(false);
    setShowScore(false);
    setWorldProgress(0);
    setMissionsCompleted(0);
    setTimeLeft(25);
    setGameOver(false);
    setGameWon(false);
    setCollectedTypes(new Set());
    setIcons(prev => prev.map(icon => ({ ...icon, isClicked: false, scale: 1 })));
  };

  // Animation loop with game mechanics
  useEffect(() => {
    const animate = () => {
      setIcons(prev => prev.map(icon => ({
        ...icon,
        angle: icon.angle + (icon.isClicked ? 0 : icon.speed),
        scale: icon.isClicked ? Math.max(0, icon.scale - 0.05) : icon.scale
      })));
      
      animationRef.current = requestAnimationFrame(animate);
    };
    
    animationRef.current = requestAnimationFrame(animate);
    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, []);

  // Reset streak if no clicks for a while
  useEffect(() => {
    if (clickStreak > 0) {
      const timeout = setTimeout(() => setClickStreak(0), 3000);
      return () => clearTimeout(timeout);
    }
  }, [clickStreak]);



  return (
    <div className="absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2 z-10">
      <div 
        ref={containerRef}
        className="absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2"
      >
        {/* Unique Earth Globe with Realistic Features */}
        <div className="relative">
          <div className="w-80 h-80 rounded-full relative">
            {/* Continental landmasses */}
            <div className="absolute inset-4 rounded-full bg-gradient-to-br from-blue-600/40 via-blue-500/30 to-blue-800/40 shadow-2xl overflow-hidden">
              {/* Continents - Europe/Africa */}
              <div className="absolute top-6 left-8 w-16 h-20 bg-green-600/60 rounded-lg transform rotate-12"></div>
              {/* North America */}
              <div className="absolute top-4 left-4 w-12 h-16 bg-green-700/50 rounded-xl transform -rotate-12"></div>
              {/* Asia */}
              <div className="absolute top-2 right-6 w-20 h-12 bg-green-600/70 rounded-2xl transform rotate-45"></div>
              {/* South America */}
              <div className="absolute bottom-6 left-12 w-8 h-18 bg-green-700/60 rounded-full transform rotate-15"></div>
              {/* Australia */}
              <div className="absolute bottom-8 right-8 w-6 h-4 bg-green-600/50 rounded-lg"></div>
              
              {/* Cloud formations */}
              <div className="absolute top-12 left-16 w-12 h-4 bg-white/30 rounded-full blur-sm"></div>
              <div className="absolute top-20 right-12 w-8 h-3 bg-white/25 rounded-full blur-sm"></div>
              <div className="absolute bottom-16 left-20 w-10 h-3 bg-white/20 rounded-full blur-sm"></div>
            </div>
            
            {/* White pointcloud overlay for 3D effect */}
            <div className="absolute inset-0">
              {[...Array(200)].map((_, i) => {
                const phi = Math.acos(1 - 2 * Math.random());
                const theta = 2 * Math.PI * Math.random();
                const radius = 36 + Math.random() * 4;
                
                const x = 50 + radius * Math.sin(phi) * Math.cos(theta);
                const y = 50 + radius * Math.sin(phi) * Math.sin(theta);
                const z = Math.cos(phi);
                
                return (
                  <div
                    key={i}
                    className="absolute w-1 h-1 bg-white rounded-full animate-pulse"
                    style={{
                      left: x + '%',
                      top: y + '%',
                      opacity: 0.2 + z * 0.6,
                      animationDelay: Math.random() * 4 + 's',
                      animationDuration: (2 + Math.random() * 2) + 's'
                    }}
                  />
                );
              })}
            </div>
            
            {/* Game Title Inside Globe */}
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              <div className="text-center">
                <div className="text-white/90 text-xl font-bold font-orbitron bg-black/30 backdrop-blur-sm px-4 py-2 rounded-lg border border-cyan-400/30">
                  Capture the World
                </div>
              </div>
            </div>
            
            {/* Atmospheric glow */}
            <div className="absolute inset-0 rounded-full bg-gradient-to-br from-blue-400/20 via-transparent to-blue-600/20 animate-pulse"></div>
            
            {/* Data scanning rings */}
            <div className="absolute inset-0 rounded-full border border-cyan-400/30 animate-ping" style={{animationDuration: '6s'}}></div>
            <div className="absolute inset-8 rounded-full border border-green-400/20 animate-ping" style={{animationDuration: '7s', animationDelay: '2s'}}></div>
            <div className="absolute inset-16 rounded-full border border-blue-400/15 animate-ping" style={{animationDuration: '8s', animationDelay: '4s'}}></div>
            
            {/* Outer glow effect */}
            <div className="absolute -inset-4 rounded-full bg-blue-400/5 blur-3xl animate-pulse"></div>
          </div>
        </div>

        {/* Orbiting Icons */}
        {icons.map((icon) => {
          const IconComponent = iconComponents[icon.type];
          const x = Math.cos(icon.angle) * icon.radius;
          const y = Math.sin(icon.angle) * icon.radius;
          
          // Icon colors matching hero section
          const getIconColor = (type: string) => {
            switch (type) {
              case 'lidar': return 'bg-purple-600/90 border-purple-400/70 shadow-purple-500/30';
              case 'video': return 'bg-blue-600/90 border-blue-400/70 shadow-blue-500/30';
              case 'gps': return 'bg-green-600/90 border-green-400/70 shadow-green-500/30';
              case 'text': return 'bg-yellow-600/90 border-yellow-400/70 shadow-yellow-500/30';
              case 'imagery': return 'bg-red-600/90 border-red-400/70 shadow-red-500/30';
              default: return 'bg-white/10 border-white/20';
            }
          };
          
          return (
            <div
              key={icon.id}
              className={`absolute w-14 h-14 flex items-center justify-center rounded-full backdrop-blur-sm transition-all duration-200 ease-out ${getIconColor(icon.type)} ${
                icon.isClicked ? 'animate-ping' : 'hover:scale-110 active:scale-95'
              } cursor-pointer shadow-xl border-2 ${
                gameActive ? 'animate-pulse' : ''
              } will-change-transform`}
              style={{
                left: x + 160,
                top: y + 160,
                zIndex: 20,
                transform: `scale(${icon.scale})`,
                opacity: icon.isClicked ? 0.3 : 1
              }}
              onClick={() => handleIconClick(icon.id)}
            >
              <IconComponent className="w-7 h-7 text-white drop-shadow-lg" />
              
              {/* Click effect */}
              {icon.isClicked && (
                <div className="absolute inset-0 bg-white/30 rounded-full animate-ping"></div>
              )}
            </div>
          );
        })}

        {/* Game UI - Compact Inside Globe */}
        {showScore && !gameOver && !gameWon && (
          <div className="absolute top-4 left-4 text-left pointer-events-auto">
            <div className="bg-black/70 backdrop-blur-sm rounded-md p-2 border border-cyan-400/30 shadow-md relative text-xs">
              <button 
                onClick={resetGame}
                className="absolute -top-1 -right-1 w-4 h-4 bg-red-600/80 hover:bg-red-500 text-white rounded-full flex items-center justify-center text-xs transition-colors"
              >
                ×
              </button>
              
              <div className="font-bold text-cyan-400 mb-1">Mission Status</div>
              <div className="text-white mb-1">Score: {score} | Time: {timeLeft}s</div>
              
              <div className="mb-1">
                <div className="text-gray-300 mb-1">World: {worldProgress}% | Missions: {missionsCompleted}/4</div>
                <div className="w-20 h-1 bg-gray-700 rounded-full overflow-hidden mb-1">
                  <div 
                    className="h-full bg-gradient-to-r from-green-500 to-cyan-500 transition-all duration-500"
                    style={{ width: `${worldProgress}%` }}
                  ></div>
                </div>
              </div>
              
              <div className="mb-1">
                <div className="text-gray-300 mb-1">Collect all 5 data types:</div>
                <div className="flex gap-1 items-center">
                  {['lidar', 'video', 'gps', 'text', 'imagery'].map((type, index) => (
                    <div key={type} className="flex items-center">
                      <div 
                        className={`w-1.5 h-1.5 rounded-full ${
                          collectedTypes.has(type) ? 'bg-green-500' : 'bg-gray-600'
                        }`}
                      ></div>
                      <span className={`text-xs ml-0.5 ${
                        collectedTypes.has(type) ? 'text-green-400' : 'text-gray-500'
                      }`}>
                        {type.charAt(0).toUpperCase()}
                      </span>
                      {index < 4 && <span className="text-gray-600 mx-0.5">•</span>}
                    </div>
                  ))}
                </div>
              </div>
              
              {clickStreak >= 3 && (
                <div className="text-yellow-400 font-semibold animate-pulse">
                  Streak x{clickStreak}!
                </div>
              )}
            </div>
          </div>
        )}

        {/* Game Over Screen - Inside Globe */}
        {gameOver && (
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-center pointer-events-auto">
            <div className="bg-red-900/85 backdrop-blur-sm rounded-lg p-4 border border-red-500/50 shadow-xl relative max-w-xs">
              <button 
                onClick={resetGame}
                className="absolute -top-2 -right-2 w-6 h-6 bg-red-600/80 hover:bg-red-500 text-white rounded-full flex items-center justify-center text-sm transition-colors"
              >
                ×
              </button>
              
              <div className="text-xl font-bold text-red-400 mb-2">Mission Failed!</div>
              <div className="text-white text-sm mb-2">Final Score: {score}</div>
              <div className="text-gray-300 text-xs mb-2">
                World Progress: {worldProgress}% | Missions: {missionsCompleted}/4
              </div>
              <div className="text-red-300 text-xs mb-3">
                Time ran out! Complete multimodal mapping requires all 5 data types.
              </div>
              <button 
                onClick={resetGame}
                className="px-4 py-2 bg-red-600/80 hover:bg-red-500/80 text-white rounded text-sm transition-colors"
              >
                Try Again
              </button>
            </div>
          </div>
        )}

        {/* Victory Screen - Inside Globe */}
        {gameWon && (
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-center pointer-events-auto">
            <div className="bg-green-900/85 backdrop-blur-sm rounded-lg p-4 border border-green-500/50 shadow-xl relative max-w-xs">
              <button 
                onClick={resetGame}
                className="absolute -top-2 -right-2 w-6 h-6 bg-green-600/80 hover:bg-green-500 text-white rounded-full flex items-center justify-center text-sm transition-colors"
              >
                ×
              </button>
              
              <div className="text-xl font-bold text-green-400 mb-2">World Captured!</div>
              <div className="text-white text-sm mb-2">Final Score: {score}</div>
              <div className="text-gray-300 text-xs mb-2">
                100% World Coverage | 4/4 Missions Complete
              </div>
              <div className="text-green-300 text-xs mb-3">
                Successfully mapped the world with multimodal 4D data!
              </div>
              <button 
                onClick={resetGame}
                className="px-4 py-2 bg-green-600/80 hover:bg-green-500/80 text-white rounded text-sm transition-colors"
              >
                Play Again
              </button>
            </div>
          </div>
        )}

        {/* Game Info Icon - Subtle and Non-intrusive */}
        {!gameActive && !gameOver && !gameWon && (
          <div className="absolute bottom-4 right-4 pointer-events-auto group">
            <div className="w-8 h-8 bg-cyan-600/80 hover:bg-cyan-500/90 rounded-full flex items-center justify-center cursor-pointer transition-all duration-300 animate-pulse hover:animate-none shadow-lg border border-cyan-400/50">
              <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
              </svg>
            </div>
            
            {/* Tooltip on hover */}
            <div className="absolute bottom-10 right-0 hidden group-hover:block z-50">
              <div className="bg-black/90 backdrop-blur-sm rounded-lg p-3 border border-cyan-400/40 shadow-xl max-w-xs">
                <div className="text-cyan-400 text-xs font-semibold mb-1">🎯 Mission: Capture the World</div>
                <div className="text-white/90 text-xs mb-2">
                  • Click orbiting icons to collect data
                  • Gather all 5 types: LiDAR, Video, GPS, Text, Imagery
                  • Complete 4 multimodal mapping missions
                  • Time limit: 25 seconds
                </div>
                <div className="text-yellow-400 text-xs animate-pulse">
                  Start by clicking any orbiting icon!
                </div>
                {/* Tooltip arrow */}
                <div className="absolute bottom-0 right-4 transform translate-y-1">
                  <div className="w-2 h-2 bg-black/90 border-r border-b border-cyan-400/40 transform rotate-45"></div>
                </div>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}