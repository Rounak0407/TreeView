import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

export default function Community() {
  const { toast } = useToast();

  // Fetch real-time community stats
  const { data: sensorData } = useQuery({
    queryKey: ['/api/sensor-data'],
    refetchInterval: 30000, // Refresh every 30 seconds (reduced for performance)
  });

  const { data: contributors } = useQuery({
    queryKey: ['/api/contributors'],
  });

  // Simulate data generation
  const simulateDataMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch('/api/simulate-data', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
      });
      if (!response.ok) {
        throw new Error('Failed to simulate data');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/sensor-data'] });
      toast({
        title: "Data Simulated",
        description: "New sensor data has been generated successfully!",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to simulate sensor data. Please try again.",
        variant: "destructive",
      });
    },
  });

  const totalDataPoints = sensorData?.length || 0;
  const activeContributors = contributors?.length || 0;

  return (
    <section className="py-20 bg-space-black" id="community" data-testid="community-section">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="font-orbitron text-4xl lg:text-5xl font-bold mb-6 text-gradient" data-testid="community-title">
            Join the Movement
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto" data-testid="community-description">
            Be part of the decentralized revolution in spatial intelligence. Connect with developers, 
            researchers, and innovators building the future of mapping.
          </p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8 mb-12">
          <div className="text-center" data-testid="stat-contributors">
            <div className="text-4xl font-bold text-neon-cyan mb-2">{activeContributors}+</div>
            <div className="text-gray-300">Active Contributors</div>
          </div>
          <div className="text-center" data-testid="stat-data-points">
            <div className="text-4xl font-bold text-neon-green mb-2">{totalDataPoints}</div>
            <div className="text-gray-300">Data Points Mapped</div>
          </div>
          <div className="text-center" data-testid="stat-countries">
            <div className="text-4xl font-bold text-electric-purple mb-2">150+</div>
            <div className="text-gray-300">Countries</div>
          </div>
        </div>
        
        <div className="glass-effect p-8 rounded-xl max-w-2xl mx-auto text-center" data-testid="community-cta">
          <h3 className="text-2xl font-bold font-orbitron mb-4">Start Contributing Today</h3>
          <p className="text-gray-300 mb-6">
            Download the TreeView app and start earning rewards for mapping your local environment.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              onClick={() => simulateDataMutation.mutate()}
              disabled={simulateDataMutation.isPending}
              className="px-6 py-3 bg-neon-cyan text-space-black font-semibold rounded-lg hover:bg-opacity-80 transition-all"
              data-testid="button-simulate-data"
            >
              {simulateDataMutation.isPending ? "Generating..." : "Simulate Data"}
            </Button>
            <Button 
              variant="outline"
              className="px-6 py-3 border border-neon-green text-neon-green hover:bg-neon-green hover:text-space-black transition-all rounded-lg"
              data-testid="button-developer-docs"
            >
              Developer Docs
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
