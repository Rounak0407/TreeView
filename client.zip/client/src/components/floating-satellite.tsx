import { useEffect, useRef } from "react";
import { Link } from "wouter";

export default function FloatingSatellite() {
  const satelliteRef = useRef<HTMLDivElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Simple setup for icon delivery if needed
    const intervalId = setInterval(() => {
      if (window.deliverIconsFromSatellite) {
        window.deliverIconsFromSatellite();
      }
    }, 10000);

    return () => {
      clearInterval(intervalId);
    };
  }, []);

  return (
    <div ref={containerRef} className="fixed inset-0 pointer-events-none z-50">
      <Link to="/space-journey">
        <div 
          ref={satelliteRef}
          className="absolute pointer-events-auto cursor-satellite hover:scale-110"
          style={{ 
            right: '100px',
            top: '100px',
            transform: 'none'
          }}
        >


          {/* Realistic Satellite Design */}
          <div className="relative group">
            {/* Main satellite body - cylindrical like real satellites */}
            <div className="w-12 h-20 bg-gradient-to-b from-gray-300 via-gray-200 to-gray-400 rounded-t-lg rounded-b-sm shadow-2xl border border-gray-300 relative">
              {/* Metallic panels */}
              <div className="absolute inset-x-1 top-2 h-3 bg-gradient-to-r from-gray-400 to-gray-300 rounded"></div>
              <div className="absolute inset-x-1 top-7 h-3 bg-gradient-to-r from-gray-300 to-gray-400 rounded"></div>
              <div className="absolute inset-x-1 top-12 h-3 bg-gradient-to-r from-gray-400 to-gray-300 rounded"></div>
              
              {/* Antenna array */}
              <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-4">
                <div className="w-1 h-4 bg-gray-600"></div>
                <div className="absolute -top-1 left-1/2 -translate-x-1/2 w-3 h-2 bg-gray-700 rounded-full"></div>
              </div>

              {/* Side antennas */}
              <div className="absolute top-4 -left-2 w-4 h-0.5 bg-gray-600"></div>
              <div className="absolute top-4 -right-2 w-4 h-0.5 bg-gray-600"></div>
              
              {/* Solar panels - realistic blue color */}
              <div className="absolute -left-8 top-3 w-6 h-14 bg-gradient-to-b from-blue-900 via-blue-800 to-blue-900 rounded-sm shadow-lg transform rotate-2 border border-blue-700">
                <div className="grid grid-cols-3 gap-0.5 p-1 h-full">
                  {[...Array(15)].map((_, i) => (
                    <div key={i} className="bg-blue-700 rounded-sm opacity-80"></div>
                  ))}
                </div>
              </div>
              
              <div className="absolute -right-8 top-3 w-6 h-14 bg-gradient-to-b from-blue-900 via-blue-800 to-blue-900 rounded-sm shadow-lg transform -rotate-2 border border-blue-700">
                <div className="grid grid-cols-3 gap-0.5 p-1 h-full">
                  {[...Array(15)].map((_, i) => (
                    <div key={i} className="bg-blue-700 rounded-sm opacity-80"></div>
                  ))}
                </div>
              </div>
              
              {/* Status lights */}
              <div className="absolute top-3 right-1 w-1.5 h-1.5 bg-green-400 rounded-full animate-pulse"></div>
              <div className="absolute top-6 right-1 w-1.5 h-1.5 bg-red-400 rounded-full animate-pulse" style={{animationDelay: '0.5s'}}></div>
              <div className="absolute top-9 right-1 w-1.5 h-1.5 bg-blue-400 rounded-full animate-pulse" style={{animationDelay: '1s'}}></div>
              
              {/* Thrusters */}
              <div className="absolute bottom-0 left-1/2 -translate-x-1/2 translate-y-2">
                <div className="flex space-x-1">
                  <div className="w-1 h-3 bg-gradient-to-b from-orange-400 via-red-500 to-transparent animate-pulse"></div>
                  <div className="w-1 h-3 bg-gradient-to-b from-orange-400 via-red-500 to-transparent animate-pulse" style={{animationDelay: '0.2s'}}></div>
                </div>
              </div>
              
              {/* Reflective surfaces */}
              <div className="absolute top-1 left-1 w-2 h-2 bg-white/60 rounded-sm transform rotate-45"></div>
              <div className="absolute bottom-4 right-1 w-1 h-1 bg-white/40 rounded-sm"></div>
            </div>

            {/* Signal waves - space communication */}
            <div className="absolute -inset-6 opacity-30 group-hover:opacity-50 transition-opacity duration-300">
              <div className="absolute inset-0 border border-green-400 rounded-full animate-ping" style={{animationDuration: '2s'}}></div>
              <div className="absolute inset-2 border border-blue-400 rounded-full animate-ping" style={{animationDuration: '2s', animationDelay: '0.7s'}}></div>
            </div>
          </div>
        </div>
      </Link>
    </div>
  );
}