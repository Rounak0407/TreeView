import { useEffect, useRef } from "react";
import { Smartphone, Car, Satellite, Camera, Radar, Navigation } from "lucide-react";
import { useGSAP } from "@/hooks/use-gsap";

export default function MappingModalities() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const { contextSafe } = useGSAP();

  useEffect(() => {
    const animateModalities = contextSafe(() => {
      if (typeof window !== 'undefined' && window.gsap && window.ScrollTrigger) {
        window.gsap.timeline({
          scrollTrigger: {
            trigger: sectionRef.current,
            start: "top 80%",
            end: "bottom 20%",
            toggleActions: "play none none reverse"
          }
        })
        .from(".modality-card", {
          y: 60,
          opacity: 0,
          duration: 0.8,
          stagger: 0.2,
          ease: "power2.out"
        });
      }
    });

    animateModalities();
  }, [contextSafe]);

  const modalities = [
    {
      icon: Smartphone,
      title: "Raw Video Input",
      description: "Smartphone, dashcam, and drone video processing with frame extraction and depth estimation",
      color: "neon-cyan",
      specs: ["HD/4K video streams", "Real-time processing", "GPS integration", "Camera intrinsics"]
    },
    {
      icon: Radar,
      title: "LiDAR + Stereo Fusion",
      description: "High-precision point cloud data combined with stereo camera depth sensing",
      color: "electric-purple",
      specs: ["Centimeter accuracy", "360° coverage", "Real-time fusion", "Point cloud generation"]
    },
    {
      icon: Navigation,
      title: "RTK & IMU Georeferencing",
      description: "Centimeter-level positioning with Inertial Measurement Unit integration",
      color: "neon-green",
      specs: ["RTK GNSS", "Sub-centimeter accuracy", "IMU fusion", "Global coordinates"]
    },
    {
      icon: Satellite,
      title: "Satellite Ground Mesh",
      description: "Fixed hardware hubs with satellite connectivity for comprehensive coverage",
      color: "yellow-500",
      specs: ["Starlink-ready", "Edge processing", "Mesh topology", "24/7 operation"]
    },
    {
      icon: Camera,
      title: "Street Camera 3D",
      description: "Existing street cameras enhanced with 3D perception capabilities",
      color: "pink-500",
      specs: ["Computer vision", "3D reconstruction", "Urban coverage", "Traffic analysis"]
    },
    {
      icon: Car,
      title: "Vehicle Sensor Kits",
      description: "Professional-grade mobile mapping systems for comprehensive data collection",
      color: "orange-500",
      specs: ["Multi-sensor arrays", "Professional accuracy", "Fleet integration", "Route optimization"]
    }
  ];

  return (
    <section 
      className="py-20 bg-space-black" 
      id="modalities" 
      ref={sectionRef}
      data-testid="modalities-section"
    >
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="font-orbitron text-4xl lg:text-5xl font-bold mb-6 text-gradient" data-testid="modalities-title">
            Mapping Modalities
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto" data-testid="modalities-description">
            Multiple data collection methods seamlessly integrated through our custom visual SLAM pipeline
            and AI reconstruction models.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {modalities.map((modality, index) => {
            const IconComponent = modality.icon;
            return (
              <div 
                key={modality.title}
                className="modality-card glass-effect p-6 rounded-xl hover:border-opacity-100 transition-all group cursor-pointer"
                style={{ borderColor: `var(--${modality.color})` }}
                data-testid={`modality-${index}`}
              >
                <div className="flex items-center mb-6">
                  <div 
                    className={`w-14 h-14 rounded-lg flex items-center justify-center mr-4 group-hover:scale-110 transition-transform`}
                    style={{ backgroundColor: `var(--${modality.color})` }}
                  >
                    <IconComponent 
                      className={modality.color.includes('yellow') || modality.color.includes('orange') || modality.color.includes('neon') ? 'text-space-black' : 'text-white'} 
                      size={28} 
                    />
                  </div>
                  <h3 className="text-xl font-bold font-orbitron">{modality.title}</h3>
                </div>
                
                <p className="text-gray-300 mb-6 leading-relaxed">
                  {modality.description}
                </p>
                
                <div className="space-y-2">
                  {modality.specs.map((spec, specIndex) => (
                    <div 
                      key={specIndex}
                      className="flex items-center text-sm"
                      data-testid={`spec-${index}-${specIndex}`}
                    >
                      <div 
                        className="w-2 h-2 rounded-full mr-3"
                        style={{ backgroundColor: `var(--${modality.color})` }}
                      />
                      <span className="text-gray-400">{spec}</span>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
        
        {/* AI Processing Pipeline Visual */}
        <div className="mt-16 glass-effect p-8 rounded-xl" data-testid="ai-pipeline">
          <h3 className="text-2xl font-bold font-orbitron mb-8 text-center">AI Mapping Stack</h3>
          <div className="grid md:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="w-16 h-16 bg-neon-cyan rounded-full flex items-center justify-center mx-auto mb-4">
                <Camera className="text-space-black" size={24} />
              </div>
              <h4 className="font-semibold mb-2">Frame Extraction</h4>
              <p className="text-sm text-gray-400">Video → key frames</p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-electric-purple rounded-full flex items-center justify-center mx-auto mb-4">
                <Radar className="text-white" size={24} />
              </div>
              <h4 className="font-semibold mb-2">Depth Estimation</h4>
              <p className="text-sm text-gray-400">Custom DepthNet</p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-neon-green rounded-full flex items-center justify-center mx-auto mb-4">
                <Navigation className="text-space-black" size={24} />
              </div>
              <h4 className="font-semibold mb-2">SfM Processing</h4>
              <p className="text-sm text-gray-400">Structure from Motion</p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-yellow-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <Satellite className="text-space-black" size={24} />
              </div>
              <h4 className="font-semibold mb-2">Point Cloud Gen</h4>
              <p className="text-sm text-gray-400">3D reconstruction</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}