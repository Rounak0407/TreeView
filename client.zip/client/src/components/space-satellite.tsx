import { useEffect, useRef, useState } from "react";
import { Satellite, X, Zap, Globe, MapPin, Users, Rocket } from "lucide-react";

export default function SpaceSatellite() {
  const satelliteRef = useRef<HTMLDivElement>(null);
  const earthRef = useRef<HTMLDivElement>(null);
  const [showSpaceExperience, setShowSpaceExperience] = useState(false);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.3 }
    );

    if (satelliteRef.current) {
      observer.observe(satelliteRef.current);
    }

    return () => observer.disconnect();
  }, []);

  // Simplified space experience activation
  useEffect(() => {
    if (isVisible) {
      const timer = setTimeout(() => {
        setShowSpaceExperience(true);
      }, 1000);
      return () => clearTimeout(timer);
    }
  }, [isVisible]);

  return (
    <>
      <div
        ref={satelliteRef}
        className="fixed z-30 cursor-pointer transform -translate-x-1/2 -translate-y-1/2"
        style={{ pointerEvents: 'auto' }}
        data-testid="space-satellite"
        onClick={() => setShowSpaceExperience(true)}
      >
        <div className="relative group">
          {/* Satellite glow */}
          <div className="absolute -inset-2 w-24 h-24 bg-electric-purple rounded-full blur-xl opacity-30 group-hover:opacity-60 transition-all duration-300"></div>
          
          {/* Main satellite body */}
          <div className="relative w-20 h-20 bg-gradient-to-r from-gray-200 to-gray-400 rounded-xl shadow-2xl border-2 border-gray-300">
            {/* Central core */}
            <div className="absolute inset-3 bg-gradient-to-br from-blue-900 to-gray-800 rounded-lg flex items-center justify-center">
              <div className="w-3 h-3 bg-neon-cyan rounded-full animate-pulse shadow-lg shadow-neon-cyan"></div>
            </div>
            
            {/* Solar panels */}
            <div className="absolute -left-4 top-1/2 transform -translate-y-1/2 w-10 h-16 bg-gradient-to-r from-blue-600 to-blue-400 rounded border-2 border-blue-300 opacity-90 shadow-lg"></div>
            <div className="absolute -right-4 top-1/2 transform -translate-y-1/2 w-10 h-16 bg-gradient-to-r from-blue-600 to-blue-400 rounded border-2 border-blue-300 opacity-90 shadow-lg"></div>
            
            {/* Antennas */}
            <div className="absolute -top-3 left-1/2 transform -translate-x-1/2 w-1.5 h-8 bg-gray-300 rounded-full"></div>
            <div className="absolute -bottom-3 right-3 w-1.5 h-6 bg-gray-300 rounded-full"></div>
            
            {/* Communication beam */}
            <div className="absolute top-full left-1/2 transform -translate-x-1/2 w-3 h-32 bg-gradient-to-b from-neon-cyan via-electric-purple to-transparent opacity-50 rounded-full blur-sm"></div>
          </div>
          
          {/* Orbit trail particles */}
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-8 h-8 border-2 border-electric-purple rounded-full animate-ping opacity-30"></div>
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-12 h-12 border border-neon-cyan rounded-full animate-ping opacity-20" style={{ animationDelay: '1s' }}></div>
          
          {/* Hover tooltip */}
          <div className="absolute -bottom-12 left-1/2 transform -translate-x-1/2 bg-space-black px-3 py-2 rounded-lg text-sm text-neon-cyan opacity-0 group-hover:opacity-100 transition-all duration-300 whitespace-nowrap border border-neon-cyan shadow-lg shadow-neon-cyan/20">
            Click to Enter Space
          </div>
        </div>
      </div>

      {/* Full Space Experience Modal */}
      {showSpaceExperience && (
        <div className="fixed inset-0 z-50 bg-gradient-to-br from-slate-900 via-blue-950 to-black overflow-y-auto">
          <div className="min-h-screen relative">
            {/* Close button */}
            <button 
              onClick={() => setShowSpaceExperience(false)}
              className="fixed top-6 right-6 z-[60] p-3 bg-slate-800/90 backdrop-blur-sm hover:bg-slate-700 rounded-full transition-all duration-300 border border-slate-600 hover:border-blue-400 group"
            >
              <X className="text-slate-300 group-hover:text-white" size={24} />
            </button>

            {/* Space Animation Container */}
            <div className="relative min-h-screen flex flex-col items-center justify-center p-8">
              
              {/* Header */}
              <div className="text-center mb-20 z-10 relative">
                <h1 className="font-mono text-5xl md:text-7xl font-light tracking-wider text-white mb-8 drop-shadow-2xl">
                  SATELLITE MAPPING
                </h1>
                <div className="text-lg md:text-xl text-slate-300 font-light tracking-wide uppercase">
                  Community-Owned <span className="text-blue-400">•</span> DePIN Powered <span className="text-blue-400">•</span> Fully Permissionless
                </div>
              </div>

              {/* Earth Visualization */}
              <div className="relative mb-20">
                <div 
                  ref={earthRef}
                  className="w-80 h-80 md:w-96 md:h-96 bg-gradient-to-br from-blue-500 via-green-500 to-blue-800 rounded-full relative border-2 border-blue-300/30 shadow-2xl shadow-blue-500/20"
                  style={{
                    background: 'radial-gradient(circle at 30% 30%, #3b82f6 0%, #22c55e 20%, #1e40af 40%, #1e3a8a 70%, #0f172a 100%)',
                    boxShadow: '0 0 80px rgba(59, 130, 246, 0.3), inset 0 0 40px rgba(0, 0, 0, 0.4)'
                  }}
                >
                  {/* Continents - more realistic */}
                  <div className="absolute inset-8 rounded-full bg-gradient-to-br from-emerald-400/40 via-green-600/30 to-emerald-800/20 opacity-70"></div>
                  <div className="absolute top-6 right-12 w-16 h-20 bg-green-600/40 rounded-full transform rotate-45"></div>
                  <div className="absolute bottom-8 left-8 w-20 h-12 bg-green-500/30 rounded-full transform -rotate-12"></div>
                  
                  {/* Scanning beam effect */}
                  <div className="absolute inset-0 rounded-full border-2 border-blue-400/30 animate-ping"></div>
                  <div className="absolute inset-4 rounded-full border border-cyan-400/40 animate-ping" style={{ animationDelay: '1s' }}></div>
                  
                  {/* Active mapping points - professional styling */}
                  <div className="mapping-point absolute top-1/4 left-1/3 w-2 h-2 bg-cyan-400 rounded-full shadow-lg shadow-cyan-400/50">
                    <div className="absolute inset-0 bg-cyan-400 rounded-full animate-ping"></div>
                  </div>
                  <div className="mapping-point absolute top-1/2 right-1/4 w-2 h-2 bg-emerald-400 rounded-full shadow-lg shadow-emerald-400/50">
                    <div className="absolute inset-0 bg-emerald-400 rounded-full animate-ping" style={{ animationDelay: '0.5s' }}></div>
                  </div>
                  <div className="mapping-point absolute bottom-1/3 left-1/2 w-2 h-2 bg-blue-400 rounded-full shadow-lg shadow-blue-400/50">
                    <div className="absolute inset-0 bg-blue-400 rounded-full animate-ping" style={{ animationDelay: '1s' }}></div>
                  </div>
                  <div className="mapping-point absolute top-1/3 right-1/3 w-2 h-2 bg-violet-400 rounded-full shadow-lg shadow-violet-400/50">
                    <div className="absolute inset-0 bg-violet-400 rounded-full animate-ping" style={{ animationDelay: '1.5s' }}></div>
                  </div>
                  <div className="mapping-point absolute bottom-1/4 right-1/2 w-2 h-2 bg-orange-400 rounded-full shadow-lg shadow-orange-400/50">
                    <div className="absolute inset-0 bg-orange-400 rounded-full animate-ping" style={{ animationDelay: '2s' }}></div>
                  </div>

                  {/* Larger professional satellite */}
                  <div className="absolute animate-orbit" style={{ top: '-60px', left: '50%', marginLeft: '-20px' }}>
                    <div className="relative w-10 h-10 bg-gradient-to-r from-slate-300 to-slate-500 rounded-lg shadow-2xl border border-slate-400">
                      {/* Satellite core */}
                      <div className="absolute inset-1 bg-gradient-to-br from-slate-700 to-slate-900 rounded flex items-center justify-center">
                        <div className="w-1.5 h-1.5 bg-cyan-400 rounded-full animate-pulse shadow-lg shadow-cyan-400/50"></div>
                      </div>
                      
                      {/* Solar panels */}
                      <div className="absolute -left-2 top-1/2 transform -translate-y-1/2 w-6 h-8 bg-gradient-to-r from-blue-600 to-blue-400 rounded border border-blue-300 opacity-90 shadow-lg"></div>
                      <div className="absolute -right-2 top-1/2 transform -translate-y-1/2 w-6 h-8 bg-gradient-to-r from-blue-600 to-blue-400 rounded border border-blue-300 opacity-90 shadow-lg"></div>
                      
                      {/* Scanning beam */}
                      <div className="absolute top-full left-1/2 transform -translate-x-1/2 w-1 h-20 bg-gradient-to-b from-cyan-400 via-blue-400 to-transparent opacity-60 rounded-full blur-sm animate-pulse"></div>
                      <div className="absolute top-full left-1/2 transform -translate-x-1/2 w-8 h-8 border border-cyan-400/30 rounded-full animate-ping"></div>
                    </div>
                  </div>
                </div>

                {/* Enhanced data streams */}
                <svg className="absolute inset-0 w-full h-full pointer-events-none">
                  <defs>
                    <linearGradient id="scanGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="#06b6d4" stopOpacity="0.8"/>
                      <stop offset="50%" stopColor="#3b82f6" stopOpacity="0.6"/>
                      <stop offset="100%" stopColor="#8b5cf6" stopOpacity="0.4"/>
                    </linearGradient>
                  </defs>
                  
                  {/* Multiple scanning beams */}
                  <path 
                    className="data-stream-line"
                    d="M 240,60 Q 220,140 190,190" 
                    stroke="url(#scanGradient)" 
                    strokeWidth="1" 
                    fill="none"
                    strokeDasharray="0,300"
                  />
                  <path 
                    className="data-stream-line"
                    d="M 240,60 Q 280,120 320,200" 
                    stroke="url(#scanGradient)" 
                    strokeWidth="1" 
                    fill="none"
                    strokeDasharray="0,300"
                  />
                  <path 
                    className="data-stream-line"
                    d="M 240,60 Q 240,140 240,220" 
                    stroke="url(#scanGradient)" 
                    strokeWidth="1" 
                    fill="none"
                    strokeDasharray="0,300"
                  />
                </svg>
              </div>

              {/* Professional Feature Grid */}
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-20 max-w-7xl mx-auto">
                <div className="bg-slate-800/40 backdrop-blur-sm p-8 rounded-2xl border border-slate-700 hover:border-blue-400 transition-all duration-300 hover:-translate-y-1">
                  <div className="flex items-center mb-6">
                    <div className="p-3 bg-blue-500/20 rounded-lg mr-4">
                      <Satellite className="text-blue-400" size={24} />
                    </div>
                    <h3 className="font-mono text-xl font-medium text-white uppercase tracking-wider">Community Satellite</h3>
                  </div>
                  <p className="text-slate-300 leading-relaxed font-light">
                    First community-owned satellite operated through TreeView DePIN ecosystem with full decentralized governance and transparent operations.
                  </p>
                </div>

                <div className="bg-slate-800/40 backdrop-blur-sm p-8 rounded-2xl border border-slate-700 hover:border-emerald-400 transition-all duration-300 hover:-translate-y-1">
                  <div className="flex items-center mb-6">
                    <div className="p-3 bg-emerald-500/20 rounded-lg mr-4">
                      <Globe className="text-emerald-400" size={24} />
                    </div>
                    <h3 className="font-mono text-xl font-medium text-white uppercase tracking-wider">3D Earth Mapping</h3>
                  </div>
                  <p className="text-slate-300 leading-relaxed font-light">
                    Captures 3D elevation data (DEM), optical imagery, and GNSS signal intelligence for comprehensive Earth mapping and analysis.
                  </p>
                </div>

                <div className="bg-slate-800/40 backdrop-blur-sm p-8 rounded-2xl border border-slate-700 hover:border-violet-400 transition-all duration-300 hover:-translate-y-1">
                  <div className="flex items-center mb-6">
                    <div className="p-3 bg-violet-500/20 rounded-lg mr-4">
                      <Zap className="text-violet-400" size={24} />
                    </div>
                    <h3 className="font-mono text-xl font-medium text-white uppercase tracking-wider">Blockchain Control</h3>
                  </div>
                  <p className="text-slate-300 leading-relaxed font-light">
                    Satellite control, data transmission, and governance via peaq-powered smart contracts and on-orbit license NFTs.
                  </p>
                </div>

                <div className="bg-slate-800/40 backdrop-blur-sm p-8 rounded-2xl border border-slate-700 hover:border-amber-400 transition-all duration-300 hover:-translate-y-1">
                  <div className="flex items-center mb-6">
                    <div className="p-3 bg-amber-500/20 rounded-lg mr-4">
                      <MapPin className="text-amber-400" size={24} />
                    </div>
                    <h3 className="font-mono text-xl font-medium text-white uppercase tracking-wider">Terrestrial Integration</h3>
                  </div>
                  <p className="text-slate-300 leading-relaxed font-light">
                    Integrates with ground-level nodes to anchor and refine 3D reconstructions from orbit to street level mapping.
                  </p>
                </div>

                <div className="bg-slate-800/40 backdrop-blur-sm p-8 rounded-2xl border border-slate-700 hover:border-pink-400 transition-all duration-300 hover:-translate-y-1">
                  <div className="flex items-center mb-6">
                    <div className="p-3 bg-pink-500/20 rounded-lg mr-4">
                      <Users className="text-pink-400" size={24} />
                    </div>
                    <h3 className="font-mono text-xl font-medium text-white uppercase tracking-wider">Fully Permissionless</h3>
                  </div>
                  <p className="text-slate-300 leading-relaxed font-light">
                    Independent from Starlink or external providers. Completely TreeView-governed and permissionless infrastructure.
                  </p>
                </div>

                <div className="bg-slate-800/40 backdrop-blur-sm p-8 rounded-2xl border border-slate-700 hover:border-orange-400 transition-all duration-300 hover:-translate-y-1">
                  <div className="flex items-center mb-6">
                    <div className="p-3 bg-orange-500/20 rounded-lg mr-4">
                      <Rocket className="text-orange-400" size={24} />
                    </div>
                    <h3 className="font-mono text-xl font-medium text-white uppercase tracking-wider">Advanced Technology</h3>
                  </div>
                  <p className="text-slate-300 leading-relaxed font-light">
                    Cutting-edge satellite technology with AI-powered data processing and real-time global mapping capabilities.
                  </p>
                </div>
              </div>

              {/* Professional Launch Announcement */}
              <div className="text-center">
                <div className="inline-block px-16 py-8 bg-gradient-to-r from-slate-800 via-blue-900 to-slate-800 rounded-3xl border-2 border-blue-400/50 backdrop-blur-sm shadow-2xl shadow-blue-500/20">
                  <div className="flex items-center justify-center mb-4">
                    <Rocket className="text-blue-400 mr-4" size={32} />
                    <h2 className="font-mono text-3xl md:text-4xl font-light text-white uppercase tracking-widest">
                      Launch Sequence Initiated
                    </h2>
                  </div>
                  <p className="text-lg text-slate-300 font-light tracking-wide">
                    TreeView satellite deployment approaching orbital readiness
                  </p>
                  <div className="mt-4 text-blue-400 font-mono text-sm tracking-wider">
                    STATUS: GOING TO SPACE SOON
                  </div>
                </div>
              </div>

              {/* Floating stars */}
              <div className="absolute inset-0 pointer-events-none">
                {Array.from({ length: 50 }).map((_, i) => (
                  <div
                    key={i}
                    className="absolute w-1 h-1 bg-white rounded-full animate-ping opacity-30"
                    style={{
                      left: `${Math.random() * 100}%`,
                      top: `${Math.random() * 100}%`,
                      animationDelay: `${Math.random() * 3}s`,
                      animationDuration: `${2 + Math.random() * 2}s`
                    }}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}