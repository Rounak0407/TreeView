import { useState } from "react";
import { Moon, Sun, Menu, X } from "lucide-react";
import { useTheme } from "./theme-provider";
import { Button } from "@/components/ui/button";
import TreeViewLogo from "./logo";

export default function Navigation() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { theme, setTheme } = useTheme();

  const toggleTheme = () => {
    setTheme(theme === "dark" ? "light" : "dark");
  };

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
      setMobileMenuOpen(false);
    }
  };

  return (
    <>
      <nav className="fixed top-0 w-full z-50 glass-effect" data-testid="navigation">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3" data-testid="logo">
              <TreeViewLogo />
            </div>
            
            <div className="hidden md:flex items-center space-x-8">
              <a 
                href="/"
                className="hover:text-neon-cyan transition-colors"
                data-testid="nav-home"
              >
                Home
              </a>
              <a 
                href="/tree-evolution"
                className="hover:text-neon-cyan transition-colors"
                data-testid="nav-tree-evolution"
              >
                Tree Evolution
              </a>
              <a 
                href="/contributors"
                className="hover:text-neon-cyan transition-colors"
                data-testid="nav-contributors"
              >
                Contributors
              </a>
              <button 
                onClick={() => scrollToSection("technology")}
                className="hover:text-neon-cyan transition-colors"
                data-testid="nav-technology"
              >
                Technology
              </button>
              <a 
                href="/details"
                className="hover:text-neon-cyan transition-colors"
                data-testid="nav-details"
              >
                Tech Details
              </a>
              <Button
                variant="ghost"
                size="icon"
                onClick={toggleTheme}
                className="text-neon-cyan hover:text-neon-green transition-colors"
                data-testid="theme-toggle"
              >
                {theme === "dark" ? <Moon size={20} /> : <Sun size={20} />}
              </Button>
            </div>
            
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden text-neon-cyan"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              data-testid="mobile-menu-toggle"
            >
              {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </Button>
          </div>
        </div>
      </nav>

      {/* Mobile Menu Overlay */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-40 bg-space-black bg-opacity-95 md:hidden" data-testid="mobile-menu">
          <div className="flex flex-col items-center justify-center h-full space-y-8 text-xl">
            <a 
              href="/"
              className="hover:text-neon-cyan transition-colors"
              data-testid="mobile-nav-home"
              onClick={() => setMobileMenuOpen(false)}
            >
              Home
            </a>
            <a 
              href="/tree-evolution"
              className="hover:text-neon-cyan transition-colors"
              data-testid="mobile-nav-tree-evolution"
              onClick={() => setMobileMenuOpen(false)}
            >
              Tree Evolution
            </a>
            <button 
              onClick={() => scrollToSection("technology")}
              className="hover:text-neon-cyan transition-colors"
              data-testid="mobile-nav-technology"
            >
              Technology
            </button>
            <a 
              href="/details"
              className="hover:text-neon-cyan transition-colors"
              data-testid="mobile-nav-details"
              onClick={() => setMobileMenuOpen(false)}
            >
              Tech Details
            </a>
            <Button
              variant="ghost"
              onClick={toggleTheme}
              className="text-neon-cyan hover:text-neon-green transition-colors"
              data-testid="mobile-theme-toggle"
            >
              {theme === "dark" ? "Light Mode" : "Dark Mode"}
            </Button>
          </div>
        </div>
      )}
    </>
  );
}
