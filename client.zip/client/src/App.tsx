import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/components/theme-provider";
// Wallet imports moved to Console component to prevent global initialization
import Home from "@/pages/home";
import Details from "@/pages/details";
import SpaceJourney from "@/pages/space-journey";
import TreeEvolution from "@/pages/tree-evolution";
import Contributors from "@/pages/contributors";
import Auth from "@/pages/auth";
import Console from "@/pages/console";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/details" component={Details} />
      <Route path="/space-journey" component={SpaceJourney} />
      <Route path="/tree-evolution" component={TreeEvolution} />
      <Route path="/contributors" component={Contributors} />
      <Route path="/auth" component={Auth} />
      <Route path="/console" component={Console} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
